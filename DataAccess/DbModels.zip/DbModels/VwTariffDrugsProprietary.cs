﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwTariffDrugsProprietary
{
    public int TariffId { get; set; }

    public string? TariffName { get; set; }

    public int? ServiceId { get; set; }

    public string? ServiceName { get; set; }

    public int? DrugGenId { get; set; }

    public string? GenericName { get; set; }

    public int? GenderSpecific { get; set; }

    public int? AgeLower { get; set; }

    public int? AgeUpper { get; set; }

    public int? MaxIncidences { get; set; }

    public int? PerDuration { get; set; }

    public int? AnExclusion { get; set; }

    public string? TariffCode { get; set; }

    public int? PreAuthorization { get; set; }

    public int? OpticalServicesTypeId { get; set; }

    public int? LabGroupId { get; set; }

    public int? MedClassId { get; set; }

    public int? InOutPatient { get; set; }

    public bool? Generic { get; set; }

    public bool? Branded { get; set; }

    public int? Status { get; set; }
}
