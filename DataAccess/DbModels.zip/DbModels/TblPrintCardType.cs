﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblPrintCardType
{
    public int PrintypeId { get; set; }

    public string? PrintName { get; set; }
}
