﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class RxProvidersPlan
{
    public double? Id { get; set; }

    public double? ProviderId { get; set; }

    public string? InsCompany { get; set; }

    public string? Plan { get; set; }

    public string? Status { get; set; }

    public double? PlanId { get; set; }

    public string? IdInscompany { get; set; }
}
