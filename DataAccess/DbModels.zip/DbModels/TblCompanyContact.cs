﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblCompanyContact
{
    public int Id { get; set; }

    public int? CompanyId { get; set; }

    public string? ContactName { get; set; }

    public string? ContactNo { get; set; }

    public string? EmailAddress { get; set; }

    public string? Rank { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }
}
