﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblGhanaCardUpdate
{
    public int GhId { get; set; }

    public int MemId { get; set; }

    public string CardNumber { get; set; } = null!;

    public DateTime DateTimeCreated { get; set; }

    public string? Channel { get; set; }
}
