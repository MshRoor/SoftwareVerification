﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwClaimsBatchHspaward
{
    public int Id { get; set; }

    public int BatchNo { get; set; }

    public decimal? Claimed { get; set; }

    public decimal? SysAward { get; set; }

    public decimal? Awarded { get; set; }

    public decimal? Building { get; set; }

    public decimal? AmountDue { get; set; }

    public DateTime? AwardDate { get; set; }

    public string? Comment { get; set; }

    public string? AmountWord { get; set; }

    public int? Status { get; set; }

    public int? ServiceProviderId { get; set; }

    public string ServiceProvider { get; set; } = null!;

    public int? NoOfClaims { get; set; }

    public decimal? AmountClaimed { get; set; }

    public DateTime? DateOfClaim { get; set; }

    public int? StatusId { get; set; }

    public bool? BuildingFund { get; set; }

    public bool? WitholdingTax { get; set; }

    public string? CustomerId { get; set; }

    public int? Tpa { get; set; }

    public string BatchType { get; set; } = null!;

    public int? TypeOfBatching { get; set; }

    public string? MonthOfClaim { get; set; }

    public decimal? Withold { get; set; }

    public string WithHoldingRate { get; set; } = null!;
}
