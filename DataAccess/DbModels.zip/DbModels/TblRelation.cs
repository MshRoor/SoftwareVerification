﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblRelation
{
    public int Id { get; set; }

    public string? Relationship { get; set; }

    public int? GenderRation { get; set; }

    public string? RelationId { get; set; }

    public string? RalationType { get; set; }

    public virtual ICollection<TblMember> TblMembers { get; set; } = new List<TblMember>();
}
