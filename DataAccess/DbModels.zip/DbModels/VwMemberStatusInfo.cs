﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwMemberStatusInfo
{
    public int RowId { get; set; }

    public int MemberId { get; set; }

    public int StatusId { get; set; }

    public string? Status { get; set; }

    public DateTime EffectiveDate { get; set; }

    public int UserId { get; set; }

    public string Username { get; set; } = null!;

    public DateTime? CreatedDate { get; set; }
}
