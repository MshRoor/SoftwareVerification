﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblCrmescalationLevel
{
    public int EscalateLevel { get; set; }

    public string EscalateEmail { get; set; } = null!;
}
