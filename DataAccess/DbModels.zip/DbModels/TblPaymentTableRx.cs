﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblPaymentTableRx
{
    public double Id { get; set; }

    public int? ProviderId { get; set; }

    public int? ProviderIdMaster { get; set; }

    public string? ProviderName { get; set; }

    public string? InsCompany { get; set; }

    public int? Yrofclaim { get; set; }

    public int? Monthofclaim { get; set; }

    public double? ProviderClaimAmt { get; set; }

    public string? InsurerAmtPaid { get; set; }

    public string? TaxAmt { get; set; }

    public string? RejectedAmt { get; set; }

    public string? PaymentStatus { get; set; }

    public string? Chknumber { get; set; }

    public int? NumberOfClaims { get; set; }

    public string? SystemInvoiceNo { get; set; }

    public DateTime? DateAdded { get; set; }

    public string? PaymentDate { get; set; }

    public string? TypeOfFacility { get; set; }

    public int? NmhPull { get; set; }

    public int? IsBatch { get; set; }

    public DateOnly? DateBatch { get; set; }
}
