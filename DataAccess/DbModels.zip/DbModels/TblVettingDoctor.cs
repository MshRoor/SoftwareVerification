﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblVettingDoctor
{
    public int Id { get; set; }

    public string Doctor { get; set; } = null!;

    public string? Email { get; set; }
}
