﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblDrugMapPricesMobimed
{
    public int Id { get; set; }

    public int DrugId { get; set; }

    public double DrugPrice { get; set; }

    public DateTime EffectiveDate { get; set; }

    public DateTime? EndDate { get; set; }

    public DateTime? DateStamp { get; set; }
}
