﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwCompanySalesComment
{
    public int Id { get; set; }

    public string Comment { get; set; } = null!;

    public int? DepartmentId { get; set; }

    public string? Department { get; set; }

    public string? EmailAddress { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? CreatedDate { get; set; }
}
