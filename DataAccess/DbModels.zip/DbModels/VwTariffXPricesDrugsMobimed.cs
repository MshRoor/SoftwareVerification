﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwTariffXPricesDrugsMobimed
{
    public int TariffId { get; set; }

    public DateTime EffectiveDate { get; set; }

    public DateTime EndDate { get; set; }

    public double DrugPrice { get; set; }
}
