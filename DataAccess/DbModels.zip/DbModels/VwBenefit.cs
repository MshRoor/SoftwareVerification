﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwBenefit
{
    public int Id { get; set; }

    public string Benefit { get; set; } = null!;

    public int BenefitGroupId { get; set; }

    public string BenefitGroup { get; set; } = null!;

    public int? BenefitParentId { get; set; }

    public string ParentName { get; set; } = null!;
}
