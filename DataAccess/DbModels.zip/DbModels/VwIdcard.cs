﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwIdcard
{
    public int Id { get; set; }

    public int? CompanyId { get; set; }

    public int? GenderId { get; set; }

    public int? TitleId { get; set; }

    public string? Surname { get; set; }

    public string? FirstName { get; set; }

    public string? OtherName { get; set; }

    public DateTime? Dob { get; set; }

    public int? MaritalId { get; set; }

    public int? OccupationId { get; set; }

    public string? Nhisno { get; set; }

    public string? Email { get; set; }

    public string? Mphone { get; set; }

    public string? Hphone { get; set; }

    public int? MemberTypeId { get; set; }

    public int? PrincipalId { get; set; }

    public int? RelationId { get; set; }

    public int? BenefitOptionId { get; set; }

    public DateTime? StartDate { get; set; }

    public int? StatusId { get; set; }

    public DateTime? RegistrationDate { get; set; }

    public DateTime? Datedisabled { get; set; }

    public string? Status { get; set; }

    public string? PrincipalNames { get; set; }

    public string? Fullname { get; set; }

    public string MemberNo { get; set; } = null!;

    public string? CompanyName { get; set; }

    public string? Pic { get; set; }

    public string? GenderShort { get; set; }

    public string? Relationship { get; set; }

    public DateTime? ExpiryDate { get; set; }

    public string? Plan { get; set; }

    public DateTime? IndvidualEx { get; set; }

    public string? OtherNames { get; set; }

    public byte[]? Logo { get; set; }

    public int? CardExpires { get; set; }

    public string? MainPlan { get; set; }
}
