﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwProformaProduct
{
    public int Id { get; set; }

    public string InvoiceNo { get; set; } = null!;

    public int ProductId { get; set; }

    public string Description { get; set; } = null!;

    public int? Quantity { get; set; }

    public double? UnitPrice { get; set; }

    public double? Amount { get; set; }

    public string? OtherComment { get; set; }

    public int? MemberTypeId { get; set; }

    public string MemberType { get; set; } = null!;
}
