﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VspUsersMain
{
    public int Id { get; set; }

    public string Username { get; set; } = null!;

    public string Fullname { get; set; } = null!;

    public string? AccountType { get; set; }

    public string? ContactNo { get; set; }

    public string? ServiceProvider { get; set; }

    public bool Active { get; set; }

    public int? BaseProviderId { get; set; }

    public string? Email { get; set; }

    public string Userroles { get; set; } = null!;
}
