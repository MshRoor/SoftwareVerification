﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TspClaimsDiagnosisTem
{
    public string ClaimsNo { get; set; } = null!;

    public string? Diagnosis { get; set; }

    public virtual TspClaimsHeader ClaimsNoNavigation { get; set; } = null!;
}
