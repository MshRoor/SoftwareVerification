﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblCompanyStatus
{
    public int Id { get; set; }

    public string? Status { get; set; }
}
