﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwRefundsReceipt
{
    public int Id { get; set; }

    public string ClaimsNo { get; set; } = null!;

    public int BatchNo { get; set; }

    public int? ServiceProviderId { get; set; }

    public string? ServiceProvider { get; set; }

    public string? ReceiptNo { get; set; }

    public DateTime? ReceiptDate { get; set; }

    public decimal? ReceiptAmount { get; set; }

    public string? FilePath { get; set; }

    public int? RefundReasonId { get; set; }

    public string Reason { get; set; } = null!;

    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public string? Comment { get; set; }

    public string? Inout { get; set; }

    public int? InOutId { get; set; }
}
