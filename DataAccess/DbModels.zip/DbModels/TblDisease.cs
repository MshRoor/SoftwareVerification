﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblDisease
{
    public int DiseaseId { get; set; }

    public string? Disease { get; set; }

    public string? Code { get; set; }

    public int? DiseaseGroupId { get; set; }

    public string? DiseaseGroupCode { get; set; }

    public string? BlockCode { get; set; }

    public string? ChapterId { get; set; }

    public string? BlockId { get; set; }

    public string? Level { get; set; }

    public string? PlaceOfClass { get; set; }

    public string? TypeOfCode { get; set; }

    public string? Code1 { get; set; }

    public string? Code2 { get; set; }

    public string? Field11 { get; set; }

    public string? Field12 { get; set; }

    public string? Field13 { get; set; }

    public string? Field14 { get; set; }

    public int? Used { get; set; }

    public virtual ICollection<TblClaimsHeaderXDisease> TblClaimsHeaderXDiseases { get; set; } = new List<TblClaimsHeaderXDisease>();

    public virtual ICollection<TspClaimsHeaderXDisease> TspClaimsHeaderXDiseases { get; set; } = new List<TspClaimsHeaderXDisease>();
}
