﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwRxClaimsDiagnosis
{
    public string? ProcessClaimNo { get; set; }

    public int DiseaseId { get; set; }

    public string? DiseaseCode { get; set; }

    public int? BuildStatus { get; set; }

    public int RowId { get; set; }
}
