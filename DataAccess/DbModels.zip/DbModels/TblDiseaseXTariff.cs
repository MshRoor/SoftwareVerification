﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblDiseaseXTariff
{
    public int RowId { get; set; }

    public int? DiseaseId { get; set; }

    public int? TariffId { get; set; }

    public DateTime? CreatedDate { get; set; }
}
