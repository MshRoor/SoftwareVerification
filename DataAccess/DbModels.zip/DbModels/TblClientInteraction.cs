﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblClientInteraction
{
    public int Id { get; set; }

    public DateTime? EventDate { get; set; }

    public string? Venue { get; set; }

    public string? Participants { get; set; }

    public string? Issues { get; set; }

    public string? Recommendations { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }
}
