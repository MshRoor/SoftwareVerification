﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblProductLine
{
    public int Id { get; set; }

    public string ProductLine { get; set; } = null!;
}
