﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblTariffXRejectionComment
{
    public int TariffXRejectionCommentId { get; set; }

    public string? TariffXRejectionComments { get; set; }

    public int? CommentLocation { get; set; }

    public int? FacilityTypeId { get; set; }

    public bool? ReturnToHsp { get; set; }

    public int? Award0 { get; set; }

    public int? RefundComment { get; set; }

    public int? ApplyOn { get; set; }
}
