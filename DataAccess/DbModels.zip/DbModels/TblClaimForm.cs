﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblClaimForm
{
    public int Id { get; set; }

    public string ClaimsNo { get; set; } = null!;

    public string ImagePath { get; set; } = null!;

    public DateTime? DateStamp { get; set; }

    public virtual TblClaimsHeader ClaimsNoNavigation { get; set; } = null!;
}
