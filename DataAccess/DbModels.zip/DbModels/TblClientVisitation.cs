﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblClientVisitation
{
    public int Id { get; set; }

    public int? CompanyId { get; set; }

    public string? VisitType { get; set; }

    public DateTime? VisitDate { get; set; }

    public string? ClientRep { get; set; }

    public string? Nmirep { get; set; }

    public string? Issues { get; set; }

    public string? Resolutions { get; set; }

    public string? Feedback { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }
}
