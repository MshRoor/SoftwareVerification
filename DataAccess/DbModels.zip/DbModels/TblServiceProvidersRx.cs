﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblServiceProvidersRx
{
    public int RowId { get; set; }

    public string? FacilityName { get; set; }

    public int ProviderId { get; set; }

    public int? ProviderIdMaster { get; set; }

    public double? LastSerialNumber { get; set; }

    public string? InsCompany { get; set; }

    public DateTime? ActivationDate { get; set; }

    public DateTime? ActivationTime { get; set; }
}
