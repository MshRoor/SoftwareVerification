﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblRefundsReceipt
{
    public int Id { get; set; }

    public string ClaimsNo { get; set; } = null!;

    public int BatchNo { get; set; }

    public int? ServiceProviderId { get; set; }

    public string? ReceiptNo { get; set; }

    public DateTime? ReceiptDate { get; set; }

    public decimal? ReceiptAmount { get; set; }

    public string? FilePath { get; set; }

    public int? RefundReasonId { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public string? Comment { get; set; }

    public string? UpdatedBy { get; set; }

    public DateTime? UpdatedDate { get; set; }

    public virtual TblClaimsBatch BatchNoNavigation { get; set; } = null!;

    public virtual TblServiceProvidersRefund? ServiceProvider { get; set; }

    public virtual ICollection<TblRefundsPrescription> TblRefundsPrescriptions { get; set; } = new List<TblRefundsPrescription>();
}
