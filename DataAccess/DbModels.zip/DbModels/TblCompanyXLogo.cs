﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblCompanyXLogo
{
    public int RowId { get; set; }

    public int? CompanyId { get; set; }

    public byte[]? Logo { get; set; }
}
