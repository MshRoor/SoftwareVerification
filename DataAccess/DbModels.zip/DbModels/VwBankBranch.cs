﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwBankBranch
{
    public int BranchId { get; set; }

    public string BranchName { get; set; } = null!;

    public int BankId { get; set; }

    public string Bank { get; set; } = null!;

    public string SortCode { get; set; } = null!;
}
