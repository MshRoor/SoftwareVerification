﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class RxProvider
{
    public double? Id { get; set; }

    public double? ServerId { get; set; }

    public string? FacilityNumber { get; set; }

    public string? FacilityName { get; set; }

    public string? FacilityLocation { get; set; }

    public string? FacilityTelNumber { get; set; }

    public string? FacilityTelNumber2 { get; set; }

    public string? FacilityContactPerson { get; set; }

    public string? FacilityContactTel { get; set; }

    public string? FacilityRegion { get; set; }

    public string? RxZone { get; set; }

    public string? Area { get; set; }

    public string? SubArea { get; set; }

    public string? FacilityPhoto { get; set; }

    public string? Cordinate { get; set; }

    public string? Latitude { get; set; }

    public string? Longitude { get; set; }

    public double? AverageRates { get; set; }

    public string? FacilityStatus { get; set; }

    public string? FacilityType { get; set; }

    public double? ProviderId { get; set; }

    public double? ProviderIdMaster { get; set; }

    public string? TypeOfFacility { get; set; }

    public DateTime? DatetimeActivated { get; set; }

    public string? Version { get; set; }

    public string? OutOfNetwork { get; set; }

    public double? TaxRate { get; set; }
}
