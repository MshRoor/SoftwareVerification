﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TspClaimStatusInfo
{
    public int Id { get; set; }

    public string ClaimsNo { get; set; } = null!;

    public int StatusId { get; set; }

    public int? UserId { get; set; }

    public DateTime? DateStamp { get; set; }

    public virtual TspClaimsHeader ClaimsNoNavigation { get; set; } = null!;

    public virtual TspClaimStatus Status { get; set; } = null!;
}
