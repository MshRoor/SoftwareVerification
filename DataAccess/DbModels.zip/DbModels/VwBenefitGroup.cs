﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwBenefitGroup
{
    public int Id { get; set; }

    public string BenefitGroup { get; set; } = null!;

    public int? BenefitParentId { get; set; }

    public string ParentName { get; set; } = null!;

    public string? CreatedBy { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? UpdatedBy { get; set; }
}
