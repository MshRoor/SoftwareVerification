﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblCardPrinting
{
    public int Id { get; set; }

    public int? MemberId { get; set; }

    public DateTime? DatePrinted { get; set; }

    public int? UserId { get; set; }

    public int? PrintType { get; set; }

    public string? SerialNo { get; set; }
}
