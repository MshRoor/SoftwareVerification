﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwDiseaseXTariff
{
    public int RowId { get; set; }

    public int? DiseaseId { get; set; }

    public int? DiseaseGroupId { get; set; }

    public int? TariffId { get; set; }

    public string? TariffCode { get; set; }

    public string? TariffName { get; set; }

    public int? ServiceId { get; set; }

    public string? ServiceName { get; set; }
}
