﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblMonthlyUsageHrportal
{
    public int Id { get; set; }

    public int? UsageMonth { get; set; }

    public int? UsageYear { get; set; }

    public string? UsagePeriod { get; set; }

    public int? Companies { get; set; }

    public int? Membership { get; set; }

    public int? Refund { get; set; }

    public int? Complaint { get; set; }

    public int? Utilization { get; set; }

    public string? Remarks { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }
}
