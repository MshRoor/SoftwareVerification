﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblServiceType
{
    public int Id { get; set; }

    public string? ServiceType { get; set; }

    public string? Service { get; set; }

    public int? StatusId { get; set; }
}
