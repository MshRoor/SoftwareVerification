﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwServiceProviderXTariffXPrice
{
    public int RowId { get; set; }

    public int ServiceProviderId { get; set; }

    public int TariffId { get; set; }

    public decimal? UnitCost { get; set; }

    public DateTime? EffectiveDate { get; set; }

    public DateTime EndDate { get; set; }

    public string? TariffName { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? CreatedDate { get; set; }
}
