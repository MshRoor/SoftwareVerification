﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblHealthTalk
{
    public int Id { get; set; }

    public int? CompanyId { get; set; }

    public DateTime? TalkDate { get; set; }

    public string? Topic { get; set; }

    public string? ResourcePerson { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }
}
