﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblOwnershipType
{
    public int Id { get; set; }

    public string? Ownership { get; set; }
}
