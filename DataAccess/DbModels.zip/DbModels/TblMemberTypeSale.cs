﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblMemberTypeSale
{
    public int Id { get; set; }

    public string MemberType { get; set; } = null!;
}
