﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwMember
{
    public int Id { get; set; }

    public string MembershipNo { get; set; } = null!;

    public string? EmpNo { get; set; }

    public int? CompanyId { get; set; }

    public string? CompanyName { get; set; }

    public int? GenderId { get; set; }

    public string? Gender { get; set; }

    public int? TitleId { get; set; }

    public string? Title { get; set; }

    public string? Surname { get; set; }

    public string? FirstName { get; set; }

    public string? Fname { get; set; }

    public string? OtherName { get; set; }

    public string? Fullname { get; set; }

    public DateOnly? Dob { get; set; }

    public int? MaritalId { get; set; }

    public string? MaritalStatus { get; set; }

    public int? OccupationId { get; set; }

    public string? Occupation { get; set; }

    public string? Nhisno { get; set; }

    public string? Email { get; set; }

    public string? Mphone { get; set; }

    public string? Hphone { get; set; }

    public int? MemberTypeId { get; set; }

    public string? MemberType { get; set; }

    public int? PrincipalId { get; set; }

    public string? PrincipalName { get; set; }

    public int? RelationId { get; set; }

    public string? Relationship { get; set; }

    public int? BenefitOptionId { get; set; }

    public string? PlanName { get; set; }

    public string? PlanShortName { get; set; }

    public DateTime? StartDate { get; set; }

    public int? StatusId { get; set; }

    public string? Status { get; set; }

    public DateTime? RegistrationDate { get; set; }

    public DateTime? Datedisabled { get; set; }

    public double? UniqueId { get; set; }

    public int? Printed { get; set; }

    public DateTime? IndvidualEx { get; set; }

    public string? EmployeeStatus { get; set; }

    public int? InfoUploaded { get; set; }

    public DateTime? UploadDateTime { get; set; }

    public string? Picpath { get; set; }

    public string? CardPin { get; set; }

    public int? OnlineMemberId { get; set; }

    public int? RxOnlineId { get; set; }

    public int? SentSms { get; set; }

    public string? HronlineId { get; set; }

    public string? HronlinePrinId { get; set; }

    public int? HronlineUpload { get; set; }

    public string? MemberNo { get; set; }

    public int? MyHealthRegistId { get; set; }

    public int? MyHealthPrincipalId { get; set; }

    public int? Updated { get; set; }

    public int? MailSent { get; set; }

    public bool? IsGroupPolicy { get; set; }

    public int? ActualStatusId { get; set; }

    public string ActualStatus { get; set; } = null!;

    public string? NewMember { get; set; }

    public string? OtherNames { get; set; }

    public string? GenderShort { get; set; }

    public DateTime? ExpiryDate { get; set; }

    public bool? ReplaceMemberNo { get; set; }

    public string? NationalIdno { get; set; }

    public int? ActualMemberTypeId { get; set; }

    public string? ActualMemberType { get; set; }

    public int? CardExpires { get; set; }

    public DateTime? MemberRegstDate { get; set; }

    public int? MainPlanId { get; set; }

    public string? MainPlanName { get; set; }

    public string? PrincipalPhoneNo { get; set; }

    public bool? HpAngina { get; set; }

    public bool? HpAutoimmune { get; set; }

    public bool? HpBackNeck { get; set; }

    public bool? HpCancerTumours { get; set; }

    public bool? HpCardiovascular { get; set; }

    public bool? HpChronicBronchitis { get; set; }

    public bool? HpChronicRespiratory { get; set; }

    public bool? HpCongenitalHeart { get; set; }

    public bool? HpCysticFibrosis { get; set; }

    public bool? HpDiabetes { get; set; }

    public bool? HpDigestiveSystem { get; set; }

    public bool? HpEmbolism { get; set; }

    public bool? HpEmphysema { get; set; }

    public bool? HpEndocrine { get; set; }

    public bool? HpFibroid { get; set; }

    public bool? HpGallBladder { get; set; }

    public bool? HpGout { get; set; }

    public bool? HpHernia { get; set; }

    public bool? HpHypertension { get; set; }

    public bool? HpIntestinalFibrosis { get; set; }

    public bool? HpKidney { get; set; }

    public bool? HpLeukemia { get; set; }

    public bool? HpLiver { get; set; }

    public bool? HpLung { get; set; }

    public bool? HpMusculoskeletal { get; set; }

    public bool? HpNephritis { get; set; }

    public bool? HpPregnant { get; set; }

    public bool? HpOthers { get; set; }

    public string? HpMoreInfo { get; set; }
}
