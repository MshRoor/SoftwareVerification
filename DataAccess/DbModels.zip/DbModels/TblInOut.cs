﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblInOut
{
    public int Id { get; set; }

    public string? Inout { get; set; }

    public virtual ICollection<TblCompanyPlanMasterLimitRenewal> TblCompanyPlanMasterLimitRenewals { get; set; } = new List<TblCompanyPlanMasterLimitRenewal>();

    public virtual ICollection<TblCompanyPlanMasterLimitSale> TblCompanyPlanMasterLimitSales { get; set; } = new List<TblCompanyPlanMasterLimitSale>();

    public virtual ICollection<TblCompanyPlanMasterLimit> TblCompanyPlanMasterLimits { get; set; } = new List<TblCompanyPlanMasterLimit>();

    public virtual ICollection<TblPlanMasterLimit> TblPlanMasterLimits { get; set; } = new List<TblPlanMasterLimit>();
}
