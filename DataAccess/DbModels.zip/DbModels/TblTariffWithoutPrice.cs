﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblTariffWithoutPrice
{
    public int Id { get; set; }

    public int? DrugId { get; set; }

    public DateTime? DateStamp { get; set; }

    public int? PspList { get; set; }

    public int? MobimedList { get; set; }
}
