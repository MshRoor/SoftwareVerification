﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblServiceProviderXService
{
    public int RowId { get; set; }

    public int? ServiceProviderId { get; set; }

    public int? ServiceClassRowId { get; set; }

    public int? ServiceId { get; set; }

    public DateTime? EffectiveDate { get; set; }

    public DateTime? EndDate { get; set; }

    public int? Status { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }
}
