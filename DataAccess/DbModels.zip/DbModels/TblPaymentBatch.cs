﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblPaymentBatch
{
    public int Id { get; set; }

    public int BankId { get; set; }
}
