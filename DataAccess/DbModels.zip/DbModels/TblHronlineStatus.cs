﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblHronlineStatus
{
    public int Id { get; set; }

    public string Status { get; set; } = null!;
}
