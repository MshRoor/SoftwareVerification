﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwBatchStatusInfo
{
    public int Id { get; set; }

    public int BatchNo { get; set; }

    public int StatusId { get; set; }

    public string Status { get; set; } = null!;

    public int? UserId { get; set; }

    public string? Username { get; set; }

    public DateTime? DateStamp { get; set; }
}
