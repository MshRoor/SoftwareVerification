﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblClaimsApprovedHsp
{
    public int AutoId { get; set; }

    public int BatchNo { get; set; }

    public int? NoOfClaims { get; set; }

    public decimal? AmountClaimed { get; set; }

    public DateTime? DateOfClaim { get; set; }

    public string? ServiceProvider { get; set; }

    public string? CustomerId { get; set; }

    public int? ServiceProvideId { get; set; }

    public string? MonthOfClaim { get; set; }

    public decimal? Claimed { get; set; }

    public decimal? Awarded { get; set; }

    public decimal? Withold { get; set; }

    public decimal? Building { get; set; }

    public decimal? AmountDue { get; set; }

    public string WithHoldingRate { get; set; } = null!;

    public decimal? Rejections { get; set; }

    public decimal? OverStatement { get; set; }

    public int? Tpa { get; set; }

    public string BatchType { get; set; } = null!;

    public bool? Processed { get; set; }

    public DateTime? ProcessedDate { get; set; }

    public string? ProcessedBy { get; set; }

    public DateTime? CreatedDate { get; set; }

    public bool? OnlinePush { get; set; }
}
