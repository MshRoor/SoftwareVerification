﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwAdviceSlip
{
    public int RowId { get; set; }

    public string ClaimsNo { get; set; } = null!;

    public int TariffId { get; set; }

    public double? Qty { get; set; }

    public double? QtyPrescribed { get; set; }

    public decimal? Claimed { get; set; }

    public decimal? Awarded { get; set; }

    public decimal? ApprovedAmount { get; set; }

    public int? RxRowId { get; set; }

    public decimal? UnitPrice { get; set; }

    public string? TariffName { get; set; }

    public int TariffXRejectionCommentId { get; set; }

    public string? TariffXRejectionComments { get; set; }

    public bool? RejectionAccepted { get; set; }

    public DateTime? StampDate { get; set; }

    public int? UserId { get; set; }

    public bool? Confirmed { get; set; }

    public decimal? RejectedAmount { get; set; }

    public int? ClaimsDetailsId { get; set; }

    public int? OnlineStatus { get; set; }

    public int? CommentLocation { get; set; }

    public int? ClaimsBatchNo { get; set; }

    public int? NmhProviderId { get; set; }

    public int? AttendMonth { get; set; }

    public int? AttendYear { get; set; }

    public int? Tpa { get; set; }

    public DateTime DateofAttendance { get; set; }

    public int MemberId { get; set; }

    public string? Inout { get; set; }

    public DateTime? DateOfClaim { get; set; }

    public decimal? ProviderAmountClaimed { get; set; }

    public decimal? SysAmountClaimed { get; set; }

    public decimal? SysAmountAwarded { get; set; }

    public string? NotAMember { get; set; }

    public string ServiceProvider { get; set; } = null!;

    public string? ServiceType { get; set; }

    public int? ServiceProviderId { get; set; }

    public string? Diagnosis { get; set; }

    public string MembershipNo { get; set; } = null!;

    public string? CompanyName { get; set; }

    public string? Fullname { get; set; }

    public DateTime? Dob { get; set; }

    public string? PlanName { get; set; }

    public DateOnly? DatePrescribed { get; set; }

    public string? Gender { get; set; }

    public decimal? Diff { get; set; }

    public int? StatusId { get; set; }

    public int? ServiceId { get; set; }

    public string? ServiceName { get; set; }

    public string? MemberAge { get; set; }

    public string? BenefitOption { get; set; }

    public string? AdviceMemberName { get; set; }
}
