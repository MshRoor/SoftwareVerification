﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblHronline
{
    public int RowId { get; set; }

    public int? RowId1 { get; set; }

    public string? PrincipalId { get; set; }

    public string? ImgLink { get; set; }

    public string? StaffId { get; set; }

    public string? MandateNo { get; set; }

    public string? Surname { get; set; }

    public string? Firstname { get; set; }

    public string? OtherNames { get; set; }

    public DateTime? Dob { get; set; }

    public string? Gender { get; set; }

    public string? PrimaryPhoneNo1 { get; set; }

    public string? PhoneNo2 { get; set; }

    public string? Email { get; set; }

    public string? NhisNo { get; set; }

    public string? Region { get; set; }

    public string? District { get; set; }

    public string? Branch { get; set; }

    public string? RelationshipType { get; set; }

    public string? MemberType { get; set; }

    public string? Role { get; set; }

    public string? ConfirmRecord { get; set; }

    public string? PrincipalName { get; set; }

    public string? Pin { get; set; }

    public string? IsEdit { get; set; }

    public string? CompanyName { get; set; }

    public string? ComapnyId { get; set; }

    public string? Registrar { get; set; }

    public string? PlanName { get; set; }

    public string? PlanId { get; set; }

    public DateTime? DateTimeCreated { get; set; }

    public DateTime? DateStemp { get; set; }

    public int? NmhStatus { get; set; }

    public bool? ImageDownloaded { get; set; }

    public string? Imagepath { get; set; }

    public string? DataSource { get; set; }

    public string? GhanaCard { get; set; }

    public int? RelationshipTypeId { get; set; }

    public DateTime? ApprovedStartDate { get; set; }
}
