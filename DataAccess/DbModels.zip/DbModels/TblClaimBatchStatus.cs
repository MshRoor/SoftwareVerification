﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblClaimBatchStatus
{
    public int Id { get; set; }

    public string Status { get; set; } = null!;

    public int? Stages { get; set; }

    public int? Dpt { get; set; }

    public string? ProcessStage { get; set; }

    public int? StageId { get; set; }

    public int? StatusId { get; set; }

    public int? BbgSt { get; set; }

    public virtual ICollection<TblClaimsBatchStatusInfo> TblClaimsBatchStatusInfos { get; set; } = new List<TblClaimsBatchStatusInfo>();
}
