﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblPhoneNumberUpdate
{
    public int RowId { get; set; }

    public int? RowIdOnline { get; set; }

    public int? MemberId { get; set; }

    public string? NewPhone { get; set; }

    public string? OtherPhone { get; set; }

    public int? IsUpdate { get; set; }

    public DateTime? DateStamp { get; set; }
}
