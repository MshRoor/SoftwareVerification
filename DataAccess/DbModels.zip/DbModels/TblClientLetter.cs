﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblClientLetter
{
    public int Id { get; set; }

    public int? CrofficerId { get; set; }

    public string? Ltype { get; set; }

    public string? Lmode { get; set; }

    public int? Lmonth { get; set; }

    public int? Lyear { get; set; }

    public string? Lperiod { get; set; }

    public string? Topic { get; set; }

    public DateTime? DueDate { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }
}
