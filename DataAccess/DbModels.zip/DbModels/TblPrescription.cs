﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblPrescription
{
    public int RowId { get; set; }

    public int? Id { get; set; }

    public string? InsCompany { get; set; }

    public string? ProcessClaimNo { get; set; }

    public string? PrescriptionDocument { get; set; }

    public string? Description { get; set; }

    public int? ProviderId { get; set; }

    public int? ProviderUserId { get; set; }

    public string? Status { get; set; }

    public int? UpdateClaimHeaderAvaliable { get; set; }

    public bool? ImageDownloaded { get; set; }

    public string? ImagePath { get; set; }

    public DateTime? DateStemp { get; set; }

    public bool? PrescriptionChecked { get; set; }
}
