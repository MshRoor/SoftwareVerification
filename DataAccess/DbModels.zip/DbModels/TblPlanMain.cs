﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblPlanMain
{
    public int Id { get; set; }

    public string MainPlanName { get; set; } = null!;

    public virtual ICollection<TblPlan> TblPlans { get; set; } = new List<TblPlan>();
}
