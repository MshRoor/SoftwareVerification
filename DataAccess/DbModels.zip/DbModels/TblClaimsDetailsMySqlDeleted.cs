﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblClaimsDetailsMySqlDeleted
{
    public int RowId { get; set; }

    public string? Id { get; set; }

    public string? ServerId { get; set; }

    public string? ProviderDataId { get; set; }

    public string? ProviderId { get; set; }

    public string? MemberNo { get; set; }

    public string? ProcessClaimNo { get; set; }

    public int? IsDeleted { get; set; }
}
