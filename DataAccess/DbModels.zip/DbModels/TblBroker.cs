﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblBroker
{
    public int Id { get; set; }

    public string BrokerName { get; set; } = null!;

    public string? ContactPerson { get; set; }

    public string? ContactNo { get; set; }

    public string? Email { get; set; }

    public DateTime? JoinDate { get; set; }

    public string? Address { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? CreatedDate { get; set; }
}
