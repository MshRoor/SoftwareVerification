﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class ClaimsComment
{
    public string? ProcessClaimNo { get; set; }

    public string? Comment { get; set; }
}
