﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblBenefitXTariff
{
    public int Id { get; set; }

    public int BenefitId { get; set; }

    public int TariffId { get; set; }

    public DateTime? CreatedDate { get; set; }

    public int? UserId { get; set; }

    public DateTime? UpdatedDate { get; set; }

    public virtual TblBenefit Benefit { get; set; } = null!;

    public virtual TblTariff Tariff { get; set; } = null!;
}
