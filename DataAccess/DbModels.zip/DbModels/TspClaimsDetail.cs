﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TspClaimsDetail
{
    public int Id { get; set; }

    public string ClaimsNo { get; set; } = null!;

    public int ProductId { get; set; }

    public double? Qty { get; set; }

    public double? QtyPrescribed { get; set; }

    public decimal? Claimed { get; set; }

    public DateTime? StampDate { get; set; }

    public int? PrescribeDrug { get; set; }

    public DateOnly? DatePrescribed { get; set; }

    public decimal? UnitPrice { get; set; }

    public int UserId { get; set; }

    public virtual TblTariff Product { get; set; } = null!;
}
