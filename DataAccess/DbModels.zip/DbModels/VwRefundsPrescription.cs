﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwRefundsPrescription
{
    public int Id { get; set; }

    public string ClaimsNo { get; set; } = null!;

    public int? ServiceProviderId { get; set; }

    public string? ServiceProvider { get; set; }

    public DateTime? FileDate { get; set; }

    public string? FilePath { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }
}
