﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwProformaInvoice
{
    public int AutoId { get; set; }

    public string InvoiceNo { get; set; } = null!;

    public DateTime InvoiceDate { get; set; }

    public int CustomerId { get; set; }

    public string CustomerName { get; set; } = null!;

    public string? CustomerAddress { get; set; }

    public string? CustomerState { get; set; }

    public string? CustomerPhone { get; set; }

    public string? CustomerAttn { get; set; }

    public string? SourceOfBusiness { get; set; }

    public int? BrokerId { get; set; }

    public string? BrokerName { get; set; }

    public string? ContactNo { get; set; }

    public int? CoverPeriod { get; set; }

    public string? PreparedBy { get; set; }

    public string? AuthorizedBy { get; set; }

    public string? BrokerContactPerson { get; set; }

    public string? BrokerContactNo { get; set; }

    public DateTime? DateCreated { get; set; }

    public int? InvoiceMembers { get; set; }

    public decimal? PremiumAmount { get; set; }

    public decimal? MembershipFee { get; set; }

    public decimal? InvoiceAmount { get; set; }

    public bool? Approved { get; set; }
}
