﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VspClaimsHeaderXDisease
{
    public int RowId { get; set; }

    public string ClaimsNo { get; set; } = null!;

    public int? DiseaseId { get; set; }

    public string? Disease { get; set; }

    public string? Code { get; set; }

    public int? DiseaseGroupId { get; set; }

    public bool? Rejected { get; set; }
}
