﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblDiseaseParentGroup
{
    public int DiseaseParentGroupId { get; set; }

    public string DiseaseParentGroupName { get; set; } = null!;

    public string DiseaseParentCode { get; set; } = null!;
}
