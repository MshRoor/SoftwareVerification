﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblPlan
{
    public int Id { get; set; }

    public string PlanName { get; set; } = null!;

    public string? Prefix { get; set; }

    public decimal? Premium { get; set; }

    public bool? Active { get; set; }

    public bool? IsFamily { get; set; }

    public int? MainPlanId { get; set; }

    public virtual TblPlanMain? MainPlan { get; set; }

    public virtual ICollection<TblCompanyPlanMasterLimitRenewal> TblCompanyPlanMasterLimitRenewals { get; set; } = new List<TblCompanyPlanMasterLimitRenewal>();

    public virtual ICollection<TblCompanyPlanMasterLimitSale> TblCompanyPlanMasterLimitSales { get; set; } = new List<TblCompanyPlanMasterLimitSale>();

    public virtual ICollection<TblCompanyPlanMasterLimit> TblCompanyPlanMasterLimits { get; set; } = new List<TblCompanyPlanMasterLimit>();

    public virtual ICollection<TblPlanBenefitGroup> TblPlanBenefitGroups { get; set; } = new List<TblPlanBenefitGroup>();

    public virtual ICollection<TblPlanBenefitLimit> TblPlanBenefitLimits { get; set; } = new List<TblPlanBenefitLimit>();

    public virtual ICollection<TblPlanBenefitParent> TblPlanBenefitParents { get; set; } = new List<TblPlanBenefitParent>();

    public virtual ICollection<TblPlanMasterLimit> TblPlanMasterLimits { get; set; } = new List<TblPlanMasterLimit>();
}
