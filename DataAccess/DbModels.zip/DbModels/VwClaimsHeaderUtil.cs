﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwClaimsHeaderUtil
{
    public int Id { get; set; }

    public DateTime DateofAttendance { get; set; }

    public string ClaimsNo { get; set; } = null!;

    public int MemberId { get; set; }

    public int? ClaimsBatchNo { get; set; }

    public int? ServiceProviderId { get; set; }

    public string? ServiceProvider { get; set; }

    public DateTime? DateStamp { get; set; }

    public int? InOutId { get; set; }

    public string? Inout { get; set; }

    public decimal? ProviderAmountClaimed { get; set; }

    public decimal? SysAmountClaimed { get; set; }

    public decimal? SysAmountAwarded { get; set; }

    public int? ClaimType { get; set; }

    public string? Diagnosis { get; set; }

    public DateTime? DateOfClaim { get; set; }

    public string MembershipNo { get; set; } = null!;

    public int? CompanyId { get; set; }

    public string? CompanyName { get; set; }

    public string? Gender { get; set; }

    public string? Title { get; set; }

    public string? Fullname { get; set; }

    public DateOnly? Dob { get; set; }

    public string? MaritalStatus { get; set; }

    public string? Occupation { get; set; }

    public string? MemberType { get; set; }

    public string? PrincipalName { get; set; }

    public string? Relationship { get; set; }

    public string? PlanName { get; set; }

    public DateTime? Datedisabled { get; set; }

    public int? RxProviderId { get; set; }

    public DateTime? StampDate { get; set; }

    public string? ServiceType { get; set; }

    public string? Service { get; set; }

    public string? Region { get; set; }

    public string? Status { get; set; }

    public string? PlanShortName { get; set; }
}
