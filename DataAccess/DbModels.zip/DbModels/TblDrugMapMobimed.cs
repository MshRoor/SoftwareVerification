﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblDrugMapMobimed
{
    public int Id { get; set; }

    public int TariffId { get; set; }

    public int DrugId { get; set; }

    public DateTime? DateStamp { get; set; }
}
