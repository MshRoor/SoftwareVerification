﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblPlanBenefitGroup
{
    public int Id { get; set; }

    public int PlanId { get; set; }

    public int BenefitGroupId { get; set; }

    public decimal? Limit { get; set; }

    public virtual TblBenefitGroup BenefitGroup { get; set; } = null!;

    public virtual TblPlan Plan { get; set; } = null!;
}
