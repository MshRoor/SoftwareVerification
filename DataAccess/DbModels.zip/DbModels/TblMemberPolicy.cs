﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblMemberPolicy
{
    public int Id { get; set; }

    public int MemberId { get; set; }

    public int CompanyId { get; set; }

    public string PolicyNo { get; set; } = null!;

    public int PlanId { get; set; }

    public DateTime StartDate { get; set; }

    public DateTime? EndDate { get; set; }

    public int? UserId { get; set; }

    public DateTime? DateStamp { get; set; }

    public bool? Customized { get; set; }

    public string? CustomizedBy { get; set; }

    public DateTime? CustomizedDate { get; set; }
}
