﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwClaimsDetail
{
    public int Id { get; set; }

    public string ClaimsNo { get; set; } = null!;

    public int ProductId { get; set; }

    public string? TariffName { get; set; }

    public double? Qty { get; set; }

    public double? QtyPrescribed { get; set; }

    public decimal? Claimed { get; set; }

    public decimal? Awarded { get; set; }

    public bool? Rejected { get; set; }

    public bool? Verify { get; set; }

    public int? VettingId { get; set; }

    public string? TariffXRejectionComments { get; set; }

    public DateTime? StampDate { get; set; }

    public decimal? Diff { get; set; }

    public decimal? ApprovedAmount { get; set; }

    public int? Released { get; set; }

    public int? RxRowId { get; set; }

    public decimal? UnitPrice { get; set; }

    public bool? Generic { get; set; }

    public bool? Branded { get; set; }

    public string? TypeName { get; set; }

    public decimal? ReviewAwarded { get; set; }

    public int? ReviewStatus { get; set; }
}
