﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblDiseaseGroup
{
    public int DiseaseGroupId { get; set; }

    public string Disease { get; set; } = null!;

    public string? DiseaseGroupCode { get; set; }

    public int? DiseaseMainGroupId { get; set; }

    public string? DiseaseMainGroupCode { get; set; }

    public bool? Exclusion { get; set; }

    public int? AgeLowerLimit { get; set; }

    public int? AgeUpperLimit { get; set; }

    public int? GenderSpecific { get; set; }
}
