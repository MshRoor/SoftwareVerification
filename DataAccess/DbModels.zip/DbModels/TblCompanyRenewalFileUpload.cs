﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblCompanyRenewalFileUpload
{
    public int Id { get; set; }

    public int CompanyId { get; set; }

    public string PolicyCode { get; set; } = null!;

    public string FileName { get; set; } = null!;

    public string? FileType { get; set; }

    public string? FilePath { get; set; }

    public string? ReportType { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? CreatedDate { get; set; }
}
