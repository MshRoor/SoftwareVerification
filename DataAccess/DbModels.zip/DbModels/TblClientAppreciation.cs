﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblClientAppreciation
{
    public int Id { get; set; }

    public string? RewardType { get; set; }

    public string? Names { get; set; }

    public string? Criteria { get; set; }

    public string? AwardType { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }
}
