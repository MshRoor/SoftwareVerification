﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblClaimsAvailable
{
    public int Id { get; set; }

    public DateTime? DateofAttendance { get; set; }

    public int? MemberId { get; set; }

    public int? ClaimsBatchNo { get; set; }

    public string? NotAMember { get; set; }

    public string? Inout { get; set; }

    public DateTime? DateOfClaim { get; set; }

    public double? SysAmountClaimed { get; set; }

    public double? SysAmountAwarded { get; set; }

    public string? ServiceType { get; set; }

    public string? ServiceProvider { get; set; }

    public int? ServiceProvideId { get; set; }

    public double? ProviderAmountClaimed { get; set; }

    public string? Diagnosis { get; set; }

    public string? FullName { get; set; }

    public string? Company { get; set; }

    public DateTime? Dob { get; set; }

    public string? Plan { get; set; }

    public int RowId { get; set; }

    public string? ClaimsNo { get; set; }

    public string? TariffName { get; set; }

    public string? TariffXRejectionComments { get; set; }

    public DateTime? StampDate { get; set; }

    public int? CommentLocation { get; set; }

    public double? Claimed { get; set; }

    public int? Qty { get; set; }

    public double? ApprovedAmount { get; set; }

    public string? PrescribedDrug { get; set; }

    public DateOnly? DatePrescribed { get; set; }

    public int? QtyPrescribed { get; set; }

    public string? AdviceMemberName { get; set; }

    public string? Gender { get; set; }

    public DateOnly? Dob2 { get; set; }

    public string? MemberAge { get; set; }

    public string? BenefitOption { get; set; }

    public double? Diff { get; set; }

    public string? ServiceProviderBatch { get; set; }

    public int? TariffXRejectionCommentId { get; set; }

    public int? ClaimsDetailsId { get; set; }

    public int? DocId { get; set; }

    public string? DocResponse { get; set; }

    public string? DocComment { get; set; }

    public bool? Vetted { get; set; }

    public bool? OnlinePush { get; set; }

    public bool? NmhPull { get; set; }

    public DateTime? DatePushed { get; set; }
}
