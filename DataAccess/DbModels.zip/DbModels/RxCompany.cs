﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class RxCompany
{
    public double? Id { get; set; }

    public string? Company { get; set; }

    public string? CompanyId { get; set; }

    public string? CompanyCode { get; set; }

    public DateTime? PolicyStartDate { get; set; }

    public DateTime? PolicyEndDate { get; set; }

    public DateTime? StatusUpdateTime { get; set; }

    public string? CompanyType { get; set; }

    public double? GroupType { get; set; }

    public string? PrefixCode { get; set; }

    public string? ContactPerson { get; set; }

    public string? ContactEmail { get; set; }

    public string? CompanyStatus { get; set; }

    public string? ExchangeRate { get; set; }

    public string? IdInscompany { get; set; }
}
