﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblDiseaseMainGroup
{
    public int DiseaseMainGroupId { get; set; }

    public string DiseaseMainGroupName { get; set; } = null!;

    public int DiseaseParentGroupId { get; set; }

    public string? DiseaseParentCode { get; set; }

    public string? DiseaseBlockCode { get; set; }

    public string? Field2 { get; set; }
}
