﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwCompanyPlanBenefitParent
{
    public int Id { get; set; }

    public int PlanId { get; set; }

    public string PlanName { get; set; } = null!;

    public int BenefitParentId { get; set; }

    public string ParentName { get; set; } = null!;

    public decimal Limit { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? UpdatedBy { get; set; }

    public DateTime? UpdatedDate { get; set; }

    public int CompanyId { get; set; }

    public string PolicyCode { get; set; } = null!;

    public bool? Updated { get; set; }

    public bool? UpdatedOnline { get; set; }
}
