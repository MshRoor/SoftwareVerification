﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblCompanySalesResponse
{
    public int Id { get; set; }

    public int CompanyId { get; set; }

    public string Comment { get; set; } = null!;

    public string? CreatedBy { get; set; }

    public DateTime? CreatedDate { get; set; }

    public virtual TblCompaniesSale Company { get; set; } = null!;
}
