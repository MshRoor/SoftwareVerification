﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwClaimsHeaderBuild
{
    public int? MemberId { get; set; }

    public int? BenefitOptionId { get; set; }

    public int? CompanyId { get; set; }

    public string? ClaimsNo { get; set; }

    public DateTime? DateofAttendance { get; set; }

    public int? AttendDay { get; set; }

    public int? AttendMonth { get; set; }

    public int? AttendYear { get; set; }

    public int InOutId { get; set; }

    public double? Qty { get; set; }

    public double? UnitPrice { get; set; }

    public DateTime? AdminisionDate { get; set; }

    public DateTime? DischargeDate { get; set; }

    public int HeaderComemntId { get; set; }

    public string? FacilityName { get; set; }

    public int? NmhProviderId { get; set; }

    public int? RxMasterProviderId { get; set; }

    public int? RxProviderId { get; set; }

    public int? ClaimsHeaderStatus { get; set; }

    public string? MemberNo { get; set; }

    public int ClaimType { get; set; }

    public int RowId { get; set; }

    public int? Id { get; set; }

    public int Tpa { get; set; }

    public double? ProviderAmountClaimed { get; set; }
}
