﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblTariffDrugsGeneric
{
    public int DrugGenId { get; set; }

    public string? TariffName { get; set; }

    public int? ServiceId { get; set; }

    public int? GenderSpecific { get; set; }

    public int? AgeLower { get; set; }

    public int? AgeUpper { get; set; }

    public int? MaxIncidences { get; set; }

    public int? PerDuration { get; set; }

    public int? AnExclusion { get; set; }

    public string? TariffCode { get; set; }

    public int? PreAuthorization { get; set; }

    public int? DrugClassId { get; set; }

    public int? InOutPatient { get; set; }
}
