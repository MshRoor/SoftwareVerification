﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VvwClaimsHeader
{
    public int Id { get; set; }

    public DateTime DateofAttendance { get; set; }

    public string ClaimsNo { get; set; } = null!;

    public int MemberId { get; set; }

    public string? FullName { get; set; }

    public int? ClaimsBatchNo { get; set; }

    public string? MemberNo { get; set; }

    public int? CompanyId { get; set; }

    public string? Company { get; set; }

    public int? ServiceProviderId { get; set; }

    public string? ServiceProvider { get; set; }

    public DateTime? DateStamp { get; set; }

    public int? InOutId { get; set; }

    public string? Inout { get; set; }

    public decimal? ProviderAmountClaimed { get; set; }

    public decimal? SysAmountClaimed { get; set; }

    public decimal? SysAmountAwarded { get; set; }

    public int? ClaimType { get; set; }

    public string? Gender { get; set; }

    public DateOnly? Dob { get; set; }

    public string? Status { get; set; }

    public string? Diagnosis { get; set; }

    public string? Relationship { get; set; }

    public int? Age { get; set; }

    public string? PlanName { get; set; }

    public int? AttendMonth { get; set; }

    public int? AttendYear { get; set; }

    public int? NmhProviderId { get; set; }

    public int? Tpa { get; set; }

    public bool? Vetted { get; set; }

    public string? ProviderComment { get; set; }

    public DateOnly? AdminisionDate { get; set; }

    public DateOnly? DischargeDate { get; set; }

    public string? ConfirmedDiagnosis { get; set; }
}
