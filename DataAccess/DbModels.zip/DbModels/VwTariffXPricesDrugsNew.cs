﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwTariffXPricesDrugsNew
{
    public int TariffId { get; set; }

    public double TariffBasePrice { get; set; }

    public DateTime EffectiveDate { get; set; }

    public DateTime EndDate { get; set; }

    public int Id { get; set; }

    public int DrugId { get; set; }
}
