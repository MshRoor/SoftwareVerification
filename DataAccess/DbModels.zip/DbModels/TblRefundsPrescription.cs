﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblRefundsPrescription
{
    public int Id { get; set; }

    public string ClaimsNo { get; set; } = null!;

    public int? ServiceProviderId { get; set; }

    public DateTime? FileDate { get; set; }

    public string? FilePath { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? CreatedDate { get; set; }

    public virtual TblRefundsReceipt ClaimsNoNavigation { get; set; } = null!;

    public virtual TblServiceProvidersRefund? ServiceProvider { get; set; }
}
