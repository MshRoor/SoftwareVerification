﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblServiceProvidersAccount
{
    public int Id { get; set; }

    public string? ServiceProvider { get; set; }

    public string? Tin { get; set; }

    public int? RegionId { get; set; }

    public string? District { get; set; }

    public string? DigitalAddress { get; set; }

    public string? EmailAddress { get; set; }

    public int? BankId { get; set; }

    public int? BankBranchId { get; set; }

    public bool? Whtaxable { get; set; }

    public double? WhtaxRate { get; set; }

    public double? CommRate { get; set; }

    public string? AccountName { get; set; }

    public string? AccountNo { get; set; }

    public string? CreatedBy { get; set; }

    public bool? IsHsp { get; set; }

    public int? Hspid { get; set; }

    public int? ServiceTypeId { get; set; }

    public string? ContactNo { get; set; }

    public string? NhiacertNo { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? UpdatedBy { get; set; }

    public DateTime? UpdatedDate { get; set; }

    public string? ThymeHspId { get; set; }
}
