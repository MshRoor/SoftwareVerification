﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblClaimsHeaderXDisease
{
    public int RowId { get; set; }

    public string ClaimsNo { get; set; } = null!;

    public int? DiseaseId { get; set; }

    public bool? Rejected { get; set; }

    public virtual TblClaimsHeader ClaimsNoNavigation { get; set; } = null!;

    public virtual TblDisease? Disease { get; set; }
}
