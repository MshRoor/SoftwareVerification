﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblMemberPlanBenefitLimit
{
    public int RowId { get; set; }

    public string PolicyCode { get; set; } = null!;

    public int MemberId { get; set; }

    public int PlanId { get; set; }

    public int BenefitId { get; set; }

    public string? CoverStatus { get; set; }

    public double? CoverLimit { get; set; }

    public string? CoverComment { get; set; }

    public int? CustomBenefitTypeId { get; set; }

    public decimal? MaleCoverLimit { get; set; }

    public decimal? FemaleCoverLimit { get; set; }

    public decimal? ChildCoverLimit { get; set; }

    public decimal? AdultCoverLimit { get; set; }

    public decimal? CostPerVisit { get; set; }

    public int? Sessions { get; set; }

    public bool? Updated { get; set; }

    public string? UpdatedBy { get; set; }

    public DateTime? UpdatedDate { get; set; }

    public bool? UpdatedOnline { get; set; }
}
