﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblMonthlyUsageMobimed
{
    public int Id { get; set; }

    public int? UsageMonth { get; set; }

    public int? UsageYear { get; set; }

    public string? UsagePeriod { get; set; }

    public int? WhatsappOrders { get; set; }

    public int? MobileAppOrders { get; set; }

    public int? SuppliedOrders { get; set; }

    public string? NonSupplyReasons { get; set; }

    public int? Downloads { get; set; }

    public string? Remarks { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }
}
