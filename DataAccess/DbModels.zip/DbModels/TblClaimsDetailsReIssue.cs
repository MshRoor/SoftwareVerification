﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblClaimsDetailsReIssue
{
    public int Id { get; set; }

    public int ClaimsDetailsId { get; set; }

    public string BatchNo { get; set; } = null!;

    public string ClaimsNo { get; set; } = null!;

    public int ProductId { get; set; }

    public double? Qty { get; set; }

    public decimal? Claimed { get; set; }

    public decimal? ApprovedAmount { get; set; }

    public decimal? ReviewAwarded { get; set; }

    public int? VettingId { get; set; }

    public DateTime? StampDate { get; set; }

    public decimal? Diff { get; set; }

    public virtual TblClaimsHeader ClaimsNoNavigation { get; set; } = null!;

    public virtual TblTariff Product { get; set; } = null!;
}
