﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VvwClaimsDetailsOnline
{
    public int Id { get; set; }

    public string ClaimsNo { get; set; } = null!;

    public int ProductId { get; set; }

    public string? TariffName { get; set; }

    public double? Qty { get; set; }

    public double? QtyPrescribed { get; set; }

    public decimal? Claimed { get; set; }

    public decimal? Awarded { get; set; }

    public bool? Rejected { get; set; }

    public bool? Verify { get; set; }

    public int? VettingId { get; set; }

    public DateTime? StampDate { get; set; }

    public decimal? Diff { get; set; }

    public decimal? ApprovedAmount { get; set; }

    public int? Released { get; set; }

    public int? RxRowId { get; set; }

    public decimal? UnitPrice { get; set; }

    public string? RxItemName { get; set; }

    public int? RowId { get; set; }

    public int? TariffXRejectionCommentId { get; set; }

    public string? TariffXRejectionComments { get; set; }

    public int MemberId { get; set; }

    public int? ClaimsBatchNo { get; set; }

    public int? AttendMonth { get; set; }

    public int? AttendYear { get; set; }

    public int? NmhProviderId { get; set; }

    public DateTime DateofAttendance { get; set; }

    public int? CommentLocation { get; set; }

    public string? Diagnosis { get; set; }
}
