﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwClaimsPayment
{
    public int Id { get; set; }

    public int BatchNo { get; set; }

    public string? ChequeNo { get; set; }

    public DateTime? ChequeDate { get; set; }

    public decimal? ChequeAmount { get; set; }

    public DateTime? DateStamp { get; set; }

    public string? AmountWord { get; set; }

    public int? PayStatus { get; set; }

    public int? BankId { get; set; }

    public DateOnly? TransDate { get; set; }

    public int? Smsstatus { get; set; }

    public string Bank { get; set; } = null!;

    public int? PaymantBatchNo { get; set; }
}
