﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblBenefitParent
{
    public int Id { get; set; }

    public string ParentName { get; set; } = null!;

    public string? CreatedBy { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? UpdatedBy { get; set; }

    public DateTime? UpdatedDate { get; set; }

    public int? RxParentId { get; set; }

    public virtual ICollection<TblBenefitGroup> TblBenefitGroups { get; set; } = new List<TblBenefitGroup>();

    public virtual ICollection<TblBenefit> TblBenefits { get; set; } = new List<TblBenefit>();

    public virtual ICollection<TblPlanBenefitParent> TblPlanBenefitParents { get; set; } = new List<TblPlanBenefitParent>();
}
