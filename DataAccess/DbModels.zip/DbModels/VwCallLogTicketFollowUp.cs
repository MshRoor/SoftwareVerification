﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwCallLogTicketFollowUp
{
    public int CallId { get; set; }

    public DateTime CallDate { get; set; }

    public string? CallerNumber { get; set; }

    public string? CallerName { get; set; }

    public bool? Nmhmember { get; set; }

    public string? MemberNo { get; set; }

    public int? CompanyId { get; set; }

    public string? Company { get; set; }

    public int? FacilityId { get; set; }

    public string? ServiceProvider { get; set; }

    public string? Location { get; set; }

    public string? CallType { get; set; }

    public int? ServiceTypeId { get; set; }

    public string? ServiceType { get; set; }

    public int? CallReasonId { get; set; }

    public string? CallReason { get; set; }

    public string? Description { get; set; }

    public string? Comment { get; set; }

    public bool? Escalated { get; set; }

    public int? EscalatedTo { get; set; }

    public string? Department { get; set; }

    public string? EscalatedStatus { get; set; }

    public string? EscalateComment { get; set; }

    public string? CreatedBy { get; set; }

    public string? UpdatedBy { get; set; }

    public string? LogSource { get; set; }

    public string? Crchannel { get; set; }

    public string? Priority { get; set; }

    public DateTime? EscalationDate { get; set; }

    public string? FinalResolution { get; set; }

    public DateTime? ResolutionDate { get; set; }

    public bool? Resolved { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? ContactEmail { get; set; }

    public int? AutoEscalateLevel { get; set; }

    public DateTime? AutoEscalateDate { get; set; }

    public string? ProductType { get; set; }

    public int? UserDepartment { get; set; }

    public int? LogSourceId { get; set; }

    public string? UserDepartmentName { get; set; }

    public bool? RespondedTo { get; set; }

    public DateTime? UpdatedDate { get; set; }

    public string? ResolvedBy { get; set; }

    public string? FeedbackComment { get; set; }

    public string? FeedbackCreatedBy { get; set; }

    public DateTime? FeedbackCreatedDate { get; set; }

    public bool? FollowUp { get; set; }
}
