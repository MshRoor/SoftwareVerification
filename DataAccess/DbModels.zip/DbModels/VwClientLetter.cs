﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwClientLetter
{
    public int Id { get; set; }

    public int? CrofficerId { get; set; }

    public string? CrofficerName { get; set; }

    public string? Ltype { get; set; }

    public string? Lmode { get; set; }

    public string? Lperiod { get; set; }

    public string? Topic { get; set; }

    public DateTime? DueDate { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }
}
