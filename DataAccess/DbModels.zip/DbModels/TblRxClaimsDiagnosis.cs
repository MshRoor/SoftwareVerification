﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblRxClaimsDiagnosis
{
    public int RowId { get; set; }

    public int? RxId { get; set; }

    public int? ProviderDataId { get; set; }

    public int? ProviderId { get; set; }

    public int? DiseaseId { get; set; }

    public string? DiseaseCode { get; set; }

    public string? DiseaseName { get; set; }

    public string? ProcessClaimNo { get; set; }

    public string? Status { get; set; }

    public DateTime? DateItem { get; set; }

    public int? BuildStatus { get; set; }

    public DateTime? StampDate { get; set; }
}
