﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblTariffXRx
{
    public int RowId { get; set; }

    public string? RxItemCode { get; set; }

    public int? NmhTarrifId { get; set; }

    public DateTime? CreatedDate { get; set; }
}
