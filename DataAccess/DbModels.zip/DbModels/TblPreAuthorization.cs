﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblPreAuthorization
{
    public int Id { get; set; }

    public int? MemberId { get; set; }

    public int? ItemId { get; set; }

    public DateTime? AuthorizeDate { get; set; }

    public int? ProviderId { get; set; }

    public int? UserId { get; set; }

    public int? BenefitOptionId { get; set; }

    public int? CompanyId { get; set; }
}
