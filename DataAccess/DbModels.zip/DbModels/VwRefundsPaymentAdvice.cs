﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwRefundsPaymentAdvice
{
    public string? CompanyName { get; set; }

    public int? ClaimsBatchNo { get; set; }

    public DateTime? DateOfClaim { get; set; }

    public string MembershipNo { get; set; } = null!;

    public string? Fullname { get; set; }

    public string? PrincipalName { get; set; }

    public string PaymentMode { get; set; } = null!;

    public string? ChequeNo { get; set; }

    public decimal? ChequeAmount { get; set; }

    public decimal? AmountClaimed { get; set; }

    public decimal? ConfirmAward { get; set; }

    public string ClaimsNo { get; set; } = null!;

    public string? Item { get; set; }

    public double? Qty { get; set; }

    public decimal? Claimed { get; set; }

    public decimal? ApprovedAmount { get; set; }

    public string? TariffXRejectionComments { get; set; }

    public int ClaimsDetailsId { get; set; }

    public DateTime DateofAttendance { get; set; }

    public int? ServiceProviderId { get; set; }

    public string? Bank { get; set; }

    public string? Comment { get; set; }
}
