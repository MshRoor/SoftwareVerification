﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblClaimsDiagnosisTem
{
    public string ClaimsNo { get; set; } = null!;

    public string? Diagnosis { get; set; }

    public string? ConfirmedDiagnosis { get; set; }

    public virtual TblClaimsHeader ClaimsNoNavigation { get; set; } = null!;
}
