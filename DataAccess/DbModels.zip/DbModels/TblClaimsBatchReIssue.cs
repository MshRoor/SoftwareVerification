﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblClaimsBatchReIssue
{
    public int Id { get; set; }

    public string BatchNo { get; set; } = null!;

    public int ServiceProviderId { get; set; }

    public int? MemberId { get; set; }

    public int? NoOfClaims { get; set; }

    public decimal? AmountClaimed { get; set; }

    public decimal? AmountAwarded { get; set; }

    public DateTime? DateOfClaim { get; set; }

    public int? StatusId { get; set; }

    public int? TypeOfBatching { get; set; }

    public int? Tpa { get; set; }

    public int? PaymentModeId { get; set; }

    public string? MoMoNumber { get; set; }

    public DateTime? CreatedDate { get; set; }

    public int? UserId { get; set; }

    public int ReferenceBatchNo { get; set; }
}
