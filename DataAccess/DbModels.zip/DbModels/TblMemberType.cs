﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblMemberType
{
    public int Id { get; set; }

    public string MemberType { get; set; } = null!;

    public int ActualMemberTypeId { get; set; }

    public string ActualMemberType { get; set; } = null!;

    public virtual ICollection<TblMember> TblMembers { get; set; } = new List<TblMember>();
}
