﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblMaritalStatus
{
    public int Id { get; set; }

    public string? Status { get; set; }

    public string? StatusCode { get; set; }

    public virtual ICollection<TblMember> TblMembers { get; set; } = new List<TblMember>();
}
