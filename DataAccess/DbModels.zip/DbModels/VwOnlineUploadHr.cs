﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwOnlineUploadHr
{
    public int? PrincipalId { get; set; }

    public string? StaffId { get; set; }

    public string? Surname { get; set; }

    public string? FirstName { get; set; }

    public string? OtherName { get; set; }

    public DateOnly? Dob { get; set; }

    public string? Gender { get; set; }

    public string? PrimaryPhoneNo1 { get; set; }

    public string? PhoneNo2 { get; set; }

    public string? Email { get; set; }

    public string? Nhisno { get; set; }

    public string? RelationshipType { get; set; }

    public string? MemberType { get; set; }

    public int ConfirmRecord { get; set; }

    public string? PrincipalNames { get; set; }

    public string? CardPin { get; set; }

    public string? Company { get; set; }

    public int? CompanyId { get; set; }

    public string? MemberNo { get; set; }

    public int MemberId { get; set; }

    public string? MemberPlan { get; set; }

    public int? PlanId { get; set; }

    public int IsEdit { get; set; }

    public int Role { get; set; }

    public int? HronlineId { get; set; }

    public int? Dobday { get; set; }

    public int? Dobmonth { get; set; }

    public int? Dobyear { get; set; }

    public bool? ReplaceMemberNo { get; set; }

    public string? NationalIdno { get; set; }
}
