﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwRefundsAdvice
{
    public string ClaimsNo { get; set; } = null!;

    public double? Qty { get; set; }

    public decimal? Claimed { get; set; }

    public string? Item { get; set; }

    public decimal? ApprovedAmount { get; set; }

    public string? TariffXRejectionComments { get; set; }

    public int ClaimsDetailsId { get; set; }

    public int? ClaimsBatchNo { get; set; }
}
