﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblDrugPriceListMobimed
{
    public int DrugId { get; set; }

    public string DrugName { get; set; } = null!;

    public double DrugPrice { get; set; }

    public bool? Mapped { get; set; }
}
