﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwClientSession
{
    public int Id { get; set; }

    public int? CompanyId { get; set; }

    public string Company { get; set; } = null!;

    public DateTime? SessionDate { get; set; }

    public string? SessionType { get; set; }

    public string? Issues { get; set; }

    public string? Theme { get; set; }

    public int? Participants { get; set; }

    public string? Resolutions { get; set; }

    public string? Feedback { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }
}
