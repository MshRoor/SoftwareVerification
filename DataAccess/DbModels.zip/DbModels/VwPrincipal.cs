﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwPrincipal
{
    public int Id { get; set; }

    public string MembershipNo { get; set; } = null!;

    public string? PrincipalName { get; set; }

    public string? FirstName { get; set; }

    public string? Mphone { get; set; }

    public int? CompanyId { get; set; }

    public string? CompanyName { get; set; }

    public int? GenderId { get; set; }

    public string? Gender { get; set; }

    public int? BenefitOptionId { get; set; }

    public string? PlanName { get; set; }

    public int? StatusId { get; set; }

    public string? Status { get; set; }

    public string? EmpNo { get; set; }

    public string? Email { get; set; }
}
