﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TspClaimsHeader
{
    public int Id { get; set; }

    public DateTime DateofAttendance { get; set; }

    public string ClaimsNo { get; set; } = null!;

    public int MemberId { get; set; }

    public int? AttendDay { get; set; }

    public int? AttendMonth { get; set; }

    public int? AttendYear { get; set; }

    public int? UserId { get; set; }

    public int? InOutId { get; set; }

    public DateTime? StampDate { get; set; }

    public int? BenefitOption { get; set; }

    public decimal? ProviderAmountClaimed { get; set; }

    public decimal? SysAmountClaimed { get; set; }

    public DateTime? AdmissionDate { get; set; }

    public DateTime? DischargeDate { get; set; }

    public int? StatusId { get; set; }

    public int? NmhProviderId { get; set; }

    public int? PrescriptionAvailable { get; set; }

    public virtual ICollection<TspClaimStatusInfo> TspClaimStatusInfos { get; set; } = new List<TspClaimStatusInfo>();

    public virtual TspClaimsDiagnosisTem? TspClaimsDiagnosisTem { get; set; }

    public virtual ICollection<TspClaimsHeaderXDisease> TspClaimsHeaderXDiseases { get; set; } = new List<TspClaimsHeaderXDisease>();
}
