﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwFrontOfficeReceipt
{
    public int Id { get; set; }

    public int ServiceProviderId { get; set; }

    public string ServiceProvider { get; set; } = null!;

    public DateTime? DateReceived { get; set; }

    public int? NoOfFiles { get; set; }

    public string? SubmittedBy { get; set; }

    public string? ContactNo { get; set; }

    public string? Designation { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? CreatedDate { get; set; }

    public decimal? Amount { get; set; }

    public DateTime? MonthOfSubmission { get; set; }

    public string? DocumentType { get; set; }
}
