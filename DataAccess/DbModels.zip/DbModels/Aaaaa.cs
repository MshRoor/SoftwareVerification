﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class Aaaaa
{
    public int Id { get; set; }

    public string MembershipNo { get; set; } = null!;

    public string? PrincipalId { get; set; }

    public int? MemberTypeId { get; set; }
}
