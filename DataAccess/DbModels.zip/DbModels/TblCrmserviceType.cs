﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblCrmserviceType
{
    public int Id { get; set; }

    public string? ServiceType { get; set; }
}
