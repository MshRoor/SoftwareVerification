﻿using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.DbModels;

public partial class EquityInsuranceDbContext : IdentityDbContext<IdentityUser>
{
    public EquityInsuranceDbContext()
    {
    }

    public EquityInsuranceDbContext(DbContextOptions<EquityInsuranceDbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Aaaaa> Aaaaas { get; set; }

    public virtual DbSet<ClaimsComment> ClaimsComments { get; set; }

    public virtual DbSet<MedifemItem> MedifemItems { get; set; }

    public virtual DbSet<RxCompany> RxCompanies { get; set; }

    public virtual DbSet<RxProvider> RxProviders { get; set; }

    public virtual DbSet<RxProvidersPlan> RxProvidersPlans { get; set; }

    public virtual DbSet<TblAuditTrail> TblAuditTrails { get; set; }

    public virtual DbSet<TblBank> TblBanks { get; set; }

    public virtual DbSet<TblBankBranch> TblBankBranches { get; set; }

    public virtual DbSet<TblBenefit> TblBenefits { get; set; }

    public virtual DbSet<TblBenefitCustomType> TblBenefitCustomTypes { get; set; }

    public virtual DbSet<TblBenefitGroup> TblBenefitGroups { get; set; }

    public virtual DbSet<TblBenefitParent> TblBenefitParents { get; set; }

    public virtual DbSet<TblBenefitXTariff> TblBenefitXTariffs { get; set; }

    public virtual DbSet<TblBillingCycle> TblBillingCycles { get; set; }

    public virtual DbSet<TblBroker> TblBrokers { get; set; }

    public virtual DbSet<TblCallLog> TblCallLogs { get; set; }

    public virtual DbSet<TblCallReason> TblCallReasons { get; set; }

    public virtual DbSet<TblCardPrinting> TblCardPrintings { get; set; }

    public virtual DbSet<TblClaimBatchStatus> TblClaimBatchStatuses { get; set; }

    public virtual DbSet<TblClaimForm> TblClaimForms { get; set; }

    public virtual DbSet<TblClaimsApprovedHsp> TblClaimsApprovedHsps { get; set; }

    public virtual DbSet<TblClaimsAvailable> TblClaimsAvailables { get; set; }

    public virtual DbSet<TblClaimsAvailableDental> TblClaimsAvailableDentals { get; set; }

    public virtual DbSet<TblClaimsAward> TblClaimsAwards { get; set; }

    public virtual DbSet<TblClaimsBatch> TblClaimsBatches { get; set; }

    public virtual DbSet<TblClaimsBatchReIssue> TblClaimsBatchReIssues { get; set; }

    public virtual DbSet<TblClaimsBatchStatusInfo> TblClaimsBatchStatusInfos { get; set; }

    public virtual DbSet<TblClaimsDetail> TblClaimsDetails { get; set; }

    public virtual DbSet<TblClaimsDetailsMySql> TblClaimsDetailsMySqls { get; set; }

    public virtual DbSet<TblClaimsDetailsMySqlDeleted> TblClaimsDetailsMySqlDeleteds { get; set; }

    public virtual DbSet<TblClaimsDetailsReIssue> TblClaimsDetailsReIssues { get; set; }

    public virtual DbSet<TblClaimsDetailsXTariffRejection> TblClaimsDetailsXTariffRejections { get; set; }

    public virtual DbSet<TblClaimsDiagnosisTem> TblClaimsDiagnosisTems { get; set; }

    public virtual DbSet<TblClaimsHeader> TblClaimsHeaders { get; set; }

    public virtual DbSet<TblClaimsHeaderXDisease> TblClaimsHeaderXDiseases { get; set; }

    public virtual DbSet<TblClaimsPayment> TblClaimsPayments { get; set; }

    public virtual DbSet<TblClaimsReceivedHsp> TblClaimsReceivedHsps { get; set; }

    public virtual DbSet<TblClientAppreciation> TblClientAppreciations { get; set; }

    public virtual DbSet<TblClientInteraction> TblClientInteractions { get; set; }

    public virtual DbSet<TblClientLetter> TblClientLetters { get; set; }

    public virtual DbSet<TblClientRefund> TblClientRefunds { get; set; }

    public virtual DbSet<TblClientSession> TblClientSessions { get; set; }

    public virtual DbSet<TblClientVisitation> TblClientVisitations { get; set; }

    public virtual DbSet<TblCommunity> TblCommunities { get; set; }

    public virtual DbSet<TblCompaniesSale> TblCompaniesSales { get; set; }

    public virtual DbSet<TblCompany> TblCompanies { get; set; }

    public virtual DbSet<TblCompanyContact> TblCompanyContacts { get; set; }

    public virtual DbSet<TblCompanyCrofficer> TblCompanyCrofficers { get; set; }

    public virtual DbSet<TblCompanyPlan> TblCompanyPlans { get; set; }

    public virtual DbSet<TblCompanyPlanBenefitGroup> TblCompanyPlanBenefitGroups { get; set; }

    public virtual DbSet<TblCompanyPlanBenefitGroupsRenewal> TblCompanyPlanBenefitGroupsRenewals { get; set; }

    public virtual DbSet<TblCompanyPlanBenefitGroupsSale> TblCompanyPlanBenefitGroupsSales { get; set; }

    public virtual DbSet<TblCompanyPlanBenefitLimit> TblCompanyPlanBenefitLimits { get; set; }

    public virtual DbSet<TblCompanyPlanBenefitLimitsRenewal> TblCompanyPlanBenefitLimitsRenewals { get; set; }

    public virtual DbSet<TblCompanyPlanBenefitLimitsSale> TblCompanyPlanBenefitLimitsSales { get; set; }

    public virtual DbSet<TblCompanyPlanBenefitParent> TblCompanyPlanBenefitParents { get; set; }

    public virtual DbSet<TblCompanyPlanBenefitParentRenewal> TblCompanyPlanBenefitParentRenewals { get; set; }

    public virtual DbSet<TblCompanyPlanBenefitParentSale> TblCompanyPlanBenefitParentSales { get; set; }

    public virtual DbSet<TblCompanyPlanMasterLimit> TblCompanyPlanMasterLimits { get; set; }

    public virtual DbSet<TblCompanyPlanMasterLimitRenewal> TblCompanyPlanMasterLimitRenewals { get; set; }

    public virtual DbSet<TblCompanyPlanMasterLimitSale> TblCompanyPlanMasterLimitSales { get; set; }

    public virtual DbSet<TblCompanyPlansRenewal> TblCompanyPlansRenewals { get; set; }

    public virtual DbSet<TblCompanyPlansSale> TblCompanyPlansSales { get; set; }

    public virtual DbSet<TblCompanyPolicy> TblCompanyPolicies { get; set; }

    public virtual DbSet<TblCompanyPolicySale> TblCompanyPolicySales { get; set; }

    public virtual DbSet<TblCompanyRenewal> TblCompanyRenewals { get; set; }

    public virtual DbSet<TblCompanyRenewalFileUpload> TblCompanyRenewalFileUploads { get; set; }

    public virtual DbSet<TblCompanySalesComment> TblCompanySalesComments { get; set; }

    public virtual DbSet<TblCompanySalesResponse> TblCompanySalesResponses { get; set; }

    public virtual DbSet<TblCompanyServiceProvider> TblCompanyServiceProviders { get; set; }

    public virtual DbSet<TblCompanyServiceProvidersRenewal> TblCompanyServiceProvidersRenewals { get; set; }

    public virtual DbSet<TblCompanyStatus> TblCompanyStatuses { get; set; }

    public virtual DbSet<TblCompanyXLogo> TblCompanyXLogos { get; set; }

    public virtual DbSet<TblCrmescalationLevel> TblCrmescalationLevels { get; set; }

    public virtual DbSet<TblCrmlogResponse> TblCrmlogResponses { get; set; }

    public virtual DbSet<TblCrmlogSource> TblCrmlogSources { get; set; }

    public virtual DbSet<TblCrmserviceType> TblCrmserviceTypes { get; set; }

    public virtual DbSet<TblCustomerServiceMonth> TblCustomerServiceMonths { get; set; }

    public virtual DbSet<TblDepartment> TblDepartments { get; set; }

    public virtual DbSet<TblDisease> TblDiseases { get; set; }

    public virtual DbSet<TblDiseaseGroup> TblDiseaseGroups { get; set; }

    public virtual DbSet<TblDiseaseMainGroup> TblDiseaseMainGroups { get; set; }

    public virtual DbSet<TblDiseaseParentGroup> TblDiseaseParentGroups { get; set; }

    public virtual DbSet<TblDiseaseXTariff> TblDiseaseXTariffs { get; set; }

    public virtual DbSet<TblDrugMap> TblDrugMaps { get; set; }

    public virtual DbSet<TblDrugMapMobimed> TblDrugMapMobimeds { get; set; }

    public virtual DbSet<TblDrugMapPrice> TblDrugMapPrices { get; set; }

    public virtual DbSet<TblDrugMapPricesMobimed> TblDrugMapPricesMobimeds { get; set; }

    public virtual DbSet<TblDrugPriceList> TblDrugPriceLists { get; set; }

    public virtual DbSet<TblDrugPriceListMobimed> TblDrugPriceListMobimeds { get; set; }

    public virtual DbSet<TblEmailUpdate> TblEmailUpdates { get; set; }

    public virtual DbSet<TblFrontOfficeReceipt> TblFrontOfficeReceipts { get; set; }

    public virtual DbSet<TblGender> TblGenders { get; set; }

    public virtual DbSet<TblGhanaCardUpdate> TblGhanaCardUpdates { get; set; }

    public virtual DbSet<TblHealthScreening> TblHealthScreenings { get; set; }

    public virtual DbSet<TblHealthTalk> TblHealthTalks { get; set; }

    public virtual DbSet<TblHronline> TblHronlines { get; set; }

    public virtual DbSet<TblHronlineStatus> TblHronlineStatuses { get; set; }

    public virtual DbSet<TblInOut> TblInOuts { get; set; }

    public virtual DbSet<TblMaritalStatus> TblMaritalStatuses { get; set; }

    public virtual DbSet<TblMember> TblMembers { get; set; }

    public virtual DbSet<TblMemberDeactivate> TblMemberDeactivates { get; set; }

    public virtual DbSet<TblMemberPlanBenefitGroup> TblMemberPlanBenefitGroups { get; set; }

    public virtual DbSet<TblMemberPlanBenefitLimit> TblMemberPlanBenefitLimits { get; set; }

    public virtual DbSet<TblMemberPlanBenefitParent> TblMemberPlanBenefitParents { get; set; }

    public virtual DbSet<TblMemberPolicy> TblMemberPolicies { get; set; }

    public virtual DbSet<TblMemberServiceProvider> TblMemberServiceProviders { get; set; }

    public virtual DbSet<TblMemberStatus> TblMemberStatuses { get; set; }

    public virtual DbSet<TblMemberStatusInfo> TblMemberStatusInfos { get; set; }

    public virtual DbSet<TblMemberType> TblMemberTypes { get; set; }

    public virtual DbSet<TblMemberTypeSale> TblMemberTypeSales { get; set; }

    public virtual DbSet<TblMonthlyUsageHrportal> TblMonthlyUsageHrportals { get; set; }

    public virtual DbSet<TblMonthlyUsageMobileApp> TblMonthlyUsageMobileApps { get; set; }

    public virtual DbSet<TblMonthlyUsageMobimed> TblMonthlyUsageMobimeds { get; set; }

    public virtual DbSet<TblMyHealthMembersBenefit> TblMyHealthMembersBenefits { get; set; }

    public virtual DbSet<TblNatureOfBusiness> TblNatureOfBusinesses { get; set; }

    public virtual DbSet<TblOccupation> TblOccupations { get; set; }

    public virtual DbSet<TblOwnershipType> TblOwnershipTypes { get; set; }

    public virtual DbSet<TblPaymentBatch> TblPaymentBatches { get; set; }

    public virtual DbSet<TblPaymentMode> TblPaymentModes { get; set; }

    public virtual DbSet<TblPaymentTableRx> TblPaymentTableRxes { get; set; }

    public virtual DbSet<TblPhoneNumberUpdate> TblPhoneNumberUpdates { get; set; }

    public virtual DbSet<TblPlan> TblPlans { get; set; }

    public virtual DbSet<TblPlanBenefitGroup> TblPlanBenefitGroups { get; set; }

    public virtual DbSet<TblPlanBenefitLimit> TblPlanBenefitLimits { get; set; }

    public virtual DbSet<TblPlanBenefitParent> TblPlanBenefitParents { get; set; }

    public virtual DbSet<TblPlanMain> TblPlanMains { get; set; }

    public virtual DbSet<TblPlanMasterLimit> TblPlanMasterLimits { get; set; }

    public virtual DbSet<TblPlanPremium> TblPlanPremiums { get; set; }

    public virtual DbSet<TblPlansUpdate> TblPlansUpdates { get; set; }

    public virtual DbSet<TblPreAuthorization> TblPreAuthorizations { get; set; }

    public virtual DbSet<TblPrescription> TblPrescriptions { get; set; }

    public virtual DbSet<TblPrintCardType> TblPrintCardTypes { get; set; }

    public virtual DbSet<TblProductLine> TblProductLines { get; set; }

    public virtual DbSet<TblProforma> TblProformas { get; set; }

    public virtual DbSet<TblProformaProduct> TblProformaProducts { get; set; }

    public virtual DbSet<TblRefundsApproved> TblRefundsApproveds { get; set; }

    public virtual DbSet<TblRefundsApprovedRejection> TblRefundsApprovedRejections { get; set; }

    public virtual DbSet<TblRefundsPayment> TblRefundsPayments { get; set; }

    public virtual DbSet<TblRefundsPrescription> TblRefundsPrescriptions { get; set; }

    public virtual DbSet<TblRefundsReason> TblRefundsReasons { get; set; }

    public virtual DbSet<TblRefundsReceipt> TblRefundsReceipts { get; set; }

    public virtual DbSet<TblRegion> TblRegions { get; set; }

    public virtual DbSet<TblRelation> TblRelations { get; set; }

    public virtual DbSet<TblRxClaimsDiagnosis> TblRxClaimsDiagnoses { get; set; }

    public virtual DbSet<TblService> TblServices { get; set; }

    public virtual DbSet<TblServiceProvider> TblServiceProviders { get; set; }

    public virtual DbSet<TblServiceProviderBenefitParent> TblServiceProviderBenefitParents { get; set; }

    public virtual DbSet<TblServiceProviderXPlan> TblServiceProviderXPlans { get; set; }

    public virtual DbSet<TblServiceProviderXService> TblServiceProviderXServices { get; set; }

    public virtual DbSet<TblServiceProviderXTariffXPrice> TblServiceProviderXTariffXPrices { get; set; }

    public virtual DbSet<TblServiceProvidersAccount> TblServiceProvidersAccounts { get; set; }

    public virtual DbSet<TblServiceProvidersRefund> TblServiceProvidersRefunds { get; set; }

    public virtual DbSet<TblServiceProvidersRx> TblServiceProvidersRxes { get; set; }

    public virtual DbSet<TblServiceType> TblServiceTypes { get; set; }

    public virtual DbSet<TblTariff> TblTariffs { get; set; }

    public virtual DbSet<TblTariffDrugsGeneric> TblTariffDrugsGenerics { get; set; }

    public virtual DbSet<TblTariffWithoutPrice> TblTariffWithoutPrices { get; set; }

    public virtual DbSet<TblTariffXRejectionComment> TblTariffXRejectionComments { get; set; }

    public virtual DbSet<TblTariffXRejectionCommentOnline> TblTariffXRejectionCommentOnlines { get; set; }

    public virtual DbSet<TblTariffXRx> TblTariffXRxes { get; set; }

    public virtual DbSet<TblTitle> TblTitles { get; set; }

    public virtual DbSet<TblUser> TblUsers { get; set; }

    public virtual DbSet<TblUserRole> TblUserRoles { get; set; }

    public virtual DbSet<TblVettingDoctor> TblVettingDoctors { get; set; }

    public virtual DbSet<TspClaimStatus> TspClaimStatuses { get; set; }

    public virtual DbSet<TspClaimStatusInfo> TspClaimStatusInfos { get; set; }

    public virtual DbSet<TspClaimsDetail> TspClaimsDetails { get; set; }

    public virtual DbSet<TspClaimsDiagnosisTem> TspClaimsDiagnosisTems { get; set; }

    public virtual DbSet<TspClaimsHeader> TspClaimsHeaders { get; set; }

    public virtual DbSet<TspClaimsHeaderXDisease> TspClaimsHeaderXDiseases { get; set; }

    public virtual DbSet<TspUser> TspUsers { get; set; }

    public virtual DbSet<TspUserRole> TspUserRoles { get; set; }

    public virtual DbSet<User> Users { get; set; }

    public virtual DbSet<VspClaimsDetail> VspClaimsDetails { get; set; }

    public virtual DbSet<VspClaimsHeader> VspClaimsHeaders { get; set; }

    public virtual DbSet<VspClaimsHeaderXDisease> VspClaimsHeaderXDiseases { get; set; }

    public virtual DbSet<VspUser> VspUsers { get; set; }

    public virtual DbSet<VspUsersMain> VspUsersMains { get; set; }

    public virtual DbSet<VvwClaimsDetailsOnline> VvwClaimsDetailsOnlines { get; set; }

    public virtual DbSet<VvwClaimsHeader> VvwClaimsHeaders { get; set; }

    public virtual DbSet<VwAdviceSlip> VwAdviceSlips { get; set; }

    public virtual DbSet<VwAdviceSlipDetail> VwAdviceSlipDetails { get; set; }

    public virtual DbSet<VwAuditTrail> VwAuditTrails { get; set; }

    public virtual DbSet<VwBankBranch> VwBankBranches { get; set; }

    public virtual DbSet<VwBatchStatusInfo> VwBatchStatusInfos { get; set; }

    public virtual DbSet<VwBenefit> VwBenefits { get; set; }

    public virtual DbSet<VwBenefitGroup> VwBenefitGroups { get; set; }

    public virtual DbSet<VwCallLogTicket> VwCallLogTickets { get; set; }

    public virtual DbSet<VwCallLogTicketFollowUp> VwCallLogTicketFollowUps { get; set; }

    public virtual DbSet<VwCallReason> VwCallReasons { get; set; }

    public virtual DbSet<VwCardPrinting> VwCardPrintings { get; set; }

    public virtual DbSet<VwClaimsAward> VwClaimsAwards { get; set; }

    public virtual DbSet<VwClaimsBatch> VwClaimsBatches { get; set; }

    public virtual DbSet<VwClaimsBatchHspaward> VwClaimsBatchHspawards { get; set; }

    public virtual DbSet<VwClaimsBatchRefund> VwClaimsBatchRefunds { get; set; }

    public virtual DbSet<VwClaimsBatchRefundReIssue> VwClaimsBatchRefundReIssues { get; set; }

    public virtual DbSet<VwClaimsBatchRefundsApproved> VwClaimsBatchRefundsApproveds { get; set; }

    public virtual DbSet<VwClaimsDetail> VwClaimsDetails { get; set; }

    public virtual DbSet<VwClaimsDetailsOnline> VwClaimsDetailsOnlines { get; set; }

    public virtual DbSet<VwClaimsDetailsReIssue> VwClaimsDetailsReIssues { get; set; }

    public virtual DbSet<VwClaimsDetailsXTariffRejection> VwClaimsDetailsXTariffRejections { get; set; }

    public virtual DbSet<VwClaimsHeader> VwClaimsHeaders { get; set; }

    public virtual DbSet<VwClaimsHeaderAdvice> VwClaimsHeaderAdvices { get; set; }

    public virtual DbSet<VwClaimsHeaderBuild> VwClaimsHeaderBuilds { get; set; }

    public virtual DbSet<VwClaimsHeaderUtil> VwClaimsHeaderUtils { get; set; }

    public virtual DbSet<VwClaimsHeaderUtilNew> VwClaimsHeaderUtilNews { get; set; }

    public virtual DbSet<VwClaimsHeaderXDisease> VwClaimsHeaderXDiseases { get; set; }

    public virtual DbSet<VwClaimsPayment> VwClaimsPayments { get; set; }

    public virtual DbSet<VwClaimsRecievedHsp> VwClaimsRecievedHsps { get; set; }

    public virtual DbSet<VwClientLetter> VwClientLetters { get; set; }

    public virtual DbSet<VwClientSession> VwClientSessions { get; set; }

    public virtual DbSet<VwClientVisitation> VwClientVisitations { get; set; }

    public virtual DbSet<VwCompaniesSale> VwCompaniesSales { get; set; }

    public virtual DbSet<VwCompaniesSummary> VwCompaniesSummaries { get; set; }

    public virtual DbSet<VwCompany> VwCompanies { get; set; }

    public virtual DbSet<VwCompanyPlan> VwCompanyPlans { get; set; }

    public virtual DbSet<VwCompanyPlanBenefitGroup> VwCompanyPlanBenefitGroups { get; set; }

    public virtual DbSet<VwCompanyPlanBenefitGroupsRenewal> VwCompanyPlanBenefitGroupsRenewals { get; set; }

    public virtual DbSet<VwCompanyPlanBenefitGroupsSale> VwCompanyPlanBenefitGroupsSales { get; set; }

    public virtual DbSet<VwCompanyPlanBenefitLimit> VwCompanyPlanBenefitLimits { get; set; }

    public virtual DbSet<VwCompanyPlanBenefitLimitsRenewal> VwCompanyPlanBenefitLimitsRenewals { get; set; }

    public virtual DbSet<VwCompanyPlanBenefitLimitsSale> VwCompanyPlanBenefitLimitsSales { get; set; }

    public virtual DbSet<VwCompanyPlanBenefitParent> VwCompanyPlanBenefitParents { get; set; }

    public virtual DbSet<VwCompanyPlanBenefitParentRenewal> VwCompanyPlanBenefitParentRenewals { get; set; }

    public virtual DbSet<VwCompanyPlanBenefitParentSale> VwCompanyPlanBenefitParentSales { get; set; }

    public virtual DbSet<VwCompanyPlansRenewal> VwCompanyPlansRenewals { get; set; }

    public virtual DbSet<VwCompanyPlansSale> VwCompanyPlansSales { get; set; }

    public virtual DbSet<VwCompanyPolicyActive> VwCompanyPolicyActives { get; set; }

    public virtual DbSet<VwCompanyPolicyRunning> VwCompanyPolicyRunnings { get; set; }

    public virtual DbSet<VwCompanySalesComment> VwCompanySalesComments { get; set; }

    public virtual DbSet<VwConsumption> VwConsumptions { get; set; }

    public virtual DbSet<VwDentalClaimsDetail> VwDentalClaimsDetails { get; set; }

    public virtual DbSet<VwDiseaseXTariff> VwDiseaseXTariffs { get; set; }

    public virtual DbSet<VwFrontOfficeReceipt> VwFrontOfficeReceipts { get; set; }

    public virtual DbSet<VwHealthScreening> VwHealthScreenings { get; set; }

    public virtual DbSet<VwHealthTalk> VwHealthTalks { get; set; }

    public virtual DbSet<VwIdcard> VwIdcards { get; set; }

    public virtual DbSet<VwMember> VwMembers { get; set; }

    public virtual DbSet<VwMemberPlanBenefitGroup> VwMemberPlanBenefitGroups { get; set; }

    public virtual DbSet<VwMemberPlanBenefitLimit> VwMemberPlanBenefitLimits { get; set; }

    public virtual DbSet<VwMemberPlanBenefitParent> VwMemberPlanBenefitParents { get; set; }

    public virtual DbSet<VwMemberPolicy> VwMemberPolicies { get; set; }

    public virtual DbSet<VwMemberStatusInfo> VwMemberStatusInfos { get; set; }

    public virtual DbSet<VwOnlineUpload> VwOnlineUploads { get; set; }

    public virtual DbSet<VwOnlineUploadHr> VwOnlineUploadHrs { get; set; }

    public virtual DbSet<VwPlan> VwPlans { get; set; }

    public virtual DbSet<VwPlanBenefitGroup> VwPlanBenefitGroups { get; set; }

    public virtual DbSet<VwPlanBenefitLimit> VwPlanBenefitLimits { get; set; }

    public virtual DbSet<VwPlanBenefitParent> VwPlanBenefitParents { get; set; }

    public virtual DbSet<VwPrincipal> VwPrincipals { get; set; }

    public virtual DbSet<VwProformaInvoice> VwProformaInvoices { get; set; }

    public virtual DbSet<VwProformaInvoiceSigned> VwProformaInvoiceSigneds { get; set; }

    public virtual DbSet<VwProformaProduct> VwProformaProducts { get; set; }

    public virtual DbSet<VwRefundsAdvice> VwRefundsAdvices { get; set; }

    public virtual DbSet<VwRefundsPaymentAdvice> VwRefundsPaymentAdvices { get; set; }

    public virtual DbSet<VwRefundsPrescription> VwRefundsPrescriptions { get; set; }

    public virtual DbSet<VwRefundsReceipt> VwRefundsReceipts { get; set; }

    public virtual DbSet<VwRxClaimsDiagnosis> VwRxClaimsDiagnoses { get; set; }

    public virtual DbSet<VwServiceProvider> VwServiceProviders { get; set; }

    public virtual DbSet<VwServiceProviderBenefitParent> VwServiceProviderBenefitParents { get; set; }

    public virtual DbSet<VwServiceProviderXPlan> VwServiceProviderXPlans { get; set; }

    public virtual DbSet<VwServiceProviderXService> VwServiceProviderXServices { get; set; }

    public virtual DbSet<VwServiceProviderXTariffXPrice> VwServiceProviderXTariffXPrices { get; set; }

    public virtual DbSet<VwServiceProvidersVettingDoctor> VwServiceProvidersVettingDoctors { get; set; }

    public virtual DbSet<VwSettlementLetter> VwSettlementLetters { get; set; }

    public virtual DbSet<VwTariff> VwTariffs { get; set; }

    public virtual DbSet<VwTariffDrugsGeneric> VwTariffDrugsGenerics { get; set; }

    public virtual DbSet<VwTariffDrugsProprietary> VwTariffDrugsProprietaries { get; set; }

    public virtual DbSet<VwTariffXPricesDrugsMobimed> VwTariffXPricesDrugsMobimeds { get; set; }

    public virtual DbSet<VwTariffXPricesDrugsNew> VwTariffXPricesDrugsNews { get; set; }

    public virtual DbSet<VwUtiliazationMyHealthDetail> VwUtiliazationMyHealthDetails { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=.\\SQLEXPRESS;Database=Equity_InsuranceDb;Trusted_Connection=True;Encrypt=True;Trust Server Certificate=True;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<Aaaaa>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("aaaaa");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.MemberTypeId).HasColumnName("MemberTypeID");
            entity.Property(e => e.MembershipNo)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.PrincipalId)
                .HasMaxLength(255)
                .HasColumnName("principal_id");
        });

        modelBuilder.Entity<ClaimsComment>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("claimsComment");

            entity.Property(e => e.Comment)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("comment");
            entity.Property(e => e.ProcessClaimNo)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("process_claim_no");
        });

        modelBuilder.Entity<MedifemItem>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("Medifem_Items");

            entity.Property(e => e.InsItemCode)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("ins_item_code");
            entity.Property(e => e.Item)
                .IsUnicode(false)
                .HasColumnName("item");
        });

        modelBuilder.Entity<RxCompany>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("RX_Company");

            entity.Property(e => e.Company).HasMaxLength(255);
            entity.Property(e => e.CompanyCode).HasMaxLength(255);
            entity.Property(e => e.CompanyId)
                .HasMaxLength(255)
                .HasColumnName("CompanyID");
            entity.Property(e => e.CompanyStatus)
                .HasMaxLength(255)
                .HasColumnName("company_status");
            entity.Property(e => e.CompanyType).HasMaxLength(255);
            entity.Property(e => e.ContactEmail)
                .HasMaxLength(255)
                .HasColumnName("contact_email");
            entity.Property(e => e.ContactPerson)
                .HasMaxLength(255)
                .HasColumnName("contact_person");
            entity.Property(e => e.ExchangeRate)
                .HasMaxLength(255)
                .HasColumnName("exchange_rate");
            entity.Property(e => e.GroupType).HasColumnName("group_type");
            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.IdInscompany)
                .HasMaxLength(255)
                .HasColumnName("id_inscompany");
            entity.Property(e => e.PolicyEndDate).HasColumnType("datetime");
            entity.Property(e => e.PolicyStartDate).HasColumnType("datetime");
            entity.Property(e => e.PrefixCode)
                .HasMaxLength(255)
                .HasColumnName("prefix_code");
            entity.Property(e => e.StatusUpdateTime)
                .HasColumnType("datetime")
                .HasColumnName("status_update_time");
        });

        modelBuilder.Entity<RxProvider>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("RX_Providers");

            entity.Property(e => e.Area)
                .HasMaxLength(255)
                .HasColumnName("area");
            entity.Property(e => e.AverageRates).HasColumnName("average_rates");
            entity.Property(e => e.Cordinate)
                .HasMaxLength(255)
                .HasColumnName("cordinate");
            entity.Property(e => e.DatetimeActivated)
                .HasColumnType("datetime")
                .HasColumnName("datetime_activated");
            entity.Property(e => e.FacilityContactPerson)
                .HasMaxLength(255)
                .HasColumnName("facility_contact_person");
            entity.Property(e => e.FacilityContactTel)
                .HasMaxLength(255)
                .HasColumnName("facility_contact_tel");
            entity.Property(e => e.FacilityLocation)
                .HasMaxLength(255)
                .HasColumnName("facility_location");
            entity.Property(e => e.FacilityName)
                .HasMaxLength(255)
                .HasColumnName("facility_name");
            entity.Property(e => e.FacilityNumber)
                .HasMaxLength(255)
                .HasColumnName("facility_number");
            entity.Property(e => e.FacilityPhoto)
                .HasMaxLength(255)
                .HasColumnName("facility_photo");
            entity.Property(e => e.FacilityRegion)
                .HasMaxLength(255)
                .HasColumnName("facility_region");
            entity.Property(e => e.FacilityStatus)
                .HasMaxLength(255)
                .HasColumnName("facility_status");
            entity.Property(e => e.FacilityTelNumber)
                .HasMaxLength(255)
                .HasColumnName("facility_tel_number");
            entity.Property(e => e.FacilityTelNumber2)
                .HasMaxLength(255)
                .HasColumnName("facility_tel_number_2");
            entity.Property(e => e.FacilityType)
                .HasMaxLength(255)
                .HasColumnName("facility_type");
            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Latitude)
                .HasMaxLength(255)
                .HasColumnName("latitude");
            entity.Property(e => e.Longitude)
                .HasMaxLength(255)
                .HasColumnName("longitude");
            entity.Property(e => e.OutOfNetwork)
                .HasMaxLength(255)
                .HasColumnName("out_of_network");
            entity.Property(e => e.ProviderId).HasColumnName("provider_id");
            entity.Property(e => e.ProviderIdMaster).HasColumnName("provider_id_master");
            entity.Property(e => e.RxZone)
                .HasMaxLength(255)
                .HasColumnName("rx_zone");
            entity.Property(e => e.ServerId).HasColumnName("server_id");
            entity.Property(e => e.SubArea)
                .HasMaxLength(255)
                .HasColumnName("sub_area");
            entity.Property(e => e.TaxRate).HasColumnName("tax_rate");
            entity.Property(e => e.TypeOfFacility)
                .HasMaxLength(255)
                .HasColumnName("type_of_facility");
            entity.Property(e => e.Version)
                .HasMaxLength(255)
                .HasColumnName("version");
        });

        modelBuilder.Entity<RxProvidersPlan>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("RX_Providers_Plan");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.IdInscompany)
                .HasMaxLength(255)
                .HasColumnName("id_inscompany");
            entity.Property(e => e.InsCompany)
                .HasMaxLength(255)
                .HasColumnName("ins_company");
            entity.Property(e => e.Plan)
                .HasMaxLength(255)
                .HasColumnName("plan");
            entity.Property(e => e.PlanId).HasColumnName("plan_id");
            entity.Property(e => e.ProviderId).HasColumnName("provider_id");
            entity.Property(e => e.Status)
                .HasMaxLength(255)
                .HasColumnName("status");
        });

        modelBuilder.Entity<TblAuditTrail>(entity =>
        {
            entity.ToTable("tblAuditTrail");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.ActionDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.ActionDescription)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ActionId)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("ActionID");
        });

        modelBuilder.Entity<TblBank>(entity =>
        {
            entity.ToTable("tblBanks");

            entity.Property(e => e.Active).HasDefaultValue(true);
            entity.Property(e => e.Bank)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Shortname)
                .HasMaxLength(20)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblBankBranch>(entity =>
        {
            entity.HasKey(e => e.BranchId);

            entity.ToTable("tblBankBranches");

            entity.Property(e => e.BranchName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.SortCode)
                .HasMaxLength(6)
                .IsUnicode(false);

            entity.HasOne(d => d.Bank).WithMany(p => p.TblBankBranches)
                .HasForeignKey(d => d.BankId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblBankBranches_tblBanks");
        });

        modelBuilder.Entity<TblBenefit>(entity =>
        {
            entity.ToTable("tblBenefits");

            entity.Property(e => e.Benefit)
                .HasMaxLength(200)
                .IsUnicode(false);
            entity.Property(e => e.RxBenefitId).HasColumnName("Rx_BenefitId");

            entity.HasOne(d => d.BenefitGroup).WithMany(p => p.TblBenefits)
                .HasForeignKey(d => d.BenefitGroupId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblBenefits_tblBenefitGroups");

            entity.HasOne(d => d.BenefitParent).WithMany(p => p.TblBenefits)
                .HasForeignKey(d => d.BenefitParentId)
                .HasConstraintName("FK_tblBenefits_tblBenefitParent");
        });

        modelBuilder.Entity<TblBenefitCustomType>(entity =>
        {
            entity.ToTable("tblBenefitCustomType");

            entity.Property(e => e.CustomType)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblBenefitGroup>(entity =>
        {
            entity.ToTable("tblBenefitGroups");

            entity.Property(e => e.BenefitGroup)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.RxGroupId).HasColumnName("Rx_GroupId");

            entity.HasOne(d => d.BenefitParent).WithMany(p => p.TblBenefitGroups)
                .HasForeignKey(d => d.BenefitParentId)
                .HasConstraintName("FK_tblBenefitGroups_tblBenefitParent");
        });

        modelBuilder.Entity<TblBenefitParent>(entity =>
        {
            entity.ToTable("tblBenefitParent");

            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.ParentName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.RxParentId).HasColumnName("Rx_ParentId");
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<TblBenefitXTariff>(entity =>
        {
            entity.ToTable("tblBenefit_X_Tariff");

            entity.HasIndex(e => new { e.BenefitId, e.TariffId }, "IX_tblBenefit_X_Tariff").IsUnique();

            entity.Property(e => e.Id).ValueGeneratedNever();
            entity.Property(e => e.BenefitId).HasColumnName("BenefitID");
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.TariffId).HasColumnName("TariffID");
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            entity.Property(e => e.UserId).HasColumnName("UserID");

            entity.HasOne(d => d.Benefit).WithMany(p => p.TblBenefitXTariffs)
                .HasForeignKey(d => d.BenefitId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblBenefit_X_Tariff_tblBenefits");

            entity.HasOne(d => d.Tariff).WithMany(p => p.TblBenefitXTariffs)
                .HasForeignKey(d => d.TariffId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblBenefit_X_Tariff_tblTariff");
        });

        modelBuilder.Entity<TblBillingCycle>(entity =>
        {
            entity.HasKey(e => e.BillingCycleNo);

            entity.ToTable("tblBillingCycle");

            entity.Property(e => e.BillingCycleNo).ValueGeneratedNever();
            entity.Property(e => e.BillingCycleName)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblBroker>(entity =>
        {
            entity.ToTable("tblBrokers");

            entity.Property(e => e.Address)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.BrokerName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ContactNo)
                .HasMaxLength(10)
                .IsUnicode(false);
            entity.Property(e => e.ContactPerson)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Email)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.JoinDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<TblCallLog>(entity =>
        {
            entity.HasKey(e => e.CallId);

            entity.ToTable("tblCallLog");

            entity.Property(e => e.AutoEscalateDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.AutoEscalateLevel).HasDefaultValue(0);
            entity.Property(e => e.CallDate).HasColumnType("datetime");
            entity.Property(e => e.CallType)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CallerName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.CallerNumber)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.Comment).IsUnicode(false);
            entity.Property(e => e.ComplaintSource)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.ContactEmail)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Crchannel)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasDefaultValue("CC")
                .HasColumnName("CRChannel");
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Description).IsUnicode(false);
            entity.Property(e => e.EscalateComment).IsUnicode(false);
            entity.Property(e => e.Escalated).HasDefaultValue(false);
            entity.Property(e => e.EscalatedStatus)
                .HasMaxLength(10)
                .IsUnicode(false);
            entity.Property(e => e.EscalationDate).HasColumnType("datetime");
            entity.Property(e => e.FeedbackDate).HasColumnType("datetime");
            entity.Property(e => e.FinalResolution).IsUnicode(false);
            entity.Property(e => e.Location)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.MemberNo)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.Nmhmember)
                .HasDefaultValue(false)
                .HasColumnName("NMHMember");
            entity.Property(e => e.Priority)
                .HasMaxLength(10)
                .IsUnicode(false);
            entity.Property(e => e.ProductType)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasDefaultValue("Corporate");
            entity.Property(e => e.ResolutionDate).HasColumnType("datetime");
            entity.Property(e => e.Resolved).HasDefaultValue(true);
            entity.Property(e => e.ResolvedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.RespondedTo).HasDefaultValue(false);
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

            entity.HasOne(d => d.LogSource).WithMany(p => p.TblCallLogs)
                .HasForeignKey(d => d.LogSourceId)
                .HasConstraintName("FK_tblCallLog_tblCRMLogSource");
        });

        modelBuilder.Entity<TblCallReason>(entity =>
        {
            entity.ToTable("tblCallReason");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.CallReason)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Priority)
                .HasMaxLength(20)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblCardPrinting>(entity =>
        {
            entity.ToTable("tblCardPrinting");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.DatePrinted)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.MemberId).HasColumnName("MemberID");
            entity.Property(e => e.PrintType).HasDefaultValue(1);
            entity.Property(e => e.SerialNo)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.UserId).HasColumnName("UserID");
        });

        modelBuilder.Entity<TblClaimBatchStatus>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK_Claim_Batch_Status");

            entity.ToTable("tblClaim_Batch_Status");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.BbgSt).HasColumnName("BBG_ST");
            entity.Property(e => e.ProcessStage)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.StageId).HasColumnName("StageID");
            entity.Property(e => e.Status)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.StatusId).HasColumnName("StatusID");
        });

        modelBuilder.Entity<TblClaimForm>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK_ClaimForms");

            entity.ToTable("tblClaimForms");

            entity.Property(e => e.ClaimsNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.DateStamp)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.ImagePath)
                .HasMaxLength(200)
                .IsUnicode(false);

            entity.HasOne(d => d.ClaimsNoNavigation).WithMany(p => p.TblClaimForms)
                .HasForeignKey(d => d.ClaimsNo)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblClaimForms_tblClaimsHeader");
        });

        modelBuilder.Entity<TblClaimsApprovedHsp>(entity =>
        {
            entity.HasKey(e => e.BatchNo);

            entity.ToTable("tblClaimsApproved_HSP");

            entity.Property(e => e.BatchNo).ValueGeneratedNever();
            entity.Property(e => e.AmountClaimed).HasColumnType("numeric(18, 2)");
            entity.Property(e => e.AmountDue).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.AutoId).ValueGeneratedOnAdd();
            entity.Property(e => e.Awarded).HasColumnType("money");
            entity.Property(e => e.BatchType)
                .HasMaxLength(2)
                .IsUnicode(false);
            entity.Property(e => e.Building).HasColumnType("money");
            entity.Property(e => e.Claimed).HasColumnType("money");
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.CustomerId)
                .HasMaxLength(13)
                .IsUnicode(false)
                .HasColumnName("CustomerID");
            entity.Property(e => e.DateOfClaim).HasColumnType("datetime");
            entity.Property(e => e.MonthOfClaim)
                .HasMaxLength(61)
                .IsUnicode(false);
            entity.Property(e => e.OnlinePush).HasDefaultValue(false);
            entity.Property(e => e.OverStatement).HasColumnType("numeric(21, 4)");
            entity.Property(e => e.Processed).HasDefaultValue(false);
            entity.Property(e => e.ProcessedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ProcessedDate).HasColumnType("datetime");
            entity.Property(e => e.Rejections).HasColumnType("money");
            entity.Property(e => e.ServiceProvideId).HasColumnName("ServiceProvideID");
            entity.Property(e => e.ServiceProvider)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Tpa).HasColumnName("TPA");
            entity.Property(e => e.WithHoldingRate)
                .HasMaxLength(4)
                .IsUnicode(false);
            entity.Property(e => e.Withold).HasColumnType("decimal(18, 2)");
        });

        modelBuilder.Entity<TblClaimsAvailable>(entity =>
        {
            entity.ToTable("tblClaimsAvailable");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.AdviceMemberName)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.BenefitOption)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ClaimsDetailsId).HasColumnName("ClaimsDetailsID");
            entity.Property(e => e.ClaimsNo)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.Company)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.DateOfClaim).HasColumnType("datetime");
            entity.Property(e => e.DatePushed).HasColumnType("datetime");
            entity.Property(e => e.DateofAttendance).HasColumnType("datetime");
            entity.Property(e => e.Diagnosis)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.Dob)
                .HasColumnType("datetime")
                .HasColumnName("DOB");
            entity.Property(e => e.Dob2).HasColumnName("DOB2");
            entity.Property(e => e.DocComment).IsUnicode(false);
            entity.Property(e => e.DocId).HasColumnName("DocID");
            entity.Property(e => e.DocResponse)
                .HasMaxLength(8)
                .IsUnicode(false);
            entity.Property(e => e.FullName)
                .HasMaxLength(300)
                .IsUnicode(false);
            entity.Property(e => e.Gender)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Inout)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.MemberAge)
                .HasMaxLength(18)
                .IsUnicode(false);
            entity.Property(e => e.MemberId).HasColumnName("MemberID");
            entity.Property(e => e.NmhPull)
                .HasDefaultValue(false)
                .HasColumnName("nmhPull");
            entity.Property(e => e.NotAMember)
                .HasMaxLength(500)
                .IsUnicode(false)
                .HasColumnName("NotA_Member");
            entity.Property(e => e.OnlinePush).HasDefaultValue(false);
            entity.Property(e => e.Plan)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PrescribedDrug)
                .HasMaxLength(5000)
                .IsUnicode(false);
            entity.Property(e => e.RowId).HasColumnName("RowID");
            entity.Property(e => e.ServiceProvideId).HasColumnName("ServiceProvideID");
            entity.Property(e => e.ServiceProvider)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ServiceProviderBatch)
                .HasMaxLength(122)
                .IsUnicode(false);
            entity.Property(e => e.ServiceType)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.StampDate).HasColumnType("datetime");
            entity.Property(e => e.TariffName)
                .HasMaxLength(5000)
                .IsUnicode(false);
            entity.Property(e => e.TariffXRejectionCommentId).HasColumnName("Tariff_X_RejectionCommentID");
            entity.Property(e => e.TariffXRejectionComments)
                .IsUnicode(false)
                .HasColumnName("Tariff_X_RejectionComments");
            entity.Property(e => e.Vetted).HasDefaultValue(false);
        });

        modelBuilder.Entity<TblClaimsAvailableDental>(entity =>
        {
            entity.ToTable("tblClaimsAvailable_Dental");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.BenefitOption).HasMaxLength(50);
            entity.Property(e => e.ClaimDetailsId).HasColumnName("ClaimDetailsID");
            entity.Property(e => e.ClaimsNo)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.Company).HasMaxLength(255);
            entity.Property(e => e.DatePushed).HasColumnType("datetime");
            entity.Property(e => e.DateofAttendance).HasColumnType("datetime");
            entity.Property(e => e.Diagnosis)
                .IsUnicode(false)
                .HasColumnName("diagnosis");
            entity.Property(e => e.DocComment).IsUnicode(false);
            entity.Property(e => e.DocId).HasColumnName("DocID");
            entity.Property(e => e.DocResponse)
                .HasMaxLength(8)
                .IsUnicode(false);
            entity.Property(e => e.EyeOptical)
                .IsUnicode(false)
                .HasColumnName("eye_optical");
            entity.Property(e => e.FacilityName)
                .HasMaxLength(255)
                .HasColumnName("facility_name");
            entity.Property(e => e.FullName)
                .HasMaxLength(304)
                .IsUnicode(false);
            entity.Property(e => e.Gender).HasMaxLength(50);
            entity.Property(e => e.Item)
                .IsUnicode(false)
                .HasColumnName("item");
            entity.Property(e => e.MemberAge)
                .HasMaxLength(18)
                .IsUnicode(false);
            entity.Property(e => e.MemberNo).HasMaxLength(4000);
            entity.Property(e => e.NmhProviderId).HasColumnName("NMH_ProviderID");
            entity.Property(e => e.NmhPull)
                .HasDefaultValue(false)
                .HasColumnName("nmhPull");
            entity.Property(e => e.OnlinePush).HasDefaultValue(false);
            entity.Property(e => e.ProviderId).HasColumnName("provider_id");
            entity.Property(e => e.RowId).HasColumnName("RowID");
            entity.Property(e => e.ServiceProvider)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Toothnos)
                .IsUnicode(false)
                .HasColumnName("toothnos");
            entity.Property(e => e.TypeOfVisit)
                .IsUnicode(false)
                .HasColumnName("type_of_visit");
            entity.Property(e => e.Vetted).HasDefaultValue(false);
        });

        modelBuilder.Entity<TblClaimsAward>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK_ClaimsAwards");

            entity.ToTable("tblClaimsAwards");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.AmountDue).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.AmountWord)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.AwardDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Awarded).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Building).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Claimed).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Comment)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.SysAward).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.WithHoldingRate)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Withold).HasColumnType("decimal(18, 2)");

            entity.HasOne(d => d.BatchNoNavigation).WithMany(p => p.TblClaimsAwards)
                .HasForeignKey(d => d.BatchNo)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblClaimsAwards_tblClaimsBatch");
        });

        modelBuilder.Entity<TblClaimsBatch>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK_ClaimsBatch_1");

            entity.ToTable("tblClaimsBatch");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.AmountAwarded).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.AmountClaimed).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Comment)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.CommentId).HasColumnName("CommentID");
            entity.Property(e => e.CompletedEntryDate).HasColumnType("datetime");
            entity.Property(e => e.ConfirmAward).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ContactNo)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.DateOfClaim).HasColumnType("datetime");
            entity.Property(e => e.DateStamp)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.EntryUserId).HasColumnName("EntryUserID");
            entity.Property(e => e.MemberId).HasColumnName("MemberID");
            entity.Property(e => e.MoMoNumber)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.ModeOfSubmission)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.OtherDeduction).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.PeriodFrom).HasColumnType("datetime");
            entity.Property(e => e.PeriodTo).HasColumnType("datetime");
            entity.Property(e => e.ProviderClaimed).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ServiceProviderId).HasColumnName("ServiceProviderID");
            entity.Property(e => e.Sms).HasColumnName("SMS");
            entity.Property(e => e.StartEntryDate).HasColumnType("datetime");
            entity.Property(e => e.StatusId).HasColumnName("StatusID");
            entity.Property(e => e.SubmittedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.SystemAward).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.SystemClaim).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Tpa)
                .HasDefaultValue(0)
                .HasColumnName("TPA");
            entity.Property(e => e.WithHolding).HasColumnType("decimal(18, 2)");
        });

        modelBuilder.Entity<TblClaimsBatchReIssue>(entity =>
        {
            entity.ToTable("tblClaimsBatch_ReIssues");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.AmountAwarded).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.AmountClaimed).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.BatchNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.DateOfClaim).HasColumnType("datetime");
            entity.Property(e => e.MemberId).HasColumnName("MemberID");
            entity.Property(e => e.MoMoNumber)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.ServiceProviderId).HasColumnName("ServiceProviderID");
            entity.Property(e => e.StatusId).HasColumnName("StatusID");
            entity.Property(e => e.Tpa)
                .HasDefaultValue(0)
                .HasColumnName("TPA");
            entity.Property(e => e.UserId).HasColumnName("UserID");
        });

        modelBuilder.Entity<TblClaimsBatchStatusInfo>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK_ClaimsBatch_Status_Info");

            entity.ToTable("tblClaimsBatch_Status_Info", tb => tb.HasTrigger("get_HSP_Portal_Data"));

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.DateStamp)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.StatusId).HasColumnName("StatusID");
            entity.Property(e => e.UserId).HasColumnName("UserID");

            entity.HasOne(d => d.BatchNoNavigation).WithMany(p => p.TblClaimsBatchStatusInfos)
                .HasForeignKey(d => d.BatchNo)
                .HasConstraintName("FK_tblClaimsBatch_Status_Info_tblClaimsBatch");

            entity.HasOne(d => d.Status).WithMany(p => p.TblClaimsBatchStatusInfos)
                .HasForeignKey(d => d.StatusId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblClaimsBatch_Status_Info_tblClaim_Batch_Status");
        });

        modelBuilder.Entity<TblClaimsDetail>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK_ClaimsDetails1");

            entity.ToTable("tblClaimsDetails");

            entity.HasIndex(e => e.ClaimsNo, "IX_tblClaimsDetails");

            entity.HasIndex(e => e.RxRowId, "IX_tblClaimsDetails_RX_RowID");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.ApprovedAmount).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Awarded).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.BenefitOption)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Claimed).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ClaimsNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Curr)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Diff)
                .HasComputedColumnSql("([Claimed]-[ApprovedAmount])", false)
                .HasColumnType("decimal(19, 2)");
            entity.Property(e => e.PassAge).HasColumnName("passAge");
            entity.Property(e => e.PassAmount).HasColumnName("passAmount");
            entity.Property(e => e.PassDiaTariff).HasColumnName("passDiaTariff");
            entity.Property(e => e.PassExclusion).HasColumnName("passExclusion");
            entity.Property(e => e.PassGender).HasColumnName("passGender");
            entity.Property(e => e.PassInOut).HasColumnName("passInOut");
            entity.Property(e => e.PassService).HasColumnName("passService");
            entity.Property(e => e.PreVetComments)
                .IsUnicode(false)
                .HasColumnName("Pre Vet Comments");
            entity.Property(e => e.ProductId).HasColumnName("ProductID");
            entity.Property(e => e.RefundReceiptNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ReviewAwarded)
                .HasDefaultValue(0.0m)
                .HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ReviewStatus).HasDefaultValue(0);
            entity.Property(e => e.RxRowId).HasColumnName("RX_RowID");
            entity.Property(e => e.StampDate).HasColumnType("datetime");
            entity.Property(e => e.UnitPrice).HasColumnType("decimal(18, 3)");
            entity.Property(e => e.VettingId).HasColumnName("VettingID");

            entity.HasOne(d => d.ClaimsNoNavigation).WithMany(p => p.TblClaimsDetails)
                .HasForeignKey(d => d.ClaimsNo)
                .HasConstraintName("FK_tblClaimsDetails_tblClaimsHeader");

            entity.HasOne(d => d.ProductNavigation).WithMany(p => p.TblClaimsDetails)
                .HasForeignKey(d => d.ProductId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblClaimsDetails_tblTariff");
        });

        modelBuilder.Entity<TblClaimsDetailsMySql>(entity =>
        {
            entity.HasKey(e => e.RowId).HasName("PK_ClaimsDetails_MySql");

            entity.ToTable("tblClaimsDetails_MySql");

            entity.HasIndex(e => e.ProcessClaimNo, "IX_tblClaimsDetails_MySql_process_claim_no");

            entity.Property(e => e.RowId).HasColumnName("RowID");
            entity.Property(e => e.ActionStatus)
                .IsUnicode(false)
                .HasColumnName("action_status");
            entity.Property(e => e.AttendingOfficer)
                .IsUnicode(false)
                .HasColumnName("attending_officer");
            entity.Property(e => e.Awarded)
                .IsUnicode(false)
                .HasColumnName("awarded");
            entity.Property(e => e.ClaimsDetailsStatus)
                .HasDefaultValue(0)
                .HasColumnName("Claims_Details_Status");
            entity.Property(e => e.ClaimsHeaderStatus)
                .HasDefaultValue(0)
                .HasColumnName("Claims_Header_Status");
            entity.Property(e => e.Comment)
                .IsUnicode(false)
                .HasColumnName("comment");
            entity.Property(e => e.CurrentLocation)
                .IsUnicode(false)
                .HasColumnName("current_location");
            entity.Property(e => e.DateAdded)
                .HasColumnType("datetime")
                .HasColumnName("date_added");
            entity.Property(e => e.DateAddedShort)
                .HasColumnType("datetime")
                .HasColumnName("date_added_short");
            entity.Property(e => e.DateOfAdmission)
                .HasColumnType("datetime")
                .HasColumnName("date_of_admission");
            entity.Property(e => e.DateOfConsultation)
                .HasColumnType("datetime")
                .HasColumnName("date_of_consultation");
            entity.Property(e => e.DateOfDischarge)
                .HasColumnType("datetime")
                .HasColumnName("date_of_discharge");
            entity.Property(e => e.DateStamp)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("dateStamp");
            entity.Property(e => e.Diagnosis)
                .IsUnicode(false)
                .HasColumnName("diagnosis");
            entity.Property(e => e.DosageForm)
                .IsUnicode(false)
                .HasColumnName("dosage_form");
            entity.Property(e => e.Dose)
                .IsUnicode(false)
                .HasColumnName("dose");
            entity.Property(e => e.EyeOptical)
                .IsUnicode(false)
                .HasColumnName("eye_optical");
            entity.Property(e => e.FacilityName)
                .HasMaxLength(200)
                .IsUnicode(false)
                .HasColumnName("facility_name");
            entity.Property(e => e.Frequency)
                .IsUnicode(false)
                .HasColumnName("frequency");
            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.InsCompany)
                .IsUnicode(false)
                .HasColumnName("ins_company");
            entity.Property(e => e.InsItemCode)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("ins_item_code");
            entity.Property(e => e.Item)
                .IsUnicode(false)
                .HasColumnName("item");
            entity.Property(e => e.ItemClass)
                .IsUnicode(false)
                .HasColumnName("item_class");
            entity.Property(e => e.ItemDaysDiff)
                .IsUnicode(false)
                .HasColumnName("item_days_diff");
            entity.Property(e => e.ItemService)
                .IsUnicode(false)
                .HasColumnName("item_service");
            entity.Property(e => e.ItemServiceType)
                .IsUnicode(false)
                .HasColumnName("item_service_type");
            entity.Property(e => e.MemberNo)
                .IsUnicode(false)
                .HasColumnName("member_no");
            entity.Property(e => e.NoOfDays)
                .IsUnicode(false)
                .HasColumnName("no_of_days");
            entity.Property(e => e.ProcessClaimNo)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("process_claim_no");
            entity.Property(e => e.ProviderDataId)
                .IsUnicode(false)
                .HasColumnName("provider_data_id");
            entity.Property(e => e.ProviderId).HasColumnName("provider_id");
            entity.Property(e => e.ProviderIdDataFor).HasColumnName("provider_id_data_for");
            entity.Property(e => e.ProviderIdMaster)
                .IsUnicode(false)
                .HasColumnName("provider_id_master");
            entity.Property(e => e.ProviderItemId)
                .IsUnicode(false)
                .HasColumnName("provider_item_id");
            entity.Property(e => e.ProviderRefNo)
                .IsUnicode(false)
                .HasColumnName("provider_ref_no");
            entity.Property(e => e.PushTime).HasColumnName("push_time");
            entity.Property(e => e.Qty).HasColumnName("qty");
            entity.Property(e => e.RxMemberId)
                .IsUnicode(false)
                .HasColumnName("rx_member_id");
            entity.Property(e => e.ServerPushStatus)
                .IsUnicode(false)
                .HasColumnName("server_push_status");
            entity.Property(e => e.SmsSent)
                .IsUnicode(false)
                .HasColumnName("sms_sent");
            entity.Property(e => e.Status)
                .IsUnicode(false)
                .HasColumnName("status");
            entity.Property(e => e.SubmitTime)
                .IsUnicode(false)
                .HasColumnName("submit_time");
            entity.Property(e => e.SubmittedStatus)
                .IsUnicode(false)
                .HasColumnName("submitted_status");
            entity.Property(e => e.Supplied)
                .IsUnicode(false)
                .HasColumnName("supplied");
            entity.Property(e => e.Toothnos)
                .IsUnicode(false)
                .HasColumnName("toothnos");
            entity.Property(e => e.TotalPrice)
                .IsUnicode(false)
                .HasColumnName("total_price");
            entity.Property(e => e.TypeOfVisit)
                .IsUnicode(false)
                .HasColumnName("type_of_visit");
            entity.Property(e => e.UnitPrice).HasColumnName("unit_price");
            entity.Property(e => e.UserId)
                .IsUnicode(false)
                .HasColumnName("user_id");
            entity.Property(e => e.ValidationKey)
                .IsUnicode(false)
                .HasColumnName("validation_key");
            entity.Property(e => e.ValidationPin)
                .IsUnicode(false)
                .HasColumnName("validation_pin");
        });

        modelBuilder.Entity<TblClaimsDetailsMySqlDeleted>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("tblClaimsDetails_MySql_deleted");

            entity.Property(e => e.Id)
                .HasMaxLength(500)
                .IsUnicode(false)
                .HasColumnName("id");
            entity.Property(e => e.IsDeleted)
                .HasDefaultValue(0)
                .HasColumnName("isDeleted");
            entity.Property(e => e.MemberNo)
                .HasMaxLength(500)
                .IsUnicode(false)
                .HasColumnName("member_no");
            entity.Property(e => e.ProcessClaimNo)
                .HasMaxLength(500)
                .IsUnicode(false)
                .HasColumnName("process_claim_no");
            entity.Property(e => e.ProviderDataId)
                .HasMaxLength(500)
                .IsUnicode(false)
                .HasColumnName("provider_data_id");
            entity.Property(e => e.ProviderId)
                .HasMaxLength(500)
                .IsUnicode(false)
                .HasColumnName("provider_id");
            entity.Property(e => e.RowId)
                .ValueGeneratedOnAdd()
                .HasColumnName("RowID");
            entity.Property(e => e.ServerId)
                .HasMaxLength(500)
                .IsUnicode(false)
                .HasColumnName("server_id");
        });

        modelBuilder.Entity<TblClaimsDetailsReIssue>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK_ClaimsDetails_ReIssues");

            entity.ToTable("tblClaimsDetails_ReIssues");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.ApprovedAmount).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.BatchNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Claimed).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ClaimsDetailsId).HasColumnName("ClaimsDetailsID");
            entity.Property(e => e.ClaimsNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Diff)
                .HasComputedColumnSql("([Claimed]-[ApprovedAmount])", false)
                .HasColumnType("decimal(19, 2)");
            entity.Property(e => e.ProductId).HasColumnName("ProductID");
            entity.Property(e => e.ReviewAwarded)
                .HasDefaultValue(0m)
                .HasColumnType("decimal(18, 2)");
            entity.Property(e => e.StampDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.VettingId).HasColumnName("VettingID");

            entity.HasOne(d => d.ClaimsNoNavigation).WithMany(p => p.TblClaimsDetailsReIssues)
                .HasForeignKey(d => d.ClaimsNo)
                .HasConstraintName("FK_tblClaimsDetails_ReIssues_tblClaimsHeader");

            entity.HasOne(d => d.Product).WithMany(p => p.TblClaimsDetailsReIssues)
                .HasForeignKey(d => d.ProductId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblClaimsDetails_ReIssues_tblTariff");
        });

        modelBuilder.Entity<TblClaimsDetailsXTariffRejection>(entity =>
        {
            entity.HasKey(e => e.RowId).HasName("PK_ClaimsDetails_X_Tariff_Rejections");

            entity.ToTable("tblClaimsDetails_X_Tariff_Rejections");

            entity.HasIndex(e => e.ClaimsDetailsId, "IX_tblClaimsDetails_X_Tariff_Rejections_ClaimsDetailsID");

            entity.HasIndex(e => e.ClaimsNo, "IX_tblClaimsDetails_X_Tariff_Rejections_ClaimsNo");

            entity.Property(e => e.RowId).HasColumnName("RowID");
            entity.Property(e => e.ClaimsDetailsId).HasColumnName("ClaimsDetailsID");
            entity.Property(e => e.ClaimsNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.RejectedAmount).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.RxRowId).HasColumnName("RX_rowID");
            entity.Property(e => e.StampDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.TariffId).HasColumnName("TariffID");
            entity.Property(e => e.TariffXRejectionCommentId).HasColumnName("Tariff_X_RejectionCommentID");
            entity.Property(e => e.UserId).HasColumnName("UserID");

            entity.HasOne(d => d.ClaimsDetails).WithMany(p => p.TblClaimsDetailsXTariffRejections)
                .HasForeignKey(d => d.ClaimsDetailsId)
                .OnDelete(DeleteBehavior.Cascade)
                .HasConstraintName("FK_tblClaimsDetails_X_Tariff_Rejections_tblClaimsDetails");
        });

        modelBuilder.Entity<TblClaimsDiagnosisTem>(entity =>
        {
            entity.HasKey(e => e.ClaimsNo).HasName("PK_ClaimsDiagnosis_Tem");

            entity.ToTable("tblClaimsDiagnosis_Tem");

            entity.Property(e => e.ClaimsNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ConfirmedDiagnosis)
                .IsUnicode(false)
                .HasColumnName("Confirmed_Diagnosis");
            entity.Property(e => e.Diagnosis).IsUnicode(false);

            entity.HasOne(d => d.ClaimsNoNavigation).WithOne(p => p.TblClaimsDiagnosisTem)
                .HasForeignKey<TblClaimsDiagnosisTem>(d => d.ClaimsNo)
                .HasConstraintName("FK_tblClaimsDiagnosis_Tem_tblClaimsHeader");
        });

        modelBuilder.Entity<TblClaimsHeader>(entity =>
        {
            entity.HasKey(e => e.ClaimsNo).HasName("PK_ClaimsHeader");

            entity.ToTable("tblClaimsHeader");

            entity.HasIndex(e => e.ClaimsBatchNo, "IX_tblClaimsHeader");

            entity.HasIndex(e => new { e.NmhProviderId, e.AttendYear, e.AttendMonth }, "IX_tblClaimsHeader_1");

            entity.HasIndex(e => e.MemberId, "IX_tblClaimsHeader_2");

            entity.Property(e => e.ClaimsNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Attend).HasColumnType("datetime");
            entity.Property(e => e.ChequeAmount)
                .HasColumnType("decimal(18, 2)")
                .HasColumnName("chequeAmount");
            entity.Property(e => e.ChequeNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ClaimType).HasDefaultValue(0);
            entity.Property(e => e.Comments)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.DateStamp).HasColumnType("datetime");
            entity.Property(e => e.DateofAttendance).HasColumnType("datetime");
            entity.Property(e => e.HeaderComemntId).HasColumnName("Header_ComemntID");
            entity.Property(e => e.Id)
                .ValueGeneratedOnAdd()
                .HasColumnName("ID");
            entity.Property(e => e.InOutId).HasColumnName("InOutID");
            entity.Property(e => e.MemberId).HasColumnName("MemberID");
            entity.Property(e => e.MoMoName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.MoMoNumber)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.NmhProviderId).HasColumnName("NMH_ProviderID");
            entity.Property(e => e.NotAMember)
                .HasMaxLength(500)
                .IsUnicode(false)
                .HasColumnName("NotA_Member");
            entity.Property(e => e.PaymentModeId).HasColumnName("PaymentModeID");
            entity.Property(e => e.PolicyCodeId).HasColumnName("PolicyCodeID");
            entity.Property(e => e.PrescriptionAvaliable).HasDefaultValue(0);
            entity.Property(e => e.ProviderAmountClaimed).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ProviderComment)
                .HasMaxLength(300)
                .IsUnicode(false);
            entity.Property(e => e.RefunPayStatus).HasDefaultValue(5);
            entity.Property(e => e.RefundBank).HasDefaultValue(0);
            entity.Property(e => e.RefundSmsSent)
                .HasDefaultValue(0)
                .HasColumnName("RefundSMS_Sent");
            entity.Property(e => e.RejectedAmount)
                .HasDefaultValue(0.0m)
                .HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ReviewAwarded)
                .HasDefaultValue(0.0m)
                .HasColumnType("decimal(18, 2)");
            entity.Property(e => e.RxMasterProviderId).HasColumnName("rx_Master_ProviderID");
            entity.Property(e => e.RxProviderId).HasColumnName("rx_ProviderID");
            entity.Property(e => e.RxProviderName)
                .HasMaxLength(500)
                .IsUnicode(false)
                .HasColumnName("rx_Provider_Name");
            entity.Property(e => e.StampDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.SysAmountAwarded).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.SysAmountClaimed).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.TotalAwarded).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Tpa)
                .HasDefaultValue(0)
                .HasColumnName("TPA");
            entity.Property(e => e.UserId).HasColumnName("UserID");
            entity.Property(e => e.Vetted).HasDefaultValue(false);
            entity.Property(e => e.VettedDate).HasColumnType("datetime");

            entity.HasOne(d => d.ClaimsBatchNoNavigation).WithMany(p => p.TblClaimsHeaders)
                .HasForeignKey(d => d.ClaimsBatchNo)
                .OnDelete(DeleteBehavior.Cascade)
                .HasConstraintName("FK_tblClaimsHeader_tblClaimsBatch");
        });

        modelBuilder.Entity<TblClaimsHeaderXDisease>(entity =>
        {
            entity.HasKey(e => e.RowId).HasName("PK_ClaimsHeader_X_Disease");

            entity.ToTable("tblClaimsHeader_X_Disease");

            entity.HasIndex(e => new { e.ClaimsNo, e.DiseaseId }, "IX_tblClaimsHeader_X_Disease");

            entity.Property(e => e.RowId).HasColumnName("RowID");
            entity.Property(e => e.ClaimsNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.DiseaseId).HasColumnName("DiseaseID");

            entity.HasOne(d => d.ClaimsNoNavigation).WithMany(p => p.TblClaimsHeaderXDiseases)
                .HasForeignKey(d => d.ClaimsNo)
                .HasConstraintName("FK_tblClaimsHeader_X_Disease_tblClaimsHeader");

            entity.HasOne(d => d.Disease).WithMany(p => p.TblClaimsHeaderXDiseases)
                .HasForeignKey(d => d.DiseaseId)
                .HasConstraintName("FK_tblClaimsHeader_X_Disease_tblDisease");
        });

        modelBuilder.Entity<TblClaimsPayment>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK_ClaimsPayments");

            entity.ToTable("tblClaimsPayments");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.AmountWord)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.BankId).HasColumnName("BankID");
            entity.Property(e => e.ChequeAmount).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ChequeDate).HasColumnType("datetime");
            entity.Property(e => e.ChequeNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.DateStamp)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Smsstatus).HasColumnName("SMSStatus");

            entity.HasOne(d => d.BatchNoNavigation).WithMany(p => p.TblClaimsPayments)
                .HasForeignKey(d => d.BatchNo)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblClaimsPayments_tblClaimsBatch");
        });

        modelBuilder.Entity<TblClaimsReceivedHsp>(entity =>
        {
            entity.HasKey(e => e.BatchNo);

            entity.ToTable("tblClaimsReceived_HSP");

            entity.Property(e => e.BatchNo).ValueGeneratedNever();
            entity.Property(e => e.AmountClaimed).HasColumnType("numeric(18, 2)");
            entity.Property(e => e.AutoId).ValueGeneratedOnAdd();
            entity.Property(e => e.BatchType)
                .HasMaxLength(2)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.CustomerId)
                .HasMaxLength(13)
                .IsUnicode(false)
                .HasColumnName("CustomerID");
            entity.Property(e => e.DateOfClaim).HasColumnType("datetime");
            entity.Property(e => e.MonthOfClaim)
                .HasMaxLength(61)
                .IsUnicode(false);
            entity.Property(e => e.OnlinePush).HasDefaultValue(false);
            entity.Property(e => e.Processed).HasDefaultValue(false);
            entity.Property(e => e.ProcessedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ProcessedDate).HasColumnType("datetime");
            entity.Property(e => e.ServiceProvideId).HasColumnName("ServiceProvideID");
            entity.Property(e => e.ServiceProvider)
                .HasMaxLength(100)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblClientAppreciation>(entity =>
        {
            entity.ToTable("tblClientAppreciation");

            entity.Property(e => e.AwardType)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Criteria)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Names).IsUnicode(false);
            entity.Property(e => e.RewardType)
                .HasMaxLength(20)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblClientInteraction>(entity =>
        {
            entity.ToTable("tblClientInteraction");

            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.EventDate).HasColumnType("datetime");
            entity.Property(e => e.Issues)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.Participants)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.Recommendations)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.Venue)
                .HasMaxLength(100)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblClientLetter>(entity =>
        {
            entity.ToTable("tblClientLetters");

            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.CrofficerId).HasColumnName("CROfficerId");
            entity.Property(e => e.DueDate).HasColumnType("datetime");
            entity.Property(e => e.Lmode)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("LMode");
            entity.Property(e => e.Lmonth).HasColumnName("LMonth");
            entity.Property(e => e.Lperiod)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("LPeriod");
            entity.Property(e => e.Ltype)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("LType");
            entity.Property(e => e.Lyear).HasColumnName("LYear");
            entity.Property(e => e.Topic)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblClientRefund>(entity =>
        {
            entity.ToTable("tblClientRefunds");

            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.MemberName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Outcome)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.OutcomeReason)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.PaymentMode)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.Status)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.SubmissionDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<TblClientSession>(entity =>
        {
            entity.ToTable("tblClientSessions");

            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Feedback)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.Issues)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.Resolutions)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.SessionDate).HasColumnType("datetime");
            entity.Property(e => e.SessionType)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.Theme)
                .HasMaxLength(100)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblClientVisitation>(entity =>
        {
            entity.ToTable("tblClientVisitation");

            entity.Property(e => e.ClientRep)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Feedback)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.Issues)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.Nmirep)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("NMIRep");
            entity.Property(e => e.Resolutions)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.VisitDate).HasColumnType("datetime");
            entity.Property(e => e.VisitType)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblCommunity>(entity =>
        {
            entity.ToTable("tblCommunity");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.Community)
                .HasMaxLength(100)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblCompaniesSale>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK_tblCompany_Sales");

            entity.ToTable("tblCompanies_Sales");

            entity.Property(e => e.ActuarialApproved).HasDefaultValue(false);
            entity.Property(e => e.ActuarialApprovedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ActuarialApprovedDate).HasColumnType("datetime");
            entity.Property(e => e.BusinessApprovalDate).HasColumnType("datetime");
            entity.Property(e => e.BusinessApproved).HasDefaultValue(false);
            entity.Property(e => e.BusinessApprovedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.BusinessDate).HasColumnType("datetime");
            entity.Property(e => e.CompanyApprovalBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CompanyApprovalDate).HasColumnType("datetime");
            entity.Property(e => e.CompanyApprovalPosition)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CompanyCardName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CompanyName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ContactPerson)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ContactPersonEmail)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ContactPersonPhone)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.ContactPersonPhone2)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.DigitalAddress)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.Email)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.IsGroupPolicy).HasDefaultValue(true);
            entity.Property(e => e.OfficeLocation)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.PostalAddress)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ProposedStartDate).HasColumnType("datetime");
            entity.Property(e => e.RegistrationNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.SourceOfBusiness)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.Telephone1)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.Telephone2)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.Tin)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("TIN");
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<TblCompany>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK_tblCompany");

            entity.ToTable("tblCompanies");

            entity.Property(e => e.ActuarialApproved).HasDefaultValue(false);
            entity.Property(e => e.ActuarialApprovedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ActuarialApprovedDate).HasColumnType("datetime");
            entity.Property(e => e.BusinessApprovalDate).HasColumnType("datetime");
            entity.Property(e => e.BusinessApproved).HasDefaultValue(false);
            entity.Property(e => e.BusinessApprovedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.BusinessDate).HasColumnType("datetime");
            entity.Property(e => e.CardExpires).HasDefaultValue(1);
            entity.Property(e => e.CompanyApprovalBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CompanyApprovalDate).HasColumnType("datetime");
            entity.Property(e => e.CompanyApprovalPosition)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CompanyCardName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CompanyExpires).HasColumnType("datetime");
            entity.Property(e => e.CompanyName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.CompanyShortName)
                .HasMaxLength(10)
                .IsUnicode(false);
            entity.Property(e => e.ContactPerson)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ContactPersonEmail)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ContactPersonPhone)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ContactPersonPhone2)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.DigitalAddress)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.Email)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ExpiryDate).HasColumnType("datetime");
            entity.Property(e => e.IndividualLimit)
                .HasDefaultValue(0)
                .HasColumnName("Individual_Limit");
            entity.Property(e => e.OfficeLocation)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.OnlineStatus).HasDefaultValue(0);
            entity.Property(e => e.PostalAddress)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ProposedStartDate).HasColumnType("datetime");
            entity.Property(e => e.RegistrationNo)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.SourceOfBusiness)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.StartDate).HasColumnType("datetime");
            entity.Property(e => e.StatusId).HasColumnName("StatusID");
            entity.Property(e => e.Telephone1)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Telephone2)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.Tin)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("TIN");
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<TblCompanyContact>(entity =>
        {
            entity.ToTable("tblCompanyContacts");

            entity.Property(e => e.ContactName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ContactNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.EmailAddress)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Rank)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblCompanyCrofficer>(entity =>
        {
            entity.ToTable("tblCompanyCROfficer");

            entity.Property(e => e.Active).HasDefaultValue(true);
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.CrofficerId).HasColumnName("CROfficerId");
            entity.Property(e => e.DateAssigned).HasColumnType("datetime");
        });

        modelBuilder.Entity<TblCompanyPlan>(entity =>
        {
            entity.ToTable("tblCompanyPlans");

            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.PolicyCode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Premium).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<TblCompanyPlanBenefitGroup>(entity =>
        {
            entity.ToTable("tblCompanyPlan_BenefitGroups");

            entity.HasIndex(e => new { e.PolicyCode, e.PlanId, e.BenefitGroupId }, "IX_tblCompanyPlan_BenefitGroups");

            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Limit)
                .HasDefaultValue(0m)
                .HasColumnType("decimal(18, 2)");
            entity.Property(e => e.PolicyCode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Updated).HasDefaultValue(false);
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            entity.Property(e => e.UpdatedOnline).HasDefaultValue(false);
        });

        modelBuilder.Entity<TblCompanyPlanBenefitGroupsRenewal>(entity =>
        {
            entity.ToTable("tblCompanyPlan_BenefitGroups_Renewals");

            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Limit)
                .HasDefaultValue(0m)
                .HasColumnType("decimal(18, 2)");
            entity.Property(e => e.PolicyCode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Updated).HasDefaultValue(false);
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<TblCompanyPlanBenefitGroupsSale>(entity =>
        {
            entity.ToTable("tblCompanyPlan_BenefitGroups_Sales");

            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Limit)
                .HasDefaultValue(0m)
                .HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Updated).HasDefaultValue(false);
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<TblCompanyPlanBenefitLimit>(entity =>
        {
            entity.HasKey(e => e.RowId);

            entity.ToTable("tblCompanyPlan_BenefitLimits");

            entity.HasIndex(e => new { e.PolicyCode, e.PlanId, e.BenefitId }, "IX_tblCompanyPlan_BenefitLimits").IsUnique();

            entity.Property(e => e.RowId).HasColumnName("RowID");
            entity.Property(e => e.AdultCoverLimit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.BenefitId).HasColumnName("BenefitID");
            entity.Property(e => e.ChildCoverLimit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.CostPerVisit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.CoverComment)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.CoverLimit).HasDefaultValue(0.0);
            entity.Property(e => e.CoverStatus)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.FemaleCoverLimit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.MaleCoverLimit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.PlanId).HasColumnName("PlanID");
            entity.Property(e => e.PolicyCode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Updated).HasDefaultValue(false);
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            entity.Property(e => e.UpdatedOnline).HasDefaultValue(false);
        });

        modelBuilder.Entity<TblCompanyPlanBenefitLimitsRenewal>(entity =>
        {
            entity.HasKey(e => e.RowId);

            entity.ToTable("tblCompanyPlan_BenefitLimits_Renewals");

            entity.HasIndex(e => new { e.PolicyCode, e.PlanId, e.BenefitId }, "IX_tblCompanyPlan_BenefitLimits_Renewals").IsUnique();

            entity.Property(e => e.RowId).HasColumnName("RowID");
            entity.Property(e => e.AdultCoverLimit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.BenefitId).HasColumnName("BenefitID");
            entity.Property(e => e.ChildCoverLimit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.CostPerVisit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.CoverComment)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.CoverLimit).HasDefaultValue(0.0);
            entity.Property(e => e.CoverStatus)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.FemaleCoverLimit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.MaleCoverLimit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.PlanId).HasColumnName("PlanID");
            entity.Property(e => e.PolicyCode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Updated).HasDefaultValue(false);
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<TblCompanyPlanBenefitLimitsSale>(entity =>
        {
            entity.HasKey(e => e.RowId);

            entity.ToTable("tblCompanyPlan_BenefitLimits_Sales");

            entity.HasIndex(e => new { e.CompanyId, e.PlanId, e.BenefitId }, "IX_tblCompanyPlan_BenefitLimits_Sales").IsUnique();

            entity.Property(e => e.RowId).HasColumnName("RowID");
            entity.Property(e => e.AdultCoverLimit)
                .HasDefaultValue(0m)
                .HasColumnType("decimal(18, 2)");
            entity.Property(e => e.BenefitId).HasColumnName("BenefitID");
            entity.Property(e => e.ChildCoverLimit)
                .HasDefaultValue(0m)
                .HasColumnType("decimal(18, 2)");
            entity.Property(e => e.CostPerVisit)
                .HasDefaultValue(0m)
                .HasColumnType("decimal(18, 2)");
            entity.Property(e => e.CoverComment)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.CoverLimit)
                .HasDefaultValue(0.0m)
                .HasColumnType("decimal(18, 2)");
            entity.Property(e => e.CoverStatus)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.CustomBenefitTypeId).HasDefaultValue(1);
            entity.Property(e => e.FemaleCoverLimit)
                .HasDefaultValue(0m)
                .HasColumnType("decimal(18, 2)");
            entity.Property(e => e.MaleCoverLimit)
                .HasDefaultValue(0m)
                .HasColumnType("decimal(18, 2)");
            entity.Property(e => e.PlanId).HasColumnName("PlanID");
            entity.Property(e => e.Sessions).HasDefaultValue(0);
            entity.Property(e => e.Updated).HasDefaultValue(false);
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<TblCompanyPlanBenefitParent>(entity =>
        {
            entity.ToTable("tblCompanyPlan_BenefitParent");

            entity.HasIndex(e => new { e.PolicyCode, e.PlanId, e.BenefitParentId }, "IX_tblCompanyPlan_BenefitParent");

            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Limit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.PolicyCode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Updated).HasDefaultValue(false);
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            entity.Property(e => e.UpdatedOnline).HasDefaultValue(false);
        });

        modelBuilder.Entity<TblCompanyPlanBenefitParentRenewal>(entity =>
        {
            entity.ToTable("tblCompanyPlan_BenefitParent_Renewals");

            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Limit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.PolicyCode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Updated).HasDefaultValue(false);
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<TblCompanyPlanBenefitParentSale>(entity =>
        {
            entity.ToTable("tblCompanyPlan_BenefitParent_Sales");

            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Limit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Updated).HasDefaultValue(false);
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<TblCompanyPlanMasterLimit>(entity =>
        {
            entity.ToTable("tblCompanyPlan_MasterLimit");

            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Limit)
                .HasDefaultValue(0m)
                .HasColumnType("decimal(18, 2)");
            entity.Property(e => e.PolicyCode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Updated).HasDefaultValue(false);
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

            entity.HasOne(d => d.InOut).WithMany(p => p.TblCompanyPlanMasterLimits)
                .HasForeignKey(d => d.InOutId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblCompanyPlan_MasterLimit_tblIn_Out");

            entity.HasOne(d => d.Plan).WithMany(p => p.TblCompanyPlanMasterLimits)
                .HasForeignKey(d => d.PlanId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblCompanyPlan_MasterLimit_tblPlans");
        });

        modelBuilder.Entity<TblCompanyPlanMasterLimitRenewal>(entity =>
        {
            entity.ToTable("tblCompanyPlan_MasterLimit_Renewals");

            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Limit)
                .HasDefaultValue(0m)
                .HasColumnType("decimal(18, 2)");
            entity.Property(e => e.PolicyCode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Updated).HasDefaultValue(false);
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

            entity.HasOne(d => d.InOut).WithMany(p => p.TblCompanyPlanMasterLimitRenewals)
                .HasForeignKey(d => d.InOutId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblCompanyPlan_MasterLimit_Renewals_tblIn_Out");

            entity.HasOne(d => d.Plan).WithMany(p => p.TblCompanyPlanMasterLimitRenewals)
                .HasForeignKey(d => d.PlanId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblCompanyPlan_MasterLimit_Renewals_tblPlans");
        });

        modelBuilder.Entity<TblCompanyPlanMasterLimitSale>(entity =>
        {
            entity.ToTable("tblCompanyPlan_MasterLimit_Sales");

            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Limit)
                .HasDefaultValue(0m)
                .HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Updated).HasDefaultValue(false);
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

            entity.HasOne(d => d.InOut).WithMany(p => p.TblCompanyPlanMasterLimitSales)
                .HasForeignKey(d => d.InOutId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblCompanyPlan_MasterLimit_Sales_tblIn_Out");

            entity.HasOne(d => d.Plan).WithMany(p => p.TblCompanyPlanMasterLimitSales)
                .HasForeignKey(d => d.PlanId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblCompanyPlan_MasterLimit_Sales_tblPlans");
        });

        modelBuilder.Entity<TblCompanyPlansRenewal>(entity =>
        {
            entity.ToTable("tblCompanyPlans_Renewals");

            entity.HasIndex(e => new { e.PolicyCode, e.PlanId, e.MemberTypeId }, "IX_tblCompanyPlans_Renewals").IsUnique();

            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.PolicyCode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Premium).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ProposedPremium)
                .HasDefaultValue(0m)
                .HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ProposedPremiumApproved).HasDefaultValue(false);
            entity.Property(e => e.ProposedPremiumApprovedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ProposedPremiumApprovedDate).HasColumnType("datetime");
            entity.Property(e => e.ProposedPremiumBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ProposedPremiumDate).HasColumnType("datetime");
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<TblCompanyPlansSale>(entity =>
        {
            entity.ToTable("tblCompanyPlans_Sales");

            entity.HasIndex(e => new { e.CompanyId, e.PlanId, e.MemberTypeId }, "IX_tblCompanyPlans_Sales").IsUnique();

            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Premium).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<TblCompanyPolicy>(entity =>
        {
            entity.ToTable("tblCompanyPolicy");

            entity.HasIndex(e => e.PolicyCode, "IX_tblCompanyPolicy").IsUnique();

            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Customized).HasDefaultValue(false);
            entity.Property(e => e.PolicyActive).HasDefaultValue(true);
            entity.Property(e => e.PolicyCode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PolicyEndDate).HasColumnType("datetime");
            entity.Property(e => e.PolicyStartDate).HasColumnType("datetime");
            entity.Property(e => e.PolicyStarted).HasDefaultValue(false);
            entity.Property(e => e.StartedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.StartedDate).HasColumnType("datetime");
            entity.Property(e => e.Terminated).HasDefaultValue(false);
            entity.Property(e => e.TerminatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.TerminatedDate).HasColumnType("datetime");
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            entity.Property(e => e.UpdatedOnline).HasDefaultValue(false);
        });

        modelBuilder.Entity<TblCompanyPolicySale>(entity =>
        {
            entity.ToTable("tblCompanyPolicy_Sales");

            entity.HasIndex(e => e.PolicyCode, "IX_tblCompanyPolicy_Sales").IsUnique();

            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.PolicyActive).HasDefaultValue(true);
            entity.Property(e => e.PolicyCode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PolicyEndDate).HasColumnType("datetime");
            entity.Property(e => e.PolicyStartDate).HasColumnType("datetime");
            entity.Property(e => e.TerminatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.TerminatedDate).HasColumnType("datetime");
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<TblCompanyRenewal>(entity =>
        {
            entity.ToTable("tblCompanyRenewals");

            entity.HasIndex(e => e.PolicyCode, "IX_tblCompanyRenewals").IsUnique();

            entity.Property(e => e.ActuarialApproved).HasDefaultValue(false);
            entity.Property(e => e.ActuarialApprovedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ActuarialApprovedDate).HasColumnType("datetime");
            entity.Property(e => e.Approved).HasDefaultValue(false);
            entity.Property(e => e.ApprovedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ApprovedDate).HasColumnType("datetime");
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.PolicyCode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PolicyEndDate).HasColumnType("datetime");
            entity.Property(e => e.PolicyStartDate).HasColumnType("datetime");
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<TblCompanyRenewalFileUpload>(entity =>
        {
            entity.ToTable("tblCompanyRenewal_FileUploads");

            entity.Property(e => e.CompanyId).HasColumnName("CompanyID");
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.FileName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.FilePath)
                .HasMaxLength(200)
                .IsUnicode(false);
            entity.Property(e => e.FileType)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.PolicyCode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ReportType)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblCompanySalesComment>(entity =>
        {
            entity.ToTable("tblCompany_Sales_Comments");

            entity.Property(e => e.Comment)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
        });

        modelBuilder.Entity<TblCompanySalesResponse>(entity =>
        {
            entity.ToTable("tblCompany_Sales_Responses");

            entity.Property(e => e.Comment)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");

            entity.HasOne(d => d.Company).WithMany(p => p.TblCompanySalesResponses)
                .HasForeignKey(d => d.CompanyId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblCompany_Sales_Responses_tblCompanies_Sales");
        });

        modelBuilder.Entity<TblCompanyServiceProvider>(entity =>
        {
            entity.ToTable("tblCompanyServiceProviders");

            entity.HasIndex(e => new { e.PolicyCode, e.ServiceProviderId }, "IX_tblCompanyServiceProviders").IsUnique();

            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.PolicyCode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<TblCompanyServiceProvidersRenewal>(entity =>
        {
            entity.ToTable("tblCompanyServiceProviders_Renewals");

            entity.HasIndex(e => new { e.PolicyCode, e.ServiceProviderId }, "IX_tblCompanyServiceProviders_Renewals").IsUnique();

            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.PolicyCode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<TblCompanyStatus>(entity =>
        {
            entity.ToTable("tblCompanyStatus");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.Status)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblCompanyXLogo>(entity =>
        {
            entity.HasKey(e => e.RowId);

            entity.ToTable("tblCompany_X_Logo");

            entity.Property(e => e.RowId).HasColumnName("RowID");
            entity.Property(e => e.CompanyId).HasColumnName("CompanyID");
            entity.Property(e => e.Logo).HasColumnType("image");
        });

        modelBuilder.Entity<TblCrmescalationLevel>(entity =>
        {
            entity.HasKey(e => e.EscalateLevel);

            entity.ToTable("tblCRMEscalationLevels");

            entity.Property(e => e.EscalateLevel).ValueGeneratedNever();
            entity.Property(e => e.EscalateEmail)
                .HasMaxLength(100)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblCrmlogResponse>(entity =>
        {
            entity.ToTable("tblCRMLogResponses");

            entity.Property(e => e.Comment)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.FollowUp).HasDefaultValue(false);
        });

        modelBuilder.Entity<TblCrmlogSource>(entity =>
        {
            entity.ToTable("tblCRMLogSource");

            entity.Property(e => e.Description)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblCrmserviceType>(entity =>
        {
            entity.ToTable("tblCRMServiceType");

            entity.Property(e => e.ServiceType)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblCustomerServiceMonth>(entity =>
        {
            entity.ToTable("tblCustomerServiceMonth");

            entity.Property(e => e.Activities)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.EventDate).HasColumnType("datetime");
            entity.Property(e => e.Remarks)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.Theme)
                .HasMaxLength(100)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblDepartment>(entity =>
        {
            entity.ToTable("tblDepartment");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Active).HasDefaultValue(false);
            entity.Property(e => e.Department)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.EmailAddress)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblDisease>(entity =>
        {
            entity.HasKey(e => e.DiseaseId).HasName("PK_Disease");

            entity.ToTable("tblDisease");

            entity.Property(e => e.DiseaseId).HasColumnName("DiseaseID");
            entity.Property(e => e.BlockCode)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.BlockId)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("BlockID");
            entity.Property(e => e.ChapterId)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("ChapterID");
            entity.Property(e => e.Code)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.Code1)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.Code2)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.Disease)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.DiseaseGroupCode)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.DiseaseGroupId).HasColumnName("DiseaseGroupID");
            entity.Property(e => e.Field11)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.Field12)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.Field13)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.Field14)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.Level)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.PlaceOfClass)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.TypeOfCode)
                .HasMaxLength(20)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblDiseaseGroup>(entity =>
        {
            entity.HasKey(e => e.DiseaseGroupId).HasName("PK_DiseaseGroup");

            entity.ToTable("tblDiseaseGroup");

            entity.Property(e => e.DiseaseGroupId).HasColumnName("DiseaseGroupID");
            entity.Property(e => e.Disease)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.DiseaseGroupCode)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.DiseaseMainGroupCode)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.DiseaseMainGroupId).HasColumnName("DiseaseMainGroupID");
        });

        modelBuilder.Entity<TblDiseaseMainGroup>(entity =>
        {
            entity.HasKey(e => e.DiseaseMainGroupId).HasName("PK_DiseaseMainGroup");

            entity.ToTable("tblDiseaseMainGroup");

            entity.Property(e => e.DiseaseMainGroupId).HasColumnName("DiseaseMainGroupID");
            entity.Property(e => e.DiseaseBlockCode)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.DiseaseMainGroupName)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.DiseaseParentCode)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.DiseaseParentGroupId).HasColumnName("DiseaseParentGroupID");
            entity.Property(e => e.Field2)
                .HasMaxLength(20)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblDiseaseParentGroup>(entity =>
        {
            entity.HasKey(e => e.DiseaseParentGroupId).HasName("PK_DiseaseParentGroup");

            entity.ToTable("tblDiseaseParentGroup");

            entity.Property(e => e.DiseaseParentGroupId).HasColumnName("DiseaseParentGroupID");
            entity.Property(e => e.DiseaseParentCode)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.DiseaseParentGroupName)
                .HasMaxLength(200)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblDiseaseXTariff>(entity =>
        {
            entity.HasKey(e => e.RowId).HasName("PK_Disease_X_Tariff");

            entity.ToTable("tblDisease_X_Tariff");

            entity.HasIndex(e => new { e.DiseaseId, e.TariffId }, "IX_tblDisease_X_Tariff").IsUnique();

            entity.Property(e => e.RowId).HasColumnName("RowID");
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.DiseaseId).HasColumnName("DiseaseID");
            entity.Property(e => e.TariffId).HasColumnName("TariffID");
        });

        modelBuilder.Entity<TblDrugMap>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK_NMH_RX_DrugMap");

            entity.ToTable("tblDrugMap");

            entity.HasIndex(e => e.TariffId, "U_NMH_Tariff").IsUnique();

            entity.Property(e => e.DateStamp)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.DrugId).HasColumnName("DrugID");
            entity.Property(e => e.TariffId).HasColumnName("TariffID");
        });

        modelBuilder.Entity<TblDrugMapMobimed>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK_NMH_DrugMap_Mobimed");

            entity.ToTable("tblDrugMap_Mobimed");

            entity.HasIndex(e => e.TariffId, "IX_NMH_DrugMap_Mobimed").IsUnique();

            entity.Property(e => e.DateStamp)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.DrugId).HasColumnName("DrugID");
            entity.Property(e => e.TariffId).HasColumnName("TariffID");
        });

        modelBuilder.Entity<TblDrugMapPrice>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK_NMH_DrugMap_Prices");

            entity.ToTable("tblDrugMap_Prices");

            entity.HasIndex(e => e.DrugId, "IX_tblDrugMap_Prices_DrugId");

            entity.Property(e => e.DateStamp)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.EffectiveDate).HasColumnType("datetime");
            entity.Property(e => e.EndDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<TblDrugMapPricesMobimed>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK_NMH_DrugMap_Prices_Mobimed");

            entity.ToTable("tblDrugMap_Prices_Mobimed");

            entity.HasIndex(e => e.DrugId, "IX_tblDrugMap_Prices_Mobimed_DrugId");

            entity.Property(e => e.DateStamp)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.EffectiveDate).HasColumnType("datetime");
            entity.Property(e => e.EndDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<TblDrugPriceList>(entity =>
        {
            entity.HasKey(e => e.DrugId).HasName("PK_NMI_DrugList");

            entity.ToTable("tblDrugPriceList");

            entity.Property(e => e.DrugName).HasMaxLength(255);
            entity.Property(e => e.TariffId).HasColumnName("TariffID");
        });

        modelBuilder.Entity<TblDrugPriceListMobimed>(entity =>
        {
            entity.HasKey(e => e.DrugId).HasName("PK_DrugPriceList_Mobimed");

            entity.ToTable("tblDrugPriceList_Mobimed");

            entity.Property(e => e.DrugName)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.Mapped).HasDefaultValue(false);
        });

        modelBuilder.Entity<TblEmailUpdate>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("tblEmail_Update");

            entity.Property(e => e.DateStamp)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.IsUpdate)
                .HasDefaultValue(0)
                .HasColumnName("IS_Update");
            entity.Property(e => e.MemberId).HasColumnName("MemberID");
            entity.Property(e => e.NewEmail)
                .HasMaxLength(1000)
                .IsUnicode(false)
                .HasColumnName("New_email");
            entity.Property(e => e.OtherEmail)
                .HasMaxLength(1000)
                .IsUnicode(false)
                .HasColumnName("Other_Email");
            entity.Property(e => e.RowId)
                .ValueGeneratedOnAdd()
                .HasColumnName("RowID");
            entity.Property(e => e.RowIdOnline).HasColumnName("RowID_Online");
        });

        modelBuilder.Entity<TblFrontOfficeReceipt>(entity =>
        {
            entity.ToTable("tblFrontOfficeReceipt");

            entity.Property(e => e.Amount).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ContactNo)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.DateReceived).HasColumnType("datetime");
            entity.Property(e => e.Designation)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.DocumentType)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.MonthOfSubmission).HasColumnType("datetime");
            entity.Property(e => e.SubmittedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<TblGender>(entity =>
        {
            entity.ToTable("tblGenders");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.Gender)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.GenderShort)
                .HasMaxLength(10)
                .IsUnicode(false)
                .IsFixedLength();
        });

        modelBuilder.Entity<TblGhanaCardUpdate>(entity =>
        {
            entity.HasKey(e => e.GhId);

            entity.ToTable("tblGhanaCard_Update", tb => tb.HasTrigger("trgGhanaCard_Update"));

            entity.Property(e => e.GhId).ValueGeneratedNever();
            entity.Property(e => e.CardNumber)
                .HasMaxLength(15)
                .IsUnicode(false)
                .HasColumnName("Card_Number");
            entity.Property(e => e.Channel)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.DateTimeCreated)
                .HasColumnType("datetime")
                .HasColumnName("DateTime_Created");
        });

        modelBuilder.Entity<TblHealthScreening>(entity =>
        {
            entity.ToTable("tblHealthScreening");

            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.HealthFacility)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ResourcePerson)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ScreenDate).HasColumnType("datetime");
            entity.Property(e => e.ScreenResults)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.ScreenStats)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.ScreenType)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblHealthTalk>(entity =>
        {
            entity.ToTable("tblHealthTalks");

            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.ResourcePerson)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.TalkDate).HasColumnType("datetime");
            entity.Property(e => e.Topic)
                .HasMaxLength(100)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblHronline>(entity =>
        {
            entity.HasKey(e => e.RowId).HasName("PK_HROnline");

            entity.ToTable("tblHROnline");

            entity.Property(e => e.RowId).HasColumnName("RowID");
            entity.Property(e => e.ApprovedStartDate)
                .HasColumnType("datetime")
                .HasColumnName("Approved_StartDate");
            entity.Property(e => e.Branch)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.ComapnyId)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("Comapny_Id");
            entity.Property(e => e.CompanyName)
                .HasMaxLength(500)
                .IsUnicode(false)
                .HasColumnName("Company_name");
            entity.Property(e => e.ConfirmRecord)
                .HasMaxLength(500)
                .IsUnicode(false)
                .HasColumnName("Confirm_Record");
            entity.Property(e => e.DataSource)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("dataSource");
            entity.Property(e => e.DateStemp)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.DateTimeCreated)
                .HasColumnType("datetime")
                .HasColumnName("DateTime_Created");
            entity.Property(e => e.District)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.Dob)
                .HasColumnType("datetime")
                .HasColumnName("dob");
            entity.Property(e => e.Email)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.Firstname)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.Gender)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.GhanaCard)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("Ghana_Card");
            entity.Property(e => e.ImageDownloaded)
                .HasDefaultValue(false)
                .HasColumnName("imageDownloaded");
            entity.Property(e => e.Imagepath)
                .HasMaxLength(200)
                .IsUnicode(false)
                .HasColumnName("imagepath");
            entity.Property(e => e.ImgLink)
                .HasMaxLength(500)
                .IsUnicode(false)
                .HasColumnName("img_link");
            entity.Property(e => e.IsEdit)
                .HasMaxLength(500)
                .IsUnicode(false)
                .HasColumnName("Is_edit");
            entity.Property(e => e.MandateNo)
                .HasMaxLength(500)
                .IsUnicode(false)
                .HasColumnName("Mandate_No");
            entity.Property(e => e.MemberType)
                .HasMaxLength(500)
                .IsUnicode(false)
                .HasColumnName("Member_type");
            entity.Property(e => e.NhisNo)
                .HasMaxLength(500)
                .IsUnicode(false)
                .HasColumnName("NHIS_no");
            entity.Property(e => e.NmhStatus)
                .HasDefaultValue(0)
                .HasColumnName("nmhStatus");
            entity.Property(e => e.OtherNames)
                .HasMaxLength(500)
                .IsUnicode(false)
                .HasColumnName("Other_names");
            entity.Property(e => e.PhoneNo2)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.Pin)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.PlanId)
                .HasMaxLength(500)
                .IsUnicode(false)
                .HasColumnName("Plan_id");
            entity.Property(e => e.PlanName)
                .HasMaxLength(500)
                .IsUnicode(false)
                .HasColumnName("Plan_name");
            entity.Property(e => e.PrimaryPhoneNo1)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.PrincipalId)
                .HasMaxLength(500)
                .IsUnicode(false)
                .HasColumnName("principal_id");
            entity.Property(e => e.PrincipalName)
                .HasMaxLength(500)
                .IsUnicode(false)
                .HasColumnName("Principal_name");
            entity.Property(e => e.Region)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.Registrar)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.RelationshipType)
                .HasMaxLength(500)
                .IsUnicode(false)
                .HasColumnName("Relationship_type");
            entity.Property(e => e.RelationshipTypeId).HasColumnName("relationship_typeId");
            entity.Property(e => e.Role).HasMaxLength(255);
            entity.Property(e => e.RowId1).HasColumnName("Row_Id");
            entity.Property(e => e.StaffId)
                .HasMaxLength(500)
                .IsUnicode(false)
                .HasColumnName("Staff_ID");
            entity.Property(e => e.Surname)
                .HasMaxLength(500)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblHronlineStatus>(entity =>
        {
            entity.ToTable("tblHROnline_Status");

            entity.Property(e => e.Id).ValueGeneratedNever();
            entity.Property(e => e.Status)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblInOut>(entity =>
        {
            entity.ToTable("tblIn_Out");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.Inout)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblMaritalStatus>(entity =>
        {
            entity.ToTable("tblMaritalStatus");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.Status)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.StatusCode)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblMember>(entity =>
        {
            entity.ToTable("tblMembers");

            entity.HasIndex(e => e.MembershipNo, "IX_tblMembers").IsUnique();

            entity.HasIndex(e => e.MemberNo, "IX_tblMembers_1");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.Barclaysbatch).HasColumnName("BARCLAYSBatch");
            entity.Property(e => e.BarclaysmemNo).HasColumnName("BARCLAYSMemNo");
            entity.Property(e => e.Barclaysno)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("BARCLAYSNo");
            entity.Property(e => e.BenefitOptionId).HasColumnName("BenefitOptionID");
            entity.Property(e => e.CardPin)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("cardPin");
            entity.Property(e => e.CompanyId).HasColumnName("CompanyID");
            entity.Property(e => e.Datedisabled).HasColumnType("datetime");
            entity.Property(e => e.DeptId).HasColumnName("DeptID");
            entity.Property(e => e.Dob).HasColumnName("DOB");
            entity.Property(e => e.Dob2).HasColumnName("DOB2");
            entity.Property(e => e.Dobday)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("DOBDay");
            entity.Property(e => e.Dobmonth)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("DOBMonth");
            entity.Property(e => e.Dobyear)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("DOBYear");
            entity.Property(e => e.Email)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.EmpNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.EmployeeStatus)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.FirstName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Fname)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("FName");
            entity.Property(e => e.GenderId).HasColumnName("GenderID");
            entity.Property(e => e.GraBatch).HasColumnName("GRA_Batch");
            entity.Property(e => e.GraPrincipalId).HasColumnName("GRA_principal_id");
            entity.Property(e => e.Graid).HasColumnName("GRAID");
            entity.Property(e => e.HpAngina).HasColumnName("hp_Angina");
            entity.Property(e => e.HpAutoimmune).HasColumnName("hp_Autoimmune");
            entity.Property(e => e.HpBackNeck).HasColumnName("hp_Back_Neck");
            entity.Property(e => e.HpCancerTumours).HasColumnName("hp_Cancer_Tumours");
            entity.Property(e => e.HpCardiovascular).HasColumnName("hp_Cardiovascular");
            entity.Property(e => e.HpChronicBronchitis).HasColumnName("hp_ChronicBronchitis");
            entity.Property(e => e.HpChronicRespiratory).HasColumnName("hp_ChronicRespiratory");
            entity.Property(e => e.HpCongenitalHeart).HasColumnName("hp_Congenital_Heart");
            entity.Property(e => e.HpCysticFibrosis).HasColumnName("hp_CysticFibrosis");
            entity.Property(e => e.HpDiabetes).HasColumnName("hp_Diabetes");
            entity.Property(e => e.HpDigestiveSystem).HasColumnName("hp_DigestiveSystem");
            entity.Property(e => e.HpEmbolism).HasColumnName("hp_Embolism");
            entity.Property(e => e.HpEmphysema).HasColumnName("hp_Emphysema");
            entity.Property(e => e.HpEndocrine).HasColumnName("hp_Endocrine");
            entity.Property(e => e.HpFibroid).HasColumnName("hp_Fibroid");
            entity.Property(e => e.HpGallBladder).HasColumnName("hp_GallBladder");
            entity.Property(e => e.HpGout).HasColumnName("hp_Gout");
            entity.Property(e => e.HpHernia).HasColumnName("hp_Hernia");
            entity.Property(e => e.HpHypertension).HasColumnName("hp_Hypertension");
            entity.Property(e => e.HpIntestinalFibrosis).HasColumnName("hp_IntestinalFibrosis");
            entity.Property(e => e.HpKidney).HasColumnName("hp_Kidney");
            entity.Property(e => e.HpLeukemia).HasColumnName("hp_Leukemia");
            entity.Property(e => e.HpLiver).HasColumnName("hp_Liver");
            entity.Property(e => e.HpLung).HasColumnName("hp_Lung");
            entity.Property(e => e.HpMoreInfo)
                .HasMaxLength(200)
                .IsUnicode(false)
                .HasColumnName("hp_MoreInfo");
            entity.Property(e => e.HpMusculoskeletal).HasColumnName("hp_Musculoskeletal");
            entity.Property(e => e.HpNephritis).HasColumnName("hp_Nephritis");
            entity.Property(e => e.HpOthers).HasColumnName("hp_Others");
            entity.Property(e => e.HpPregnant).HasColumnName("hp_Pregnant");
            entity.Property(e => e.Hphone)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.HronlineId)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasDefaultValueSql("((0))")
                .HasColumnName("HROnline_ID");
            entity.Property(e => e.HronlinePrinId)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("HROnline_Prin_ID");
            entity.Property(e => e.HronlineUpload)
                .HasDefaultValue(0)
                .HasColumnName("HROnline_Upload");
            entity.Property(e => e.IndvidualEx).HasColumnType("datetime");
            entity.Property(e => e.International)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.MailSent).HasDefaultValue(0);
            entity.Property(e => e.MaritalId).HasColumnName("MaritalID");
            entity.Property(e => e.MemberNo)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.MemberRegstDate).HasColumnType("datetime");
            entity.Property(e => e.MemberTypeId).HasColumnName("MemberTypeID");
            entity.Property(e => e.MembershipNo)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.Mphone)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.MyHealthPrincipalId).HasColumnName("MyHealth_PrincipalID");
            entity.Property(e => e.MyHealthRegistId).HasColumnName("MyHealth_RegistID");
            entity.Property(e => e.NationalIdno)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("NationalIDNo");
            entity.Property(e => e.NewMember)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Nhisno)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("NHISNo");
            entity.Property(e => e.OccupationId).HasColumnName("OccupationID");
            entity.Property(e => e.OldMembershipNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.OtherName)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("otherName");
            entity.Property(e => e.Picpath)
                .HasMaxLength(4000)
                .IsUnicode(false)
                .HasColumnName("picpath");
            entity.Property(e => e.PolicyStartDate).HasColumnType("datetime");
            entity.Property(e => e.PositionId).HasColumnName("PositionID");
            entity.Property(e => e.PrincipalId).HasColumnName("PrincipalID");
            entity.Property(e => e.Printed).HasDefaultValue(0);
            entity.Property(e => e.ProviderId).HasColumnName("ProviderID");
            entity.Property(e => e.RegId).HasColumnName("RegID");
            entity.Property(e => e.RegistrationDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.RelationId).HasColumnName("RelationID");
            entity.Property(e => e.ReplaceMemberNo).HasDefaultValue(true);
            entity.Property(e => e.RxOnlineId).HasColumnName("RX_OnlineID");
            entity.Property(e => e.SentSms)
                .HasDefaultValue(2)
                .HasColumnName("SentSMS");
            entity.Property(e => e.StaffId)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("StaffID");
            entity.Property(e => e.StaffTypeId).HasColumnName("StaffTypeID");
            entity.Property(e => e.StartDate).HasColumnType("datetime");
            entity.Property(e => e.Surname)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.TitleId).HasColumnName("TitleID");
            entity.Property(e => e.UniqueId).HasColumnName("UniqueID");
            entity.Property(e => e.Updated).HasColumnName("UPDATED");
            entity.Property(e => e.UploadDateTime).HasColumnType("datetime");

            entity.HasOne(d => d.Company).WithMany(p => p.TblMembers)
                .HasForeignKey(d => d.CompanyId)
                .HasConstraintName("FK_tblMembers_tblCompanies");

            entity.HasOne(d => d.Gender).WithMany(p => p.TblMembers)
                .HasForeignKey(d => d.GenderId)
                .HasConstraintName("FK_tblMembers_tblGenders");

            entity.HasOne(d => d.Marital).WithMany(p => p.TblMembers)
                .HasForeignKey(d => d.MaritalId)
                .HasConstraintName("FK_tblMembers_tblMaritalStatus");

            entity.HasOne(d => d.MemberType).WithMany(p => p.TblMembers)
                .HasForeignKey(d => d.MemberTypeId)
                .HasConstraintName("FK_tblMembers_tblMemberType");

            entity.HasOne(d => d.Occupation).WithMany(p => p.TblMembers)
                .HasForeignKey(d => d.OccupationId)
                .HasConstraintName("FK_tblMembers_tblOccupation");

            entity.HasOne(d => d.Relation).WithMany(p => p.TblMembers)
                .HasForeignKey(d => d.RelationId)
                .HasConstraintName("FK_tblMembers_tblRelation");

            entity.HasOne(d => d.StatusNavigation).WithMany(p => p.TblMembers)
                .HasForeignKey(d => d.Status)
                .HasConstraintName("FK_tblMembers_tblMemberStatus");

            entity.HasOne(d => d.Title).WithMany(p => p.TblMembers)
                .HasForeignKey(d => d.TitleId)
                .HasConstraintName("FK_tblMembers_tblTitles");
        });

        modelBuilder.Entity<TblMemberDeactivate>(entity =>
        {
            entity.HasKey(e => e.RowId);

            entity.ToTable("tblMember_Deactivate", tb => tb.HasTrigger("trgDeactivateMember"));

            entity.Property(e => e.RowId)
                .ValueGeneratedNever()
                .HasColumnName("Row_Id");
            entity.Property(e => e.DateStamp)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.DateTimeCreated)
                .HasColumnType("datetime")
                .HasColumnName("DateTime_Created");
            entity.Property(e => e.EffectiveDate).HasColumnName("Effective_Date");
            entity.Property(e => e.MemberId).HasColumnName("Member_ID");
            entity.Property(e => e.MembershipNo)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("Membership_No");
        });

        modelBuilder.Entity<TblMemberPlanBenefitGroup>(entity =>
        {
            entity.ToTable("tblMemberPlan_BenefitGroups");

            entity.HasIndex(e => new { e.PolicyCode, e.MemberId, e.PlanId, e.BenefitGroupId }, "IX_tblMemberPlan_BenefitGroups");

            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Limit)
                .HasDefaultValue(0m)
                .HasColumnType("decimal(18, 2)");
            entity.Property(e => e.PolicyCode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Updated).HasDefaultValue(false);
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            entity.Property(e => e.UpdatedOnline).HasDefaultValue(false);
        });

        modelBuilder.Entity<TblMemberPlanBenefitLimit>(entity =>
        {
            entity.HasKey(e => e.RowId);

            entity.ToTable("tblMemberPlan_BenefitLimits");

            entity.HasIndex(e => new { e.PolicyCode, e.MemberId, e.PlanId, e.BenefitId }, "IX_tblMemberPlan_BenefitLimits");

            entity.Property(e => e.RowId).HasColumnName("RowID");
            entity.Property(e => e.AdultCoverLimit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.BenefitId).HasColumnName("BenefitID");
            entity.Property(e => e.ChildCoverLimit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.CostPerVisit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.CoverComment)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.CoverLimit).HasDefaultValue(0.0);
            entity.Property(e => e.CoverStatus)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.FemaleCoverLimit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.MaleCoverLimit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.PlanId).HasColumnName("PlanID");
            entity.Property(e => e.PolicyCode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Updated).HasDefaultValue(false);
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            entity.Property(e => e.UpdatedOnline).HasDefaultValue(false);
        });

        modelBuilder.Entity<TblMemberPlanBenefitParent>(entity =>
        {
            entity.ToTable("tblMemberPlan_BenefitParent");

            entity.HasIndex(e => new { e.PolicyCode, e.MemberId, e.PlanId, e.BenefitParentId }, "IX_tblMemberPlan_BenefitParent");

            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Limit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.PolicyCode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Updated).HasDefaultValue(false);
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            entity.Property(e => e.UpdatedOnline).HasDefaultValue(false);
        });

        modelBuilder.Entity<TblMemberPolicy>(entity =>
        {
            entity.ToTable("tblMemberPolicy");

            entity.Property(e => e.Customized).HasDefaultValue(false);
            entity.Property(e => e.CustomizedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CustomizedDate).HasColumnType("datetime");
            entity.Property(e => e.DateStamp)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.EndDate).HasColumnType("datetime");
            entity.Property(e => e.PolicyNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.StartDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<TblMemberServiceProvider>(entity =>
        {
            entity.ToTable("tblMemberServiceProviders");

            entity.HasIndex(e => new { e.PolicyCode, e.MemberId, e.ServiceProviderId }, "IX_tblMemberServiceProviders").IsUnique();

            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.PolicyCode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<TblMemberStatus>(entity =>
        {
            entity.ToTable("tblMemberStatus");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.StatueCode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Status)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblMemberStatusInfo>(entity =>
        {
            entity.HasKey(e => e.RowId);

            entity.ToTable("tblMemberStatusInfo");

            entity.HasIndex(e => e.MemberId, "IX_tblMemberStatusInfo");

            entity.Property(e => e.RowId).HasColumnName("RowID");
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.EffectiveDate).HasColumnType("datetime");
            entity.Property(e => e.MemberId).HasColumnName("MemberID");
            entity.Property(e => e.StatusId).HasColumnName("StatusID");
            entity.Property(e => e.UserId).HasColumnName("UserID");
        });

        modelBuilder.Entity<TblMemberType>(entity =>
        {
            entity.ToTable("tblMemberType");

            entity.Property(e => e.ActualMemberType)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.MemberType)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblMemberTypeSale>(entity =>
        {
            entity.ToTable("tblMemberType_Sales");

            entity.Property(e => e.MemberType)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblMonthlyUsageHrportal>(entity =>
        {
            entity.ToTable("tblMonthlyUsage_HRPortal");

            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Remarks)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.UsagePeriod)
                .HasMaxLength(20)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblMonthlyUsageMobileApp>(entity =>
        {
            entity.ToTable("tblMonthlyUsage_MobileApps");

            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.MobileApp)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Remarks)
                .HasMaxLength(200)
                .IsUnicode(false);
            entity.Property(e => e.Traffic)
                .HasMaxLength(200)
                .IsUnicode(false);
            entity.Property(e => e.UsagePeriod)
                .HasMaxLength(20)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblMonthlyUsageMobimed>(entity =>
        {
            entity.ToTable("tblMonthlyUsage_Mobimed");

            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.NonSupplyReasons)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.Remarks)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.UsagePeriod)
                .HasMaxLength(20)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblMyHealthMembersBenefit>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("tblMyHealth_Members_Benefits");

            entity.Property(e => e.DateStamp).HasDefaultValueSql("(getutcdate())");
            entity.Property(e => e.IpLimit)
                .HasColumnType("decimal(18, 2)")
                .HasColumnName("IP_Limit");
            entity.Property(e => e.MyHealthPrincipalId).HasColumnName("MyHealth_PrincipalID");
            entity.Property(e => e.OpdLimit)
                .HasColumnType("decimal(18, 2)")
                .HasColumnName("OPD_Limit");
            entity.Property(e => e.PushStatus).HasDefaultValue(0);
            entity.Property(e => e.RowId)
                .ValueGeneratedOnAdd()
                .HasColumnName("RowID");
        });

        modelBuilder.Entity<TblNatureOfBusiness>(entity =>
        {
            entity.ToTable("tblNatureOfBusiness");

            entity.Property(e => e.NatureOfBusiness)
                .HasMaxLength(100)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblOccupation>(entity =>
        {
            entity.ToTable("tblOccupation");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.Occupation)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblOwnershipType>(entity =>
        {
            entity.ToTable("tblOwnershipType");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.Ownership)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblPaymentBatch>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK_Payment_Batch");

            entity.ToTable("tblPayment_Batch");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.BankId).HasColumnName("BankID");
        });

        modelBuilder.Entity<TblPaymentMode>(entity =>
        {
            entity.HasKey(e => e.PaymentModeId).HasName("PK_PaymentModes");

            entity.ToTable("tblPaymentModes");

            entity.Property(e => e.PaymentModeId).HasColumnName("PaymentModeID");
            entity.Property(e => e.PaymentMode)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblPaymentTableRx>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK_payment_table_rx");

            entity.ToTable("tblPayment_Table_RX");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Chknumber)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("chknumber");
            entity.Property(e => e.DateAdded)
                .HasColumnType("datetime")
                .HasColumnName("date_added");
            entity.Property(e => e.InsCompany)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("ins_company");
            entity.Property(e => e.InsurerAmtPaid)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("insurer_amt_paid");
            entity.Property(e => e.IsBatch)
                .HasDefaultValue(0)
                .HasColumnName("isBatch");
            entity.Property(e => e.Monthofclaim).HasColumnName("monthofclaim");
            entity.Property(e => e.NmhPull)
                .HasDefaultValue(0)
                .HasColumnName("nmhPull");
            entity.Property(e => e.NumberOfClaims).HasColumnName("number_of_claims");
            entity.Property(e => e.PaymentDate)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("payment_date");
            entity.Property(e => e.PaymentStatus)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("payment_status");
            entity.Property(e => e.ProviderClaimAmt).HasColumnName("provider_claim_amt");
            entity.Property(e => e.ProviderId).HasColumnName("provider_id");
            entity.Property(e => e.ProviderIdMaster).HasColumnName("provider_id_master");
            entity.Property(e => e.ProviderName)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("provider_name");
            entity.Property(e => e.RejectedAmt)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("rejected_amt");
            entity.Property(e => e.SystemInvoiceNo)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("system_invoice_no");
            entity.Property(e => e.TaxAmt)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("tax_amt");
            entity.Property(e => e.TypeOfFacility)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("type_of_facility");
            entity.Property(e => e.Yrofclaim).HasColumnName("yrofclaim");
        });

        modelBuilder.Entity<TblPhoneNumberUpdate>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("tblPhoneNumber_Update");

            entity.Property(e => e.DateStamp)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.IsUpdate)
                .HasDefaultValue(0)
                .HasColumnName("Is_Update");
            entity.Property(e => e.MemberId).HasColumnName("MemberID");
            entity.Property(e => e.NewPhone)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("New_Phone");
            entity.Property(e => e.OtherPhone)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("Other_Phone");
            entity.Property(e => e.RowId)
                .ValueGeneratedOnAdd()
                .HasColumnName("RowID");
            entity.Property(e => e.RowIdOnline).HasColumnName("RowID_Online");
        });

        modelBuilder.Entity<TblPlan>(entity =>
        {
            entity.ToTable("tblPlans");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.Active).HasDefaultValue(true);
            entity.Property(e => e.IsFamily)
                .HasDefaultValue(false)
                .HasColumnName("isFamily");
            entity.Property(e => e.PlanName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Prefix)
                .HasMaxLength(10)
                .IsUnicode(false);
            entity.Property(e => e.Premium).HasColumnType("decimal(18, 2)");

            entity.HasOne(d => d.MainPlan).WithMany(p => p.TblPlans)
                .HasForeignKey(d => d.MainPlanId)
                .HasConstraintName("FK_tblPlans_tblPlanMain");
        });

        modelBuilder.Entity<TblPlanBenefitGroup>(entity =>
        {
            entity.ToTable("tblPlan_BenefitGroups");

            entity.Property(e => e.Limit)
                .HasDefaultValue(0m)
                .HasColumnType("decimal(18, 2)");

            entity.HasOne(d => d.BenefitGroup).WithMany(p => p.TblPlanBenefitGroups)
                .HasForeignKey(d => d.BenefitGroupId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblPlan_BenefitGroups_tblBenefitGroups");

            entity.HasOne(d => d.Plan).WithMany(p => p.TblPlanBenefitGroups)
                .HasForeignKey(d => d.PlanId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblPlan_BenefitGroups_tblPlans");
        });

        modelBuilder.Entity<TblPlanBenefitLimit>(entity =>
        {
            entity.HasKey(e => e.RowId);

            entity.ToTable("tblPlan_BenefitLimits");

            entity.HasIndex(e => new { e.PlanId, e.BenefitId }, "IX_tblPlan_Benefit").IsUnique();

            entity.Property(e => e.RowId).HasColumnName("RowID");
            entity.Property(e => e.BenefitId).HasColumnName("BenefitID");
            entity.Property(e => e.CoverComment)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.CoverLimit)
                .HasDefaultValue(0.0m)
                .HasColumnType("decimal(18, 2)");
            entity.Property(e => e.CoverStatus)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.PlanId).HasColumnName("PlanID");

            entity.HasOne(d => d.Benefit).WithMany(p => p.TblPlanBenefitLimits)
                .HasForeignKey(d => d.BenefitId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblPlan_BenefitLimits_tblBenefits");

            entity.HasOne(d => d.Plan).WithMany(p => p.TblPlanBenefitLimits)
                .HasForeignKey(d => d.PlanId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblPlan_BenefitLimits_tblPlans");
        });

        modelBuilder.Entity<TblPlanBenefitParent>(entity =>
        {
            entity.ToTable("tblPlan_BenefitParent");

            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.Limit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

            entity.HasOne(d => d.BenefitParent).WithMany(p => p.TblPlanBenefitParents)
                .HasForeignKey(d => d.BenefitParentId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblPlan_BenefitParent_tblBenefitParent");

            entity.HasOne(d => d.Plan).WithMany(p => p.TblPlanBenefitParents)
                .HasForeignKey(d => d.PlanId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblPlan_BenefitParent_tblPlans");
        });

        modelBuilder.Entity<TblPlanMain>(entity =>
        {
            entity.ToTable("tblPlanMain");

            entity.Property(e => e.MainPlanName)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblPlanMasterLimit>(entity =>
        {
            entity.ToTable("tblPlan_MasterLimit");

            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Limit)
                .HasDefaultValue(0m)
                .HasColumnType("decimal(18, 2)");
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

            entity.HasOne(d => d.InOut).WithMany(p => p.TblPlanMasterLimits)
                .HasForeignKey(d => d.InOutId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblPlan_MasterLimit_tblIn_Out");

            entity.HasOne(d => d.Plan).WithMany(p => p.TblPlanMasterLimits)
                .HasForeignKey(d => d.PlanId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblPlan_MasterLimit_tblPlans");
        });

        modelBuilder.Entity<TblPlanPremium>(entity =>
        {
            entity.ToTable("tblPlanPremiums");

            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Premium)
                .HasDefaultValue(0m)
                .HasColumnType("decimal(18, 2)");
        });

        modelBuilder.Entity<TblPlansUpdate>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("tblPlansUpdate");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.IsFamily).HasColumnName("isFamily");
            entity.Property(e => e.PlanName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Prefix)
                .HasMaxLength(10)
                .IsUnicode(false);
            entity.Property(e => e.Premium).HasColumnType("decimal(18, 2)");
        });

        modelBuilder.Entity<TblPreAuthorization>(entity =>
        {
            entity.ToTable("tblPre_Authorizations");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.AuthorizeDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime")
                .HasColumnName("Authorize_Date");
            entity.Property(e => e.BenefitOptionId).HasColumnName("BenefitOptionID");
            entity.Property(e => e.CompanyId).HasColumnName("CompanyID");
            entity.Property(e => e.ItemId).HasColumnName("ItemID");
            entity.Property(e => e.MemberId).HasColumnName("MemberID");
            entity.Property(e => e.ProviderId).HasColumnName("ProviderID");
            entity.Property(e => e.UserId).HasColumnName("UserID");
        });

        modelBuilder.Entity<TblPrescription>(entity =>
        {
            entity.HasKey(e => e.RowId);

            entity.ToTable("tblPrescriptions");

            entity.Property(e => e.RowId).HasColumnName("Row_ID");
            entity.Property(e => e.DateStemp)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("dateStemp");
            entity.Property(e => e.Description)
                .HasMaxLength(500)
                .IsUnicode(false)
                .HasColumnName("description");
            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.ImageDownloaded).HasDefaultValue(false);
            entity.Property(e => e.ImagePath)
                .HasMaxLength(200)
                .IsUnicode(false);
            entity.Property(e => e.InsCompany)
                .HasMaxLength(10)
                .IsFixedLength()
                .HasColumnName("ins_company");
            entity.Property(e => e.PrescriptionChecked)
                .HasDefaultValue(false)
                .HasColumnName("prescription_checked");
            entity.Property(e => e.PrescriptionDocument)
                .HasMaxLength(500)
                .IsUnicode(false)
                .HasColumnName("prescription_document");
            entity.Property(e => e.ProcessClaimNo)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("process_claim_no");
            entity.Property(e => e.ProviderId).HasColumnName("provider_id");
            entity.Property(e => e.ProviderUserId).HasColumnName("provider_user_id");
            entity.Property(e => e.Status)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("status");
            entity.Property(e => e.UpdateClaimHeaderAvaliable)
                .HasDefaultValue(0)
                .HasColumnName("Update_ClaimHeader_avaliable");
        });

        modelBuilder.Entity<TblPrintCardType>(entity =>
        {
            entity.HasKey(e => e.PrintypeId);

            entity.ToTable("tblPrintCardTypes");

            entity.Property(e => e.PrintypeId).HasColumnName("PrintypeID");
            entity.Property(e => e.PrintName)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblProductLine>(entity =>
        {
            entity.ToTable("tblProductLines");

            entity.Property(e => e.ProductLine)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblProforma>(entity =>
        {
            entity.HasKey(e => e.InvoiceNo);

            entity.ToTable("tblProforma");

            entity.Property(e => e.InvoiceNo)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.Approved).HasDefaultValue(false);
            entity.Property(e => e.AuthorizedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.AutoId).ValueGeneratedOnAdd();
            entity.Property(e => e.BrokerContactNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.BrokerContactPerson)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CustomerAttn)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.DateCreated)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.InvoiceAmount)
                .HasComputedColumnSql("([PremiumAmount]+[MembershipFee])", false)
                .HasColumnType("decimal(19, 2)");
            entity.Property(e => e.InvoiceDate).HasColumnType("datetime");
            entity.Property(e => e.InvoiceMembers).HasDefaultValue(0);
            entity.Property(e => e.MembershipFee)
                .HasDefaultValue(0m)
                .HasColumnType("decimal(18, 2)");
            entity.Property(e => e.PremiumAmount)
                .HasDefaultValue(0m)
                .HasColumnType("decimal(18, 2)");
            entity.Property(e => e.PreparedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.SourceOfBusiness)
                .HasMaxLength(10)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblProformaProduct>(entity =>
        {
            entity.ToTable("tblProformaProducts", tb => tb.HasTrigger("trgUpdateProformaMembers_Amount"));

            entity.Property(e => e.Amount).HasComputedColumnSql("([Quantity]*[UnitPrice])", false);
            entity.Property(e => e.DateCreated)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.InvoiceNo)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.OtherComment)
                .HasMaxLength(100)
                .IsUnicode(false);

            entity.HasOne(d => d.InvoiceNoNavigation).WithMany(p => p.TblProformaProducts)
                .HasForeignKey(d => d.InvoiceNo)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblProformaProducts_tblProforma");
        });

        modelBuilder.Entity<TblRefundsApproved>(entity =>
        {
            entity.HasKey(e => e.AutoId);

            entity.ToTable("tblRefundsApproved");

            entity.Property(e => e.ClaimsNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Company)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.CompanyId).HasColumnName("CompanyID");
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.DateOfClaim).HasColumnType("datetime");
            entity.Property(e => e.FullName)
                .HasMaxLength(304)
                .IsUnicode(false);
            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.MemberNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.MoMoName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.MoMoNumber)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.OnlinePush).HasDefaultValue(false);
            entity.Property(e => e.Paid).HasDefaultValue(false);
            entity.Property(e => e.PaidBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PaidDate).HasColumnType("datetime");
            entity.Property(e => e.PaymentMode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PrinceMemberNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PrincipalId).HasColumnName("PrincipalID");
            entity.Property(e => e.PrincipalName)
                .HasMaxLength(304)
                .IsUnicode(false);
            entity.Property(e => e.Processed).HasDefaultValue(false);
            entity.Property(e => e.ProcessedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ProcessedDate).HasColumnType("datetime");
            entity.Property(e => e.Rejection).HasColumnType("money");
            entity.Property(e => e.SysAmountAwarded).HasColumnType("money");
            entity.Property(e => e.SysAmountClaimed).HasColumnType("money");
        });

        modelBuilder.Entity<TblRefundsApprovedRejection>(entity =>
        {
            entity.HasKey(e => e.AutoId);

            entity.ToTable("tblRefundsApproved_Rejections");

            entity.Property(e => e.ClaimsBatchNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Company)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.CompanyId).HasColumnName("CompanyID");
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.DateOfClaim).HasColumnType("datetime");
            entity.Property(e => e.FullName)
                .HasMaxLength(304)
                .IsUnicode(false);
            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.MemberNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.MoMoName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.MoMoNumber)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.OnlinePush).HasDefaultValue(false);
            entity.Property(e => e.PaymentMode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PrinceMemberNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PrincipalId).HasColumnName("PrincipalID");
            entity.Property(e => e.PrincipalName)
                .HasMaxLength(304)
                .IsUnicode(false);
            entity.Property(e => e.ReferenceClaimNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Rejection).HasColumnType("money");
            entity.Property(e => e.SysAmountAwarded).HasColumnType("money");
            entity.Property(e => e.SysAmountClaimed).HasColumnType("money");
        });

        modelBuilder.Entity<TblRefundsPayment>(entity =>
        {
            entity.ToTable("tblRefundsPayment", tb => tb.HasTrigger("Insert_AccountsPayment"));

            entity.Property(e => e.Id).ValueGeneratedNever();
            entity.Property(e => e.AccountName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Amount).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ChequeNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Description)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.PayDate).HasColumnType("datetime");
            entity.Property(e => e.PayMode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PostingAccount)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Processed).HasDefaultValue(0);
            entity.Property(e => e.ReferenceNo)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblRefundsPrescription>(entity =>
        {
            entity.ToTable("tblRefundsPrescriptions");

            entity.Property(e => e.ClaimsNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.FileDate).HasColumnType("datetime");
            entity.Property(e => e.FilePath)
                .HasMaxLength(200)
                .IsUnicode(false);

            entity.HasOne(d => d.ClaimsNoNavigation).WithMany(p => p.TblRefundsPrescriptions)
                .HasForeignKey(d => d.ClaimsNo)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblRefundsPrescriptions_tblRefundsReceipts");

            entity.HasOne(d => d.ServiceProvider).WithMany(p => p.TblRefundsPrescriptions)
                .HasForeignKey(d => d.ServiceProviderId)
                .HasConstraintName("FK_tblRefundsPrescriptions_tblServiceProviders_Refunds");
        });

        modelBuilder.Entity<TblRefundsReason>(entity =>
        {
            entity.ToTable("tblRefundsReasons");

            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Reason)
                .HasMaxLength(100)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblRefundsReceipt>(entity =>
        {
            entity.HasKey(e => e.ClaimsNo);

            entity.ToTable("tblRefundsReceipts");

            entity.Property(e => e.ClaimsNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Comment)
                .HasMaxLength(200)
                .IsUnicode(false);
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.FilePath)
                .HasMaxLength(200)
                .IsUnicode(false);
            entity.Property(e => e.Id).ValueGeneratedOnAdd();
            entity.Property(e => e.ReceiptAmount).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ReceiptDate).HasColumnType("datetime");
            entity.Property(e => e.ReceiptNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

            entity.HasOne(d => d.BatchNoNavigation).WithMany(p => p.TblRefundsReceipts)
                .HasForeignKey(d => d.BatchNo)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblRefundsReceipts_tblClaimsBatch");

            entity.HasOne(d => d.ServiceProvider).WithMany(p => p.TblRefundsReceipts)
                .HasForeignKey(d => d.ServiceProviderId)
                .HasConstraintName("FK_tblRefundsReceipts_tblServiceProviders_Refunds");
        });

        modelBuilder.Entity<TblRegion>(entity =>
        {
            entity.ToTable("tblRegions");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.Region)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.RegionCode)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblRelation>(entity =>
        {
            entity.ToTable("tblRelation");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.RalationType)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.RelationId)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Relationship)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblRxClaimsDiagnosis>(entity =>
        {
            entity.HasKey(e => e.RowId).HasName("PK_RX_Claims_Diagnosis");

            entity.ToTable("tblRX_Claims_Diagnosis");

            entity.Property(e => e.RowId).HasColumnName("RowID");
            entity.Property(e => e.BuildStatus)
                .HasDefaultValue(0)
                .HasColumnName("Build_status");
            entity.Property(e => e.DateItem)
                .HasColumnType("datetime")
                .HasColumnName("date_item");
            entity.Property(e => e.DiseaseCode)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("disease_code");
            entity.Property(e => e.DiseaseId).HasColumnName("disease_id");
            entity.Property(e => e.DiseaseName)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("disease_name");
            entity.Property(e => e.ProcessClaimNo)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("process_claim_no");
            entity.Property(e => e.ProviderDataId).HasColumnName("provider_data_id");
            entity.Property(e => e.ProviderId).HasColumnName("provider_id");
            entity.Property(e => e.RxId).HasColumnName("RX_id");
            entity.Property(e => e.StampDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Status)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("status");
        });

        modelBuilder.Entity<TblService>(entity =>
        {
            entity.HasKey(e => e.ServiceId);

            entity.ToTable("tblServices");

            entity.Property(e => e.ServiceId).HasColumnName("ServiceID");
            entity.Property(e => e.DateStamp).HasColumnType("datetime");
            entity.Property(e => e.Description)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ServiceCode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ServiceName)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblServiceProvider>(entity =>
        {
            entity.ToTable("tblServiceProviders", tb => tb.HasTrigger("get_HSP_Online"));

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.AccountName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.AccountNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.AceeptTpa).HasColumnName("AceeptTPA");
            entity.Property(e => e.BankId).HasColumnName("BankID");
            entity.Property(e => e.BranchName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Ceoemail)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("CEOEmail");
            entity.Property(e => e.Ceoname)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("CEOName");
            entity.Property(e => e.Ceophone)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("CEOphone");
            entity.Property(e => e.ClaimsEmail)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ClaimsName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CommunityId).HasColumnName("CommunityID");
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.DigitalAddress)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.DocIdOnlineVetting).HasColumnName("DocID_OnlineVetting");
            entity.Property(e => e.Doctor).HasMaxLength(50);
            entity.Property(e => e.Email)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.FaxNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.FinEmail)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.GroupLocation).HasMaxLength(50);
            entity.Property(e => e.HspId)
                .HasDefaultValue(0)
                .HasColumnName("HspID");
            entity.Property(e => e.MobNum)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.OwnerTypeId).HasColumnName("OwnerTypeID");
            entity.Property(e => e.PaymentContactName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PaymentContactNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PostalAddress)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.PspMarkUp)
                .HasColumnType("decimal(18, 2)")
                .HasColumnName("PSP_MarkUp");
            entity.Property(e => e.Region).HasMaxLength(50);
            entity.Property(e => e.RegionId).HasColumnName("RegionID");
            entity.Property(e => e.RegistrationNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.RmEmail)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("RM_Email");
            entity.Property(e => e.RmMob)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("RM_Mob");
            entity.Property(e => e.RmName)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("RM_Name");
            entity.Property(e => e.RmOtherPhone)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("RM_OtherPhone");
            entity.Property(e => e.RxMasterProviderId).HasColumnName("RX_Master_ProviderID");
            entity.Property(e => e.ServiceProvider)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ServiceProviderStatus).HasMaxLength(50);
            entity.Property(e => e.ServiceType).HasMaxLength(50);
            entity.Property(e => e.ServiceTypeId).HasColumnName("ServiceTypeID");
            entity.Property(e => e.StatusId).HasColumnName("StatusID");
            entity.Property(e => e.StreetLocation)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.TelNum)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<TblServiceProviderBenefitParent>(entity =>
        {
            entity.HasKey(e => e.RowId);

            entity.ToTable("tblServiceProvider_BenefitParent");

            entity.HasIndex(e => new { e.ServiceProviderId, e.ParentBenefitId }, "IX_tblServiceProvider_BenefitParent");

            entity.Property(e => e.RowId).HasColumnName("RowID");
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.EffectiveDate).HasColumnType("datetime");
            entity.Property(e => e.EndDate).HasColumnType("datetime");
            entity.Property(e => e.ParentBenefitId).HasColumnName("ParentBenefitID");
            entity.Property(e => e.ServiceProviderId).HasColumnName("ServiceProviderID");
        });

        modelBuilder.Entity<TblServiceProviderXPlan>(entity =>
        {
            entity.HasKey(e => e.RowId);

            entity.ToTable("tblServiceProvider_X_Plans");

            entity.HasIndex(e => new { e.ServiceProviderId, e.PlanId }, "IX_tblServiceProvider_X_Plans");

            entity.Property(e => e.RowId).HasColumnName("RowID");
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.EffectiveDate).HasColumnType("datetime");
            entity.Property(e => e.EndDate).HasColumnType("datetime");
            entity.Property(e => e.PlanId).HasColumnName("PlanID");
            entity.Property(e => e.ServiceProviderId).HasColumnName("ServiceProviderID");
        });

        modelBuilder.Entity<TblServiceProviderXService>(entity =>
        {
            entity.HasKey(e => e.RowId);

            entity.ToTable("tblServiceProvider_X_Services");

            entity.Property(e => e.RowId).HasColumnName("RowID");
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.EffectiveDate).HasColumnType("datetime");
            entity.Property(e => e.EndDate).HasColumnType("datetime");
            entity.Property(e => e.ServiceClassRowId).HasColumnName("ServiceClass_RowID");
            entity.Property(e => e.ServiceId).HasColumnName("ServiceID");
            entity.Property(e => e.ServiceProviderId).HasColumnName("ServiceProviderID");
        });

        modelBuilder.Entity<TblServiceProviderXTariffXPrice>(entity =>
        {
            entity.HasKey(e => e.RowId);

            entity.ToTable("tblServiceProvider_X_Tariff_X_Prices");

            entity.HasIndex(e => new { e.ServiceProviderId, e.TariffId }, "IX_tblServiceProvider_X_Tariff_X_Prices");

            entity.Property(e => e.RowId).HasColumnName("RowID");
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.EffectiveDate).HasColumnType("datetime");
            entity.Property(e => e.EndDate).HasColumnType("datetime");
            entity.Property(e => e.ServiceProviderId).HasColumnName("ServiceProviderID");
            entity.Property(e => e.TariffId).HasColumnName("TariffID");
            entity.Property(e => e.UnitCost).HasColumnType("decimal(18, 2)");
        });

        modelBuilder.Entity<TblServiceProvidersAccount>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK_tblNonHealthServiceProviders");

            entity.ToTable("tblServiceProviders_Accounts");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.AccountName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.AccountNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CommRate).HasDefaultValue(0.0);
            entity.Property(e => e.ContactNo)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.DigitalAddress)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.District)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.EmailAddress)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Hspid).HasColumnName("HSPId");
            entity.Property(e => e.IsHsp).HasColumnName("IsHSP");
            entity.Property(e => e.NhiacertNo)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("NHIACertNo");
            entity.Property(e => e.ServiceProvider)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ThymeHspId)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Tin)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("TIN");
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            entity.Property(e => e.WhtaxRate)
                .HasDefaultValue(0.0)
                .HasColumnName("WHTaxRate");
            entity.Property(e => e.Whtaxable)
                .HasDefaultValue(false)
                .HasColumnName("WHTaxable");
        });

        modelBuilder.Entity<TblServiceProvidersRefund>(entity =>
        {
            entity.ToTable("tblServiceProviders_Refunds");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.ServiceProvider)
                .HasMaxLength(100)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblServiceProvidersRx>(entity =>
        {
            entity.HasKey(e => e.RowId);

            entity.ToTable("tblServiceProviders_RX");

            entity.Property(e => e.RowId).HasColumnName("RowID");
            entity.Property(e => e.ActivationDate)
                .HasColumnType("datetime")
                .HasColumnName("activation_date");
            entity.Property(e => e.ActivationTime)
                .HasColumnType("datetime")
                .HasColumnName("activation_time");
            entity.Property(e => e.FacilityName)
                .HasMaxLength(255)
                .HasColumnName("facility_name");
            entity.Property(e => e.InsCompany)
                .HasMaxLength(255)
                .HasColumnName("ins_company");
            entity.Property(e => e.LastSerialNumber).HasColumnName("last_serial_number");
            entity.Property(e => e.ProviderId).HasColumnName("provider_id");
            entity.Property(e => e.ProviderIdMaster).HasColumnName("provider_id_master");
        });

        modelBuilder.Entity<TblServiceType>(entity =>
        {
            entity.ToTable("tblServiceTypes");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.Service)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ServiceType)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.StatusId).HasColumnName("statusID");
        });

        modelBuilder.Entity<TblTariff>(entity =>
        {
            entity.HasKey(e => e.TariffId).HasName("PK_Tariff");

            entity.ToTable("tblTariff");

            entity.HasIndex(e => e.BenefitId, "IX_tblTariff");

            entity.Property(e => e.TariffId).HasColumnName("TariffID");
            entity.Property(e => e.DrugGenId).HasColumnName("DrugGenID");
            entity.Property(e => e.InOutPatient).HasColumnName("In_OutPatient");
            entity.Property(e => e.LabGroupId).HasColumnName("LabGroupID");
            entity.Property(e => e.MedClassId).HasColumnName("MedClassID");
            entity.Property(e => e.OpticalServicesTypeId).HasColumnName("OpticalServicesTypeID");
            entity.Property(e => e.ServiceId).HasColumnName("ServiceID");
            entity.Property(e => e.Status).HasColumnName("STATUS");
            entity.Property(e => e.TariffCode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.TariffName)
                .HasMaxLength(5000)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblTariffDrugsGeneric>(entity =>
        {
            entity.HasKey(e => e.DrugGenId);

            entity.ToTable("tblTariff_DrugsGeneric");

            entity.Property(e => e.DrugGenId).HasColumnName("DrugGenID");
            entity.Property(e => e.DrugClassId).HasColumnName("DrugClassID");
            entity.Property(e => e.InOutPatient).HasColumnName("In_OutPatient");
            entity.Property(e => e.ServiceId).HasColumnName("ServiceID");
            entity.Property(e => e.TariffCode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.TariffName)
                .HasMaxLength(5000)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblTariffWithoutPrice>(entity =>
        {
            entity.ToTable("tblTariff_Without_Price");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.DateStamp)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.DrugId).HasColumnName("DrugID");
            entity.Property(e => e.MobimedList)
                .HasDefaultValue(0)
                .HasColumnName("Mobimed_List");
            entity.Property(e => e.PspList)
                .HasDefaultValue(0)
                .HasColumnName("PSP_List");
        });

        modelBuilder.Entity<TblTariffXRejectionComment>(entity =>
        {
            entity.HasKey(e => e.TariffXRejectionCommentId);

            entity.ToTable("tblTariff_X_RejectionComment");

            entity.Property(e => e.TariffXRejectionCommentId).HasColumnName("Tariff_X_RejectionCommentID");
            entity.Property(e => e.ApplyOn).HasDefaultValue(0);
            entity.Property(e => e.FacilityTypeId).HasColumnName("FacilityTypeID");
            entity.Property(e => e.ReturnToHsp).HasColumnName("ReturnToHSP");
            entity.Property(e => e.TariffXRejectionComments).HasColumnName("Tariff_X_RejectionComments");
        });

        modelBuilder.Entity<TblTariffXRejectionCommentOnline>(entity =>
        {
            entity.HasKey(e => e.TariffXRejectionCommentId).HasName("PK_Tariff_X_RejectionComment_Online");

            entity.ToTable("tblTariff_X_RejectionComment_Online");

            entity.Property(e => e.TariffXRejectionCommentId)
                .ValueGeneratedNever()
                .HasColumnName("Tariff_X_RejectionCommentID");
            entity.Property(e => e.TariffXRejectionComments)
                .HasMaxLength(255)
                .HasColumnName("Tariff_X_RejectionComments");
        });

        modelBuilder.Entity<TblTariffXRx>(entity =>
        {
            entity.HasKey(e => e.RowId);

            entity.ToTable("tblTariff_X_RX");

            entity.HasIndex(e => e.RxItemCode, "IX_tblTariff_X_RX").IsUnique();

            entity.Property(e => e.RowId).HasColumnName("RowID");
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.NmhTarrifId).HasColumnName("NMH_TarrifID");
            entity.Property(e => e.RxItemCode)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("RX_Item_Code");
        });

        modelBuilder.Entity<TblTitle>(entity =>
        {
            entity.ToTable("tblTitles");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.Title)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblUser>(entity =>
        {
            entity.ToTable("tblUsers");

            entity.HasIndex(e => e.Username, "IX_tblUsers").IsUnique();

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.AccountTypeId).HasColumnName("AccountTypeID");
            entity.Property(e => e.Address)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Branch)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.ContactNo).HasMaxLength(20);
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Email)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Fullname)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Gender)
                .HasMaxLength(10)
                .IsUnicode(false);
            entity.Property(e => e.MaritalStatus)
                .HasMaxLength(10)
                .IsUnicode(false);
            entity.Property(e => e.PostType)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.PrepareSignPath)
                .HasMaxLength(200)
                .IsUnicode(false);
            entity.Property(e => e.ProfilePath)
                .HasMaxLength(200)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            entity.Property(e => e.UserKey)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UserPassword).HasMaxLength(20);
            entity.Property(e => e.Username)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Userroles).IsUnicode(false);
        });

        modelBuilder.Entity<TblUserRole>(entity =>
        {
            entity.HasKey(e => e.RoleId);

            entity.ToTable("tblUserRoles");

            entity.Property(e => e.RoleId).HasColumnName("RoleID");
            entity.Property(e => e.UserRole)
                .HasMaxLength(30)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TblVettingDoctor>(entity =>
        {
            entity.ToTable("tblVettingDoctors");

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("ID");
            entity.Property(e => e.Doctor)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.Email)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TspClaimStatus>(entity =>
        {
            entity.ToTable("tspClaim_Status");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.Status)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TspClaimStatusInfo>(entity =>
        {
            entity.ToTable("tspClaim_Status_Info");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.ClaimsNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.DateStamp)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.StatusId).HasColumnName("StatusID");
            entity.Property(e => e.UserId).HasColumnName("UserID");

            entity.HasOne(d => d.ClaimsNoNavigation).WithMany(p => p.TspClaimStatusInfos)
                .HasForeignKey(d => d.ClaimsNo)
                .HasConstraintName("FK_tspClaim_Status_Info_tspClaimsHeader");

            entity.HasOne(d => d.Status).WithMany(p => p.TspClaimStatusInfos)
                .HasForeignKey(d => d.StatusId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tspClaim_Status_Info_tspClaim_Status");
        });

        modelBuilder.Entity<TspClaimsDetail>(entity =>
        {
            entity.ToTable("tspClaimsDetails");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.Claimed).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ClaimsNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ProductId).HasColumnName("ProductID");
            entity.Property(e => e.StampDate).HasColumnType("datetime");
            entity.Property(e => e.UnitPrice).HasColumnType("decimal(18, 3)");
            entity.Property(e => e.UserId).HasColumnName("UserID");

            entity.HasOne(d => d.Product).WithMany(p => p.TspClaimsDetails)
                .HasForeignKey(d => d.ProductId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tspClaimsDetails_tblTariff");
        });

        modelBuilder.Entity<TspClaimsDiagnosisTem>(entity =>
        {
            entity.HasKey(e => e.ClaimsNo);

            entity.ToTable("tspClaimsDiagnosis_Tem");

            entity.Property(e => e.ClaimsNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Diagnosis).IsUnicode(false);

            entity.HasOne(d => d.ClaimsNoNavigation).WithOne(p => p.TspClaimsDiagnosisTem)
                .HasForeignKey<TspClaimsDiagnosisTem>(d => d.ClaimsNo)
                .HasConstraintName("FK_tspClaimsDiagnosis_Tem_tspClaimsHeader");
        });

        modelBuilder.Entity<TspClaimsHeader>(entity =>
        {
            entity.HasKey(e => e.ClaimsNo);

            entity.ToTable("tspClaimsHeader");

            entity.Property(e => e.ClaimsNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.AdmissionDate).HasColumnType("datetime");
            entity.Property(e => e.DateofAttendance).HasColumnType("datetime");
            entity.Property(e => e.DischargeDate).HasColumnType("datetime");
            entity.Property(e => e.Id)
                .ValueGeneratedOnAdd()
                .HasColumnName("ID");
            entity.Property(e => e.InOutId).HasColumnName("InOutID");
            entity.Property(e => e.MemberId).HasColumnName("MemberID");
            entity.Property(e => e.NmhProviderId).HasColumnName("NMH_ProviderID");
            entity.Property(e => e.PrescriptionAvailable).HasDefaultValue(0);
            entity.Property(e => e.ProviderAmountClaimed).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.StampDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.StatusId).HasColumnName("StatusID");
            entity.Property(e => e.SysAmountClaimed).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.UserId).HasColumnName("UserID");
        });

        modelBuilder.Entity<TspClaimsHeaderXDisease>(entity =>
        {
            entity.HasKey(e => e.RowId);

            entity.ToTable("tspClaimsHeader_X_Disease");

            entity.Property(e => e.RowId).HasColumnName("RowID");
            entity.Property(e => e.ClaimsNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.DiseaseId).HasColumnName("DiseaseID");

            entity.HasOne(d => d.ClaimsNoNavigation).WithMany(p => p.TspClaimsHeaderXDiseases)
                .HasForeignKey(d => d.ClaimsNo)
                .HasConstraintName("FK_tspClaimsHeader_X_Disease_tspClaimsHeader");

            entity.HasOne(d => d.Disease).WithMany(p => p.TspClaimsHeaderXDiseases)
                .HasForeignKey(d => d.DiseaseId)
                .HasConstraintName("FK_tspClaimsHeader_X_Disease_tblDisease");
        });

        modelBuilder.Entity<TspUser>(entity =>
        {
            entity.ToTable("tspUsers");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.AccountType)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.ContactNo)
                .HasMaxLength(10)
                .IsUnicode(false);
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getutcdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Email)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Fullname)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Gender)
                .HasMaxLength(10)
                .IsUnicode(false);
            entity.Property(e => e.ProviderId).IsUnicode(false);
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            entity.Property(e => e.UserPassword).HasMaxLength(20);
            entity.Property(e => e.Username)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Userroles).IsUnicode(false);
        });

        modelBuilder.Entity<TspUserRole>(entity =>
        {
            entity.HasKey(e => e.RoleId);

            entity.ToTable("tspUserRoles");

            entity.Property(e => e.RoleId).HasColumnName("RoleID");
            entity.Property(e => e.UserRole)
                .HasMaxLength(30)
                .IsUnicode(false);
        });

        modelBuilder.Entity<User>(entity =>
        {
            entity.HasNoKey();

            entity.Property(e => e.AccountTypeId).HasColumnName("AccountTypeID");
            entity.Property(e => e.Email).HasMaxLength(50);
            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.NmiUserId).HasColumnName("NmiUserID");
            entity.Property(e => e.PhoneNumber).HasMaxLength(13);
            entity.Property(e => e.Profile).HasMaxLength(200);
            entity.Property(e => e.Staffnumber).HasMaxLength(50);
            entity.Property(e => e.UserName).HasMaxLength(50);
            entity.Property(e => e.UserRoles)
                .HasMaxLength(200)
                .IsUnicode(false);
        });

        modelBuilder.Entity<VspClaimsDetail>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vspClaimsDetails");

            entity.Property(e => e.Claimed).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ClaimsNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.ProductId).HasColumnName("ProductID");
            entity.Property(e => e.StampDate).HasColumnType("datetime");
            entity.Property(e => e.TariffName)
                .HasMaxLength(5000)
                .IsUnicode(false);
            entity.Property(e => e.TypeName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UnitPrice).HasColumnType("decimal(18, 3)");
        });

        modelBuilder.Entity<VspClaimsHeader>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vspClaimsHeader");

            entity.Property(e => e.ClaimsNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CompanyId).HasColumnName("CompanyID");
            entity.Property(e => e.DateofAttendance).HasColumnType("datetime");
            entity.Property(e => e.Diagnosis).IsUnicode(false);
            entity.Property(e => e.Dob).HasColumnName("DOB");
            entity.Property(e => e.FullName)
                .HasMaxLength(304)
                .IsUnicode(false);
            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.InOutId).HasColumnName("InOutID");
            entity.Property(e => e.Inout)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.MemberId).HasColumnName("MemberID");
            entity.Property(e => e.MembershipNo)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.Mphone)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.NmhProviderId).HasColumnName("NMH_ProviderID");
            entity.Property(e => e.ProviderAmountClaimed).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ServiceProvider)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.StampDate).HasColumnType("datetime");
            entity.Property(e => e.Status)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.StatusId).HasColumnName("StatusID");
            entity.Property(e => e.TypeOfVisit)
                .HasMaxLength(58)
                .IsUnicode(false);
        });

        modelBuilder.Entity<VspClaimsHeaderXDisease>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vspClaimsHeader_X_Disease");

            entity.Property(e => e.ClaimsNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Code)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.Disease)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.DiseaseGroupId).HasColumnName("DiseaseGroupID");
            entity.Property(e => e.DiseaseId).HasColumnName("DiseaseID");
            entity.Property(e => e.RowId).HasColumnName("RowID");
        });

        modelBuilder.Entity<VspUser>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vspUsers");

            entity.Property(e => e.AccountType)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.ContactNo)
                .HasMaxLength(10)
                .IsUnicode(false);
            entity.Property(e => e.Email)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Fullname)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Gender)
                .HasMaxLength(10)
                .IsUnicode(false);
            entity.Property(e => e.Id)
                .ValueGeneratedOnAdd()
                .HasColumnName("id");
            entity.Property(e => e.ProviderId).IsUnicode(false);
            entity.Property(e => e.UserPassword).HasMaxLength(20);
            entity.Property(e => e.Username)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Userroles).IsUnicode(false);
        });

        modelBuilder.Entity<VspUsersMain>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vspUsersMain");

            entity.Property(e => e.AccountType)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.ContactNo)
                .HasMaxLength(10)
                .IsUnicode(false);
            entity.Property(e => e.Email)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Fullname)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.ServiceProvider)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Username)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Userroles).IsUnicode(false);
        });

        modelBuilder.Entity<VvwClaimsDetailsOnline>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vvwClaimsDetails_Online");

            entity.Property(e => e.ApprovedAmount).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Awarded).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Claimed).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ClaimsNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.DateofAttendance).HasColumnType("datetime");
            entity.Property(e => e.Diagnosis).IsUnicode(false);
            entity.Property(e => e.Diff).HasColumnType("decimal(19, 2)");
            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.MemberId).HasColumnName("MemberID");
            entity.Property(e => e.NmhProviderId).HasColumnName("NMH_ProviderID");
            entity.Property(e => e.ProductId).HasColumnName("ProductID");
            entity.Property(e => e.RowId).HasColumnName("RowID");
            entity.Property(e => e.RxItemName)
                .IsUnicode(false)
                .HasColumnName("rx_item_name");
            entity.Property(e => e.RxRowId).HasColumnName("RX_RowID");
            entity.Property(e => e.StampDate).HasColumnType("datetime");
            entity.Property(e => e.TariffName)
                .HasMaxLength(5000)
                .IsUnicode(false);
            entity.Property(e => e.TariffXRejectionCommentId).HasColumnName("Tariff_X_RejectionCommentID");
            entity.Property(e => e.TariffXRejectionComments).HasColumnName("Tariff_X_RejectionComments");
            entity.Property(e => e.UnitPrice).HasColumnType("decimal(18, 3)");
            entity.Property(e => e.VettingId).HasColumnName("VettingID");
        });

        modelBuilder.Entity<VvwClaimsHeader>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vvwClaimsHeader");

            entity.Property(e => e.ClaimsNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Company)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.CompanyId).HasColumnName("CompanyID");
            entity.Property(e => e.ConfirmedDiagnosis)
                .IsUnicode(false)
                .HasColumnName("Confirmed_Diagnosis");
            entity.Property(e => e.DateStamp).HasColumnType("datetime");
            entity.Property(e => e.DateofAttendance).HasColumnType("datetime");
            entity.Property(e => e.Diagnosis).IsUnicode(false);
            entity.Property(e => e.Dob).HasColumnName("DOB");
            entity.Property(e => e.FullName)
                .HasMaxLength(304)
                .IsUnicode(false);
            entity.Property(e => e.Gender)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.InOutId).HasColumnName("InOutID");
            entity.Property(e => e.Inout)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.MemberId).HasColumnName("MemberID");
            entity.Property(e => e.MemberNo)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.NmhProviderId).HasColumnName("NMH_ProviderID");
            entity.Property(e => e.PlanName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ProviderAmountClaimed).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ProviderComment)
                .HasMaxLength(300)
                .IsUnicode(false);
            entity.Property(e => e.Relationship)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ServiceProvider)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ServiceProviderId).HasColumnName("ServiceProviderID");
            entity.Property(e => e.Status)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.SysAmountAwarded).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.SysAmountClaimed).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Tpa).HasColumnName("TPA");
        });

        modelBuilder.Entity<VwAdviceSlip>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwAdviceSlip");

            entity.Property(e => e.AdviceMemberName)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.ApprovedAmount).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Awarded).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.BenefitOption)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Claimed).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ClaimsDetailsId).HasColumnName("ClaimsDetailsID");
            entity.Property(e => e.ClaimsNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CompanyName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.DateOfClaim).HasColumnType("datetime");
            entity.Property(e => e.DateofAttendance).HasColumnType("datetime");
            entity.Property(e => e.Diagnosis).IsUnicode(false);
            entity.Property(e => e.Diff).HasColumnType("decimal(19, 2)");
            entity.Property(e => e.Dob)
                .HasColumnType("datetime")
                .HasColumnName("DOB");
            entity.Property(e => e.Fullname)
                .HasMaxLength(304)
                .IsUnicode(false);
            entity.Property(e => e.Gender)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Inout)
                .HasMaxLength(58)
                .IsUnicode(false);
            entity.Property(e => e.MemberAge)
                .HasMaxLength(18)
                .IsUnicode(false);
            entity.Property(e => e.MemberId).HasColumnName("MemberID");
            entity.Property(e => e.MembershipNo)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.NmhProviderId).HasColumnName("NMH_ProviderID");
            entity.Property(e => e.NotAMember)
                .HasMaxLength(500)
                .IsUnicode(false)
                .HasColumnName("NotA_Member");
            entity.Property(e => e.PlanName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ProviderAmountClaimed).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.RejectedAmount).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.RowId).HasColumnName("RowID");
            entity.Property(e => e.RxRowId).HasColumnName("RX_RowID");
            entity.Property(e => e.ServiceId).HasColumnName("ServiceID");
            entity.Property(e => e.ServiceName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ServiceProvider)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ServiceProviderId).HasColumnName("ServiceProviderID");
            entity.Property(e => e.ServiceType)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.StampDate).HasColumnType("datetime");
            entity.Property(e => e.StatusId).HasColumnName("StatusID");
            entity.Property(e => e.SysAmountAwarded).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.SysAmountClaimed).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.TariffId).HasColumnName("TariffID");
            entity.Property(e => e.TariffName)
                .HasMaxLength(5000)
                .IsUnicode(false);
            entity.Property(e => e.TariffXRejectionCommentId).HasColumnName("Tariff_X_RejectionCommentID");
            entity.Property(e => e.TariffXRejectionComments).HasColumnName("Tariff_X_RejectionComments");
            entity.Property(e => e.Tpa).HasColumnName("TPA");
            entity.Property(e => e.UnitPrice).HasColumnType("decimal(18, 3)");
            entity.Property(e => e.UserId).HasColumnName("UserID");
        });

        modelBuilder.Entity<VwAdviceSlipDetail>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwAdviceSlip_Details");

            entity.Property(e => e.ApprovedAmount).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Awarded).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Claimed).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ClaimsDetailsId).HasColumnName("ClaimsDetailsID");
            entity.Property(e => e.ClaimsNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.MemberId).HasColumnName("MemberID");
            entity.Property(e => e.NmhProviderId).HasColumnName("NMH_ProviderID");
            entity.Property(e => e.RejectedAmount).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.RowId).HasColumnName("RowID");
            entity.Property(e => e.RxRowId).HasColumnName("RX_RowID");
            entity.Property(e => e.StampDate).HasColumnType("datetime");
            entity.Property(e => e.TariffId).HasColumnName("TariffID");
            entity.Property(e => e.TariffName)
                .HasMaxLength(5000)
                .IsUnicode(false);
            entity.Property(e => e.TariffXRejectionCommentId).HasColumnName("Tariff_X_RejectionCommentID");
            entity.Property(e => e.TariffXRejectionComments).HasColumnName("Tariff_X_RejectionComments");
            entity.Property(e => e.Tpa).HasColumnName("TPA");
            entity.Property(e => e.UnitPrice).HasColumnType("decimal(18, 3)");
            entity.Property(e => e.UserId).HasColumnName("UserID");
        });

        modelBuilder.Entity<VwAuditTrail>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwAuditTrail");

            entity.Property(e => e.ActionDate).HasColumnType("datetime");
            entity.Property(e => e.ActionDescription)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ActionId)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("ActionID");
            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.Username)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<VwBankBranch>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwBankBranches");

            entity.Property(e => e.Bank)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.BranchName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.SortCode)
                .HasMaxLength(6)
                .IsUnicode(false);
        });

        modelBuilder.Entity<VwBatchStatusInfo>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("Vw_Batch_Status_Info");

            entity.Property(e => e.DateStamp).HasColumnType("datetime");
            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.Status)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.StatusId).HasColumnName("StatusID");
            entity.Property(e => e.UserId).HasColumnName("UserID");
            entity.Property(e => e.Username)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<VwBenefit>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwBenefits");

            entity.Property(e => e.Benefit)
                .HasMaxLength(200)
                .IsUnicode(false);
            entity.Property(e => e.BenefitGroup)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ParentName)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<VwBenefitGroup>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwBenefitGroups");

            entity.Property(e => e.BenefitGroup)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.ParentName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<VwCallLogTicket>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwCallLogTickets");

            entity.Property(e => e.AutoEscalateDate).HasColumnType("datetime");
            entity.Property(e => e.CallDate).HasColumnType("datetime");
            entity.Property(e => e.CallReason)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CallType)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CallerName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.CallerNumber)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.Comment).IsUnicode(false);
            entity.Property(e => e.Company)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ContactEmail)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Crchannel)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("CRChannel");
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.Department)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Description).IsUnicode(false);
            entity.Property(e => e.EscalateComment).IsUnicode(false);
            entity.Property(e => e.EscalatedStatus)
                .HasMaxLength(10)
                .IsUnicode(false);
            entity.Property(e => e.EscalationDate).HasColumnType("datetime");
            entity.Property(e => e.FinalResolution).IsUnicode(false);
            entity.Property(e => e.Location)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.LogSource)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.MemberNo)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.Nmhmember).HasColumnName("NMHMember");
            entity.Property(e => e.Priority)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.ProductType)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.ResolutionDate).HasColumnType("datetime");
            entity.Property(e => e.ResolvedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ServiceProvider)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ServiceType)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            entity.Property(e => e.UserDepartmentName)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<VwCallLogTicketFollowUp>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwCallLogTicketFollowUp");

            entity.Property(e => e.AutoEscalateDate).HasColumnType("datetime");
            entity.Property(e => e.CallDate).HasColumnType("datetime");
            entity.Property(e => e.CallReason)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CallType)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CallerName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.CallerNumber)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.Comment).IsUnicode(false);
            entity.Property(e => e.Company)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ContactEmail)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Crchannel)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("CRChannel");
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.Department)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Description).IsUnicode(false);
            entity.Property(e => e.EscalateComment).IsUnicode(false);
            entity.Property(e => e.EscalatedStatus)
                .HasMaxLength(10)
                .IsUnicode(false);
            entity.Property(e => e.EscalationDate).HasColumnType("datetime");
            entity.Property(e => e.FeedbackComment)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.FeedbackCreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.FeedbackCreatedDate).HasColumnType("datetime");
            entity.Property(e => e.FinalResolution).IsUnicode(false);
            entity.Property(e => e.Location)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.LogSource)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.MemberNo)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.Nmhmember).HasColumnName("NMHMember");
            entity.Property(e => e.Priority)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.ProductType)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.ResolutionDate).HasColumnType("datetime");
            entity.Property(e => e.ResolvedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ServiceProvider)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ServiceType)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            entity.Property(e => e.UserDepartmentName)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<VwCallReason>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwCallReasons");

            entity.Property(e => e.CallReason)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.ServiceType)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<VwCardPrinting>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwCardPrinting");

            entity.Property(e => e.DatePrinted).HasColumnType("datetime");
            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.MemberId).HasColumnName("MemberID");
            entity.Property(e => e.PrintedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.SerialNo)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.UserId).HasColumnName("UserID");
        });

        modelBuilder.Entity<VwClaimsAward>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwClaimsAwards");

            entity.Property(e => e.AmountClaimed).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.AmountDue).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.AmountWord)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.AwardDate).HasColumnType("datetime");
            entity.Property(e => e.Awarded).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Building).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Claimed).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Comment)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.DateOfClaim).HasColumnType("datetime");
            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.ServiceProvider)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ServiceProviderId).HasColumnName("ServiceProviderID");
            entity.Property(e => e.StatusId).HasColumnName("StatusID");
            entity.Property(e => e.SysAward).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.WithHoldingRate)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Withold).HasColumnType("decimal(18, 2)");
        });

        modelBuilder.Entity<VwClaimsBatch>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwClaimsBatch");

            entity.Property(e => e.AceeptTpa).HasColumnName("AceeptTPA");
            entity.Property(e => e.AmountAwarded).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.AmountClaimed).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ClaimsMonth).HasMaxLength(35);
            entity.Property(e => e.CompletedEntryDate).HasColumnType("datetime");
            entity.Property(e => e.ConfirmAward).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ContactNo)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.DateOfClaim).HasColumnType("datetime");
            entity.Property(e => e.DateStamp).HasColumnType("datetime");
            entity.Property(e => e.MemberId).HasColumnName("MemberID");
            entity.Property(e => e.MoMoNumber)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.ModeOfSubmission)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PeriodFrom).HasColumnType("datetime");
            entity.Property(e => e.PeriodTo).HasColumnType("datetime");
            entity.Property(e => e.ProviderClaimed).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.RmName)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("RM_Name");
            entity.Property(e => e.Service)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ServiceProvider)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ServiceProviderId).HasColumnName("ServiceProviderID");
            entity.Property(e => e.ServiceType)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ServiceTypeId).HasColumnName("ServiceTypeID");
            entity.Property(e => e.Sms).HasColumnName("SMS");
            entity.Property(e => e.StartEntryDate).HasColumnType("datetime");
            entity.Property(e => e.Status)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.StatusId).HasColumnName("StatusID");
            entity.Property(e => e.SubmittedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.SystemAward).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.SystemClaim).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Tpa).HasColumnName("TPA");
            entity.Property(e => e.TypeOfBatch)
                .HasMaxLength(13)
                .IsUnicode(false);
            entity.Property(e => e.TypeOfClaims)
                .HasMaxLength(17)
                .IsUnicode(false);
            entity.Property(e => e.Username)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<VwClaimsBatchHspaward>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwClaimsBatch_HSPAwards");

            entity.Property(e => e.AmountClaimed).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.AmountDue).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.AmountWord)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.AwardDate).HasColumnType("datetime");
            entity.Property(e => e.Awarded).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.BatchType)
                .HasMaxLength(2)
                .IsUnicode(false);
            entity.Property(e => e.Building).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Claimed).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Comment)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.CustomerId)
                .HasMaxLength(13)
                .IsUnicode(false)
                .HasColumnName("CustomerID");
            entity.Property(e => e.DateOfClaim).HasColumnType("datetime");
            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.MonthOfClaim).HasMaxLength(34);
            entity.Property(e => e.ServiceProvider)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ServiceProviderId).HasColumnName("ServiceProviderID");
            entity.Property(e => e.StatusId).HasColumnName("StatusID");
            entity.Property(e => e.SysAward).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Tpa).HasColumnName("TPA");
            entity.Property(e => e.WithHoldingRate)
                .HasMaxLength(4)
                .IsUnicode(false);
            entity.Property(e => e.Withold).HasColumnType("decimal(18, 2)");
        });

        modelBuilder.Entity<VwClaimsBatchRefund>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwClaimsBatch_Refunds");

            entity.Property(e => e.AmountAwarded).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.AmountClaimed).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Bank)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.BankId).HasColumnName("BankID");
            entity.Property(e => e.ChequeAmount).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ChequeDate).HasColumnType("datetime");
            entity.Property(e => e.ChequeNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CompanyId).HasColumnName("CompanyID");
            entity.Property(e => e.CompanyName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.CompletedEntryDate).HasColumnType("datetime");
            entity.Property(e => e.ConfirmAward).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ContactNo)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.ContactPersonEmail)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.DateOfClaim).HasColumnType("datetime");
            entity.Property(e => e.DateStamp).HasColumnType("datetime");
            entity.Property(e => e.Dob).HasColumnName("DOB");
            entity.Property(e => e.Email)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.FirstName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.FullName)
                .HasMaxLength(304)
                .IsUnicode(false);
            entity.Property(e => e.Gender)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.MemberId).HasColumnName("MemberID");
            entity.Property(e => e.MembershipNo)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.MoMoNumber)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.ModeOfSubmission)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Mphone)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.PaymentMode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PeriodFrom).HasColumnType("datetime");
            entity.Property(e => e.PeriodTo).HasColumnType("datetime");
            entity.Property(e => e.PlanName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PrinceMemberNo)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.PrincipalEmail)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.PrincipalName)
                .HasMaxLength(304)
                .IsUnicode(false);
            entity.Property(e => e.ProviderClaimed).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Relationship)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ServiceProviderId).HasColumnName("ServiceProviderID");
            entity.Property(e => e.Sms).HasColumnName("SMS");
            entity.Property(e => e.StartEntryDate).HasColumnType("datetime");
            entity.Property(e => e.Status)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.StatusId).HasColumnName("StatusID");
            entity.Property(e => e.SubmittedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.SystemAward).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.SystemClaim).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Tpa).HasColumnName("TPA");
            entity.Property(e => e.Username)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<VwClaimsBatchRefundReIssue>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwClaimsBatch_RefundReIssues");

            entity.Property(e => e.AmountAwarded).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.AmountClaimed).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.BatchNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CompanyId).HasColumnName("CompanyID");
            entity.Property(e => e.CompanyName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ContactPersonEmail)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.DateOfClaim).HasColumnType("datetime");
            entity.Property(e => e.Dob).HasColumnName("DOB");
            entity.Property(e => e.Email)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.FirstName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.FullName)
                .HasMaxLength(304)
                .IsUnicode(false);
            entity.Property(e => e.Gender)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.MemberId).HasColumnName("MemberID");
            entity.Property(e => e.MembershipNo)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.MoMoNumber)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.Mphone)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.PaymentMode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PlanName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PrinceMemberNo)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.PrincipalEmail)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.PrincipalId).HasColumnName("PrincipalID");
            entity.Property(e => e.PrincipalName)
                .HasMaxLength(304)
                .IsUnicode(false);
            entity.Property(e => e.Relationship)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ServiceProviderId).HasColumnName("ServiceProviderID");
            entity.Property(e => e.Status)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.StatusId).HasColumnName("StatusID");
            entity.Property(e => e.Tpa).HasColumnName("TPA");
            entity.Property(e => e.UserId).HasColumnName("UserID");
            entity.Property(e => e.Username)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<VwClaimsBatchRefundsApproved>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwClaimsBatch_RefundsApproved");

            entity.Property(e => e.CompanyId).HasColumnName("CompanyID");
            entity.Property(e => e.CompanyName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.DateOfClaim).HasColumnType("datetime");
            entity.Property(e => e.DateStamp).HasColumnType("datetime");
            entity.Property(e => e.FullName)
                .HasMaxLength(304)
                .IsUnicode(false);
            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.MemberId).HasColumnName("MemberID");
            entity.Property(e => e.MemberNo)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.MoMoNumber)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.PaymentMode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PrinceMemberNo)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.PrincipalId).HasColumnName("PrincipalID");
            entity.Property(e => e.PrincipalName)
                .HasMaxLength(304)
                .IsUnicode(false);
            entity.Property(e => e.Rejection).HasColumnType("decimal(19, 2)");
            entity.Property(e => e.ServiceProviderId).HasColumnName("ServiceProviderID");
            entity.Property(e => e.StatusId).HasColumnName("StatusID");
            entity.Property(e => e.SysAmountAwarded).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.SysAmountClaimed).HasColumnType("decimal(18, 2)");
        });

        modelBuilder.Entity<VwClaimsDetail>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwClaimsDetails");

            entity.Property(e => e.ApprovedAmount).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Awarded).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Claimed).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ClaimsNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Diff).HasColumnType("decimal(19, 2)");
            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.ProductId).HasColumnName("ProductID");
            entity.Property(e => e.ReviewAwarded).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.RxRowId).HasColumnName("RX_RowID");
            entity.Property(e => e.StampDate).HasColumnType("datetime");
            entity.Property(e => e.TariffName)
                .HasMaxLength(5000)
                .IsUnicode(false);
            entity.Property(e => e.TariffXRejectionComments).HasColumnName("Tariff_X_RejectionComments");
            entity.Property(e => e.TypeName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UnitPrice).HasColumnType("decimal(18, 3)");
            entity.Property(e => e.VettingId).HasColumnName("VettingID");
        });

        modelBuilder.Entity<VwClaimsDetailsOnline>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwClaimsDetails_Online");

            entity.Property(e => e.ApprovedAmount).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Awarded).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Claimed).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ClaimsNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Diff).HasColumnType("decimal(19, 2)");
            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.ProductId).HasColumnName("ProductID");
            entity.Property(e => e.RxItemName)
                .IsUnicode(false)
                .HasColumnName("rx_item_name");
            entity.Property(e => e.RxRowId).HasColumnName("RX_RowID");
            entity.Property(e => e.StampDate).HasColumnType("datetime");
            entity.Property(e => e.TariffName)
                .HasMaxLength(5000)
                .IsUnicode(false);
            entity.Property(e => e.UnitPrice).HasColumnType("decimal(18, 3)");
            entity.Property(e => e.VettingId).HasColumnName("VettingID");
        });

        modelBuilder.Entity<VwClaimsDetailsReIssue>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwClaimsDetails_ReIssues");

            entity.Property(e => e.ApprovedAmount).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.BatchNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Claimed).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ClaimsDetailsId).HasColumnName("ClaimsDetailsID");
            entity.Property(e => e.ClaimsNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Diff).HasColumnType("decimal(19, 2)");
            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.ProductId).HasColumnName("ProductID");
            entity.Property(e => e.ReviewAwarded).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.StampDate).HasColumnType("datetime");
            entity.Property(e => e.TariffName)
                .HasMaxLength(5000)
                .IsUnicode(false);
            entity.Property(e => e.TariffXRejectionComments).HasColumnName("Tariff_X_RejectionComments");
            entity.Property(e => e.TypeName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.VettingId).HasColumnName("VettingID");
        });

        modelBuilder.Entity<VwClaimsDetailsXTariffRejection>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwClaimsDetails_X_Tariff_Rejections");

            entity.Property(e => e.ApprovedAmount).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Awarded).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Claimed).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ClaimsDetailsId).HasColumnName("ClaimsDetailsID");
            entity.Property(e => e.ClaimsNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.RejectedAmount).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.RowId).HasColumnName("RowID");
            entity.Property(e => e.RxRowId).HasColumnName("RX_RowID");
            entity.Property(e => e.StampDate).HasColumnType("datetime");
            entity.Property(e => e.TariffId).HasColumnName("TariffID");
            entity.Property(e => e.TariffName)
                .HasMaxLength(5000)
                .IsUnicode(false);
            entity.Property(e => e.TariffXRejectionCommentId).HasColumnName("Tariff_X_RejectionCommentID");
            entity.Property(e => e.TariffXRejectionComments).HasColumnName("Tariff_X_RejectionComments");
            entity.Property(e => e.UnitPrice).HasColumnType("decimal(18, 3)");
            entity.Property(e => e.UserId).HasColumnName("UserID");
        });

        modelBuilder.Entity<VwClaimsHeader>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwClaimsHeader");

            entity.Property(e => e.ClaimsNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Company)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.CompanyId).HasColumnName("CompanyID");
            entity.Property(e => e.ConfirmedDiagnosis)
                .IsUnicode(false)
                .HasColumnName("Confirmed_Diagnosis");
            entity.Property(e => e.DateStamp).HasColumnType("datetime");
            entity.Property(e => e.DateofAttendance).HasColumnType("datetime");
            entity.Property(e => e.Diagnosis).IsUnicode(false);
            entity.Property(e => e.Dob).HasColumnName("DOB");
            entity.Property(e => e.FullName)
                .HasMaxLength(304)
                .IsUnicode(false);
            entity.Property(e => e.Gender)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.InOutId).HasColumnName("InOutID");
            entity.Property(e => e.Inout)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.MemberId).HasColumnName("MemberID");
            entity.Property(e => e.MemberNo)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.PlanName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ProviderAmountClaimed).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Relationship)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ServiceProvider)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ServiceProviderId).HasColumnName("ServiceProviderID");
            entity.Property(e => e.Status)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.SysAmountAwarded).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.SysAmountClaimed).HasColumnType("decimal(18, 2)");
        });

        modelBuilder.Entity<VwClaimsHeaderAdvice>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwClaimsHeaderAdvice");

            entity.Property(e => e.BenefitOption)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ClaimsNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CompanyId).HasColumnName("CompanyID");
            entity.Property(e => e.CompanyName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.DateofAttendance).HasColumnType("datetime");
            entity.Property(e => e.Dob).HasColumnName("DOB");
            entity.Property(e => e.Fullname)
                .HasMaxLength(304)
                .IsUnicode(false);
            entity.Property(e => e.Gender)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.Inout)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.MemberId).HasColumnName("MemberID");
            entity.Property(e => e.MemberType)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.MembershipNo)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.PlanName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Relationship)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ServiceProvider)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ServiceType)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.SysAmountAwarded).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.SysAmountClaimed).HasColumnType("decimal(18, 2)");
        });

        modelBuilder.Entity<VwClaimsHeaderBuild>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwClaimsHeader_Build");

            entity.Property(e => e.AdminisionDate).HasColumnType("datetime");
            entity.Property(e => e.BenefitOptionId).HasColumnName("BenefitOptionID");
            entity.Property(e => e.ClaimsHeaderStatus).HasColumnName("Claims_Header_Status");
            entity.Property(e => e.ClaimsNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CompanyId).HasColumnName("CompanyID");
            entity.Property(e => e.DateofAttendance).HasColumnType("datetime");
            entity.Property(e => e.DischargeDate).HasColumnType("datetime");
            entity.Property(e => e.FacilityName)
                .HasMaxLength(200)
                .IsUnicode(false)
                .HasColumnName("facility_name");
            entity.Property(e => e.HeaderComemntId).HasColumnName("Header_ComemntID");
            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.InOutId).HasColumnName("InOutID");
            entity.Property(e => e.MemberId).HasColumnName("MemberID");
            entity.Property(e => e.MemberNo).IsUnicode(false);
            entity.Property(e => e.NmhProviderId).HasColumnName("NMH_ProviderID");
            entity.Property(e => e.Qty).HasColumnName("qty");
            entity.Property(e => e.RowId).HasColumnName("RowID");
            entity.Property(e => e.RxMasterProviderId).HasColumnName("RX_MasterProviderID");
            entity.Property(e => e.RxProviderId).HasColumnName("RX_ProviderID");
            entity.Property(e => e.Tpa).HasColumnName("TPA");
            entity.Property(e => e.UnitPrice).HasColumnName("unit_price");
        });

        modelBuilder.Entity<VwClaimsHeaderUtil>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwClaimsHeader_Util");

            entity.Property(e => e.ClaimsNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CompanyId).HasColumnName("CompanyID");
            entity.Property(e => e.CompanyName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.DateOfClaim).HasColumnType("datetime");
            entity.Property(e => e.DateStamp).HasColumnType("datetime");
            entity.Property(e => e.Datedisabled).HasColumnType("datetime");
            entity.Property(e => e.DateofAttendance).HasColumnType("datetime");
            entity.Property(e => e.Diagnosis).IsUnicode(false);
            entity.Property(e => e.Dob).HasColumnName("DOB");
            entity.Property(e => e.Fullname)
                .HasMaxLength(304)
                .IsUnicode(false);
            entity.Property(e => e.Gender)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.InOutId).HasColumnName("InOutID");
            entity.Property(e => e.Inout)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.MaritalStatus)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.MemberId).HasColumnName("MemberID");
            entity.Property(e => e.MemberType)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.MembershipNo)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.Occupation)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PlanName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PlanShortName)
                .HasMaxLength(10)
                .IsUnicode(false);
            entity.Property(e => e.PrincipalName)
                .HasMaxLength(304)
                .IsUnicode(false);
            entity.Property(e => e.ProviderAmountClaimed).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Region)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Relationship)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.RxProviderId).HasColumnName("rx_ProviderID");
            entity.Property(e => e.Service)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ServiceProvider)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ServiceProviderId).HasColumnName("ServiceProviderID");
            entity.Property(e => e.ServiceType)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.StampDate).HasColumnType("datetime");
            entity.Property(e => e.Status)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.SysAmountAwarded).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.SysAmountClaimed).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Title)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<VwClaimsHeaderUtilNew>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwClaimsHeader_Util_New");

            entity.Property(e => e.ClaimsNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CompanyId).HasColumnName("CompanyID");
            entity.Property(e => e.CompanyName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.DateOfClaim).HasColumnType("datetime");
            entity.Property(e => e.DateStamp).HasColumnType("datetime");
            entity.Property(e => e.Datedisabled).HasColumnType("datetime");
            entity.Property(e => e.DateofAttendance).HasColumnType("datetime");
            entity.Property(e => e.Diagnosis).IsUnicode(false);
            entity.Property(e => e.Dob).HasColumnName("DOB");
            entity.Property(e => e.Fullname)
                .HasMaxLength(304)
                .IsUnicode(false);
            entity.Property(e => e.Gender)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.InOutId).HasColumnName("InOutID");
            entity.Property(e => e.Inout)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.MaritalStatus)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.MemberId).HasColumnName("MemberID");
            entity.Property(e => e.MemberType)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.MembershipNo)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.Occupation)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PlanName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PlanShortName)
                .HasMaxLength(10)
                .IsUnicode(false);
            entity.Property(e => e.PrincipalName)
                .HasMaxLength(304)
                .IsUnicode(false);
            entity.Property(e => e.ProviderAmountClaimed).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Region)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Relationship)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.RxProviderId).HasColumnName("rx_ProviderID");
            entity.Property(e => e.Service)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ServiceProvider)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ServiceProviderId).HasColumnName("ServiceProviderID");
            entity.Property(e => e.ServiceType)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.StampDate).HasColumnType("datetime");
            entity.Property(e => e.Status)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.SysAmountAwarded).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.SysAmountClaimed).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Title)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<VwClaimsHeaderXDisease>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwClaimsHeader_X_Disease");

            entity.Property(e => e.ClaimsNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Code)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.Disease)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.DiseaseGroupId).HasColumnName("DiseaseGroupID");
            entity.Property(e => e.DiseaseId).HasColumnName("DiseaseID");
            entity.Property(e => e.RowId).HasColumnName("RowID");
        });

        modelBuilder.Entity<VwClaimsPayment>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwClaimsPayments");

            entity.Property(e => e.AmountWord)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.Bank)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.BankId).HasColumnName("BankID");
            entity.Property(e => e.ChequeAmount).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ChequeDate).HasColumnType("datetime");
            entity.Property(e => e.ChequeNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.DateStamp).HasColumnType("datetime");
            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.Smsstatus).HasColumnName("SMSStatus");
        });

        modelBuilder.Entity<VwClaimsRecievedHsp>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwClaimsRecieved_HSP");

            entity.Property(e => e.AmountClaimed).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.BatchType)
                .HasMaxLength(2)
                .IsUnicode(false);
            entity.Property(e => e.CustomerId)
                .HasMaxLength(13)
                .IsUnicode(false)
                .HasColumnName("CustomerID");
            entity.Property(e => e.DateOfClaim).HasColumnType("datetime");
            entity.Property(e => e.MonthOfClaim).HasMaxLength(34);
            entity.Property(e => e.ServiceProvider)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ServiceProviderId).HasColumnName("ServiceProviderID");
            entity.Property(e => e.StatusId).HasColumnName("StatusID");
            entity.Property(e => e.Tpa).HasColumnName("TPA");
        });

        modelBuilder.Entity<VwClientLetter>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwClientLetters");

            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.CrofficerId).HasColumnName("CROfficerId");
            entity.Property(e => e.CrofficerName)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("CROfficerName");
            entity.Property(e => e.DueDate).HasColumnType("datetime");
            entity.Property(e => e.Lmode)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("LMode");
            entity.Property(e => e.Lperiod)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("LPeriod");
            entity.Property(e => e.Ltype)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("LType");
            entity.Property(e => e.Topic)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<VwClientSession>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwClientSessions");

            entity.Property(e => e.Company)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.Feedback)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.Issues)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.Resolutions)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.SessionDate).HasColumnType("datetime");
            entity.Property(e => e.SessionType)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.Theme)
                .HasMaxLength(100)
                .IsUnicode(false);
        });

        modelBuilder.Entity<VwClientVisitation>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwClientVisitation");

            entity.Property(e => e.ClientRep)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Company)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.Issues)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.Nmirep)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("NMIRep");
            entity.Property(e => e.VisitDate).HasColumnType("datetime");
            entity.Property(e => e.VisitType)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<VwCompaniesSale>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwCompanies_Sales");

            entity.Property(e => e.ActuarialApprovedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ActuarialApprovedDate).HasColumnType("datetime");
            entity.Property(e => e.BillingCycleName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.BusinessApprovalDate).HasColumnType("datetime");
            entity.Property(e => e.BusinessApprovedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.BusinessDate).HasColumnType("datetime");
            entity.Property(e => e.CompanyApprovalBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CompanyApprovalDate).HasColumnType("datetime");
            entity.Property(e => e.CompanyApprovalPosition)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CompanyName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ContactPerson)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ContactPersonEmail)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ContactPersonPhone)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.ContactPersonPhone2)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.DigitalAddress)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.Email)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.NatureOfBusiness)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.OfficeLocation)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.PostalAddress)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ProposedStartDate).HasColumnType("datetime");
            entity.Property(e => e.Region)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.SourceOfBusiness)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.Telephone1)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.Telephone2)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.Tin)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("TIN");
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<VwCompaniesSummary>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("Vw_Companies_Summary");

            entity.Property(e => e.BusinessDate).HasColumnType("datetime");
            entity.Property(e => e.CompanyId).HasColumnName("CompanyID");
            entity.Property(e => e.CompanyName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ContactPerson)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Email)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ExecoCare).HasColumnName("EXECoCare");
            entity.Property(e => e.NatureOfBusiness)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.PolicyEndDate).HasColumnType("datetime");
            entity.Property(e => e.PolicyStartDate).HasColumnType("datetime");
            entity.Property(e => e.PostalAddress)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Telephone1)
                .HasMaxLength(100)
                .IsUnicode(false);
        });

        modelBuilder.Entity<VwCompany>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwCompanies");

            entity.Property(e => e.ActuarialApprovedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ActuarialApprovedDate).HasColumnType("datetime");
            entity.Property(e => e.BillingCycleName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.BusinessApprovalDate).HasColumnType("datetime");
            entity.Property(e => e.BusinessApprovedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.BusinessDate).HasColumnType("datetime");
            entity.Property(e => e.CompanyApprovalBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CompanyApprovalDate).HasColumnType("datetime");
            entity.Property(e => e.CompanyApprovalPosition)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CompanyName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ContactPerson)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ContactPersonEmail)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ContactPersonPhone)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ContactPersonPhone2)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.DigitalAddress)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.Email)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.NatureOfBusiness)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.OfficeLocation)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.PostalAddress)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ProposedStartDate).HasColumnType("datetime");
            entity.Property(e => e.Region)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.SourceOfBusiness)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.Telephone1)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Telephone2)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.Tin)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("TIN");
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<VwCompanyPlan>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwCompanyPlans");

            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.MemberType)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PlanName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PolicyCode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Premium).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<VwCompanyPlanBenefitGroup>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwCompanyPlan_BenefitGroups");

            entity.Property(e => e.BenefitGroup)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.Limit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ParentName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PlanName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PolicyCode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<VwCompanyPlanBenefitGroupsRenewal>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwCompanyPlan_BenefitGroups_Renewals");

            entity.Property(e => e.BenefitGroup)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.Limit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ParentName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PlanName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PolicyCode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<VwCompanyPlanBenefitGroupsSale>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwCompanyPlan_BenefitGroups_Sales");

            entity.Property(e => e.BenefitGroup)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.Limit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ParentName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PlanName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<VwCompanyPlanBenefitLimit>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwCompanyPlan_BenefitLimits");

            entity.Property(e => e.AdultCoverLimit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Benefit)
                .HasMaxLength(200)
                .IsUnicode(false);
            entity.Property(e => e.BenefitGroup)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.BenefitId).HasColumnName("BenefitID");
            entity.Property(e => e.ChildCoverLimit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.CompanyName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.CostPerVisit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.CoverComment)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.CoverStatus)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.CustomType)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.FemaleCoverLimit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.MaleCoverLimit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.PlanId).HasColumnName("PlanID");
            entity.Property(e => e.PlanName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PolicyCode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.RowId).HasColumnName("RowID");
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<VwCompanyPlanBenefitLimitsRenewal>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwCompanyPlan_BenefitLimits_Renewals");

            entity.Property(e => e.AdultCoverLimit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Benefit)
                .HasMaxLength(200)
                .IsUnicode(false);
            entity.Property(e => e.BenefitGroup)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.BenefitId).HasColumnName("BenefitID");
            entity.Property(e => e.ChildCoverLimit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.CompanyName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.CostPerVisit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.CoverComment)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.CoverStatus)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.CustomType)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.FemaleCoverLimit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.MaleCoverLimit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.PlanId).HasColumnName("PlanID");
            entity.Property(e => e.PlanName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PolicyCode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.RowId).HasColumnName("RowID");
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<VwCompanyPlanBenefitLimitsSale>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwCompanyPlan_BenefitLimits_Sales");

            entity.Property(e => e.AdultCoverLimit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Benefit)
                .HasMaxLength(200)
                .IsUnicode(false);
            entity.Property(e => e.BenefitGroup)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.BenefitId).HasColumnName("BenefitID");
            entity.Property(e => e.ChildCoverLimit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.CompanyName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.CostPerVisit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.CoverComment)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.CoverLimit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.CoverStatus)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.CustomType)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.FemaleCoverLimit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.MaleCoverLimit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.PlanId).HasColumnName("PlanID");
            entity.Property(e => e.PlanName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.RowId).HasColumnName("RowID");
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<VwCompanyPlanBenefitParent>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwCompanyPlan_BenefitParent");

            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.Limit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ParentName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PlanName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PolicyCode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<VwCompanyPlanBenefitParentRenewal>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwCompanyPlan_BenefitParent_Renewals");

            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.Limit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ParentName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PlanName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PolicyCode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<VwCompanyPlanBenefitParentSale>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwCompanyPlan_BenefitParent_Sales");

            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.Limit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ParentName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PlanName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<VwCompanyPlansRenewal>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwCompanyPlans_Renewals");

            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.MemberType)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PlanName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PolicyCode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Premium).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ProposedPremium).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ProposedPremiumApprovedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ProposedPremiumApprovedDate).HasColumnType("datetime");
            entity.Property(e => e.ProposedPremiumBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ProposedPremiumDate).HasColumnType("datetime");
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<VwCompanyPlansSale>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwCompanyPlans_Sales");

            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.MemberType)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PlanName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Premium).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<VwCompanyPolicyActive>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("Vw_CompanyPolicy_Active");

            entity.Property(e => e.CompanyName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ExpiryType)
                .HasMaxLength(9)
                .IsUnicode(false)
                .HasColumnName("Expiry_Type");
            entity.Property(e => e.PolicyCode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PolicyEndDate).HasColumnType("datetime");
            entity.Property(e => e.PolicyStartDate).HasColumnType("datetime");
            entity.Property(e => e.StartedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.StartedDate).HasColumnType("datetime");
            entity.Property(e => e.TerminatedDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<VwCompanyPolicyRunning>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("Vw_CompanyPolicy_Running");

            entity.Property(e => e.CompanyName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.ExpiryType)
                .HasMaxLength(9)
                .IsUnicode(false)
                .HasColumnName("Expiry_Type");
            entity.Property(e => e.PolicyCode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PolicyEndDate).HasColumnType("datetime");
            entity.Property(e => e.PolicyStartDate).HasColumnType("datetime");
            entity.Property(e => e.StartedDate).HasColumnType("datetime");
            entity.Property(e => e.TerminatedDate).HasColumnType("datetime");
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<VwCompanySalesComment>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwCompany_Sales_Comments");

            entity.Property(e => e.Comment)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.Department)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.EmailAddress)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<VwConsumption>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwConsumption");

            entity.Property(e => e.Awarded).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.BenefitOption)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Claimed).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ClaimsDetailsId).HasColumnName("ClaimsDetailsID");
            entity.Property(e => e.ClaimsNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CompanyId).HasColumnName("CompanyID");
            entity.Property(e => e.CompanyName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.DateofAttendance).HasColumnType("datetime");
            entity.Property(e => e.Dob).HasColumnName("DOB");
            entity.Property(e => e.Fullname)
                .HasMaxLength(304)
                .IsUnicode(false);
            entity.Property(e => e.Gender)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Inout)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.MemberType)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Relationship)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Service)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ServiceProvider)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ServiceType)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.TypeName)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<VwDentalClaimsDetail>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("Vw_Dental_ClaimsDetails");

            entity.Property(e => e.ClaimsNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CompanyName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.DateofAttendance).HasColumnType("datetime");
            entity.Property(e => e.Diagnosis)
                .IsUnicode(false)
                .HasColumnName("diagnosis");
            entity.Property(e => e.EyeOptical)
                .IsUnicode(false)
                .HasColumnName("eye_optical");
            entity.Property(e => e.FullName)
                .HasMaxLength(304)
                .IsUnicode(false);
            entity.Property(e => e.Gender)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Item)
                .IsUnicode(false)
                .HasColumnName("item");
            entity.Property(e => e.MemberAge)
                .HasMaxLength(18)
                .IsUnicode(false);
            entity.Property(e => e.MemberNo)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.NmhProviderId).HasColumnName("NMH_ProviderID");
            entity.Property(e => e.PlanName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ProviderId).HasColumnName("provider_id");
            entity.Property(e => e.RowId).HasColumnName("RowID");
            entity.Property(e => e.ServiceProvider)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Toothnos)
                .IsUnicode(false)
                .HasColumnName("toothnos");
            entity.Property(e => e.TypeOfVisit)
                .IsUnicode(false)
                .HasColumnName("type_of_visit");
        });

        modelBuilder.Entity<VwDiseaseXTariff>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwDisease_X_Tariff");

            entity.Property(e => e.DiseaseGroupId).HasColumnName("DiseaseGroupID");
            entity.Property(e => e.DiseaseId).HasColumnName("DiseaseID");
            entity.Property(e => e.RowId).HasColumnName("RowID");
            entity.Property(e => e.ServiceId).HasColumnName("ServiceID");
            entity.Property(e => e.ServiceName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.TariffCode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.TariffId).HasColumnName("TariffID");
            entity.Property(e => e.TariffName)
                .HasMaxLength(5000)
                .IsUnicode(false);
        });

        modelBuilder.Entity<VwFrontOfficeReceipt>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwFrontOfficeReceipt");

            entity.Property(e => e.Amount).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ContactNo)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.DateReceived).HasColumnType("datetime");
            entity.Property(e => e.Designation)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.DocumentType)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.MonthOfSubmission).HasColumnType("datetime");
            entity.Property(e => e.ServiceProvider)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.SubmittedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<VwHealthScreening>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwHealthScreening");

            entity.Property(e => e.Company)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.HealthFacility)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ResourcePerson)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ScreenDate).HasColumnType("datetime");
            entity.Property(e => e.ScreenResults)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.ScreenStats)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.ScreenType)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<VwHealthTalk>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwHealthTalks");

            entity.Property(e => e.Company)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.ResourcePerson)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.TalkDate).HasColumnType("datetime");
            entity.Property(e => e.Topic)
                .HasMaxLength(100)
                .IsUnicode(false);
        });

        modelBuilder.Entity<VwIdcard>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("Vw_IDCard");

            entity.Property(e => e.BenefitOptionId).HasColumnName("BenefitOptionID");
            entity.Property(e => e.CompanyId).HasColumnName("CompanyID");
            entity.Property(e => e.CompanyName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Datedisabled).HasColumnType("datetime");
            entity.Property(e => e.Dob)
                .HasColumnType("datetime")
                .HasColumnName("DOB");
            entity.Property(e => e.Email)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ExpiryDate).HasColumnType("datetime");
            entity.Property(e => e.FirstName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Fullname)
                .HasMaxLength(304)
                .IsUnicode(false);
            entity.Property(e => e.GenderId).HasColumnName("GenderID");
            entity.Property(e => e.GenderShort)
                .HasMaxLength(10)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.Hphone)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.IndvidualEx).HasColumnType("datetime");
            entity.Property(e => e.Logo).HasColumnType("image");
            entity.Property(e => e.MainPlan)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.MaritalId).HasColumnName("MaritalID");
            entity.Property(e => e.MemberNo)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.MemberTypeId).HasColumnName("MemberTypeID");
            entity.Property(e => e.Mphone)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Nhisno)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("NHISNo");
            entity.Property(e => e.OccupationId).HasColumnName("OccupationID");
            entity.Property(e => e.OtherName)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("otherName");
            entity.Property(e => e.OtherNames)
                .HasMaxLength(202)
                .IsUnicode(false);
            entity.Property(e => e.Pic)
                .HasMaxLength(4041)
                .IsUnicode(false);
            entity.Property(e => e.Plan)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PrincipalId).HasColumnName("PrincipalID");
            entity.Property(e => e.PrincipalNames)
                .HasMaxLength(304)
                .IsUnicode(false);
            entity.Property(e => e.RegistrationDate).HasColumnType("datetime");
            entity.Property(e => e.RelationId).HasColumnName("RelationID");
            entity.Property(e => e.Relationship)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.StartDate).HasColumnType("datetime");
            entity.Property(e => e.Status)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.StatusId).HasColumnName("StatusID");
            entity.Property(e => e.Surname)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.TitleId).HasColumnName("TitleID");
        });

        modelBuilder.Entity<VwMember>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwMembers");

            entity.Property(e => e.ActualMemberType)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ActualStatus)
                .HasMaxLength(8)
                .IsUnicode(false);
            entity.Property(e => e.ActualStatusId).HasColumnName("ActualStatusID");
            entity.Property(e => e.BenefitOptionId).HasColumnName("BenefitOptionID");
            entity.Property(e => e.CardPin)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("cardPin");
            entity.Property(e => e.CompanyId).HasColumnName("CompanyID");
            entity.Property(e => e.CompanyName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Datedisabled).HasColumnType("datetime");
            entity.Property(e => e.Dob).HasColumnName("DOB");
            entity.Property(e => e.Email)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.EmpNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.EmployeeStatus)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ExpiryDate).HasColumnType("datetime");
            entity.Property(e => e.FirstName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Fname)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("FName");
            entity.Property(e => e.Fullname)
                .HasMaxLength(304)
                .IsUnicode(false);
            entity.Property(e => e.Gender)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.GenderId).HasColumnName("GenderID");
            entity.Property(e => e.GenderShort)
                .HasMaxLength(10)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.HpAngina).HasColumnName("hp_Angina");
            entity.Property(e => e.HpAutoimmune).HasColumnName("hp_Autoimmune");
            entity.Property(e => e.HpBackNeck).HasColumnName("hp_Back_Neck");
            entity.Property(e => e.HpCancerTumours).HasColumnName("hp_Cancer_Tumours");
            entity.Property(e => e.HpCardiovascular).HasColumnName("hp_Cardiovascular");
            entity.Property(e => e.HpChronicBronchitis).HasColumnName("hp_ChronicBronchitis");
            entity.Property(e => e.HpChronicRespiratory).HasColumnName("hp_ChronicRespiratory");
            entity.Property(e => e.HpCongenitalHeart).HasColumnName("hp_Congenital_Heart");
            entity.Property(e => e.HpCysticFibrosis).HasColumnName("hp_CysticFibrosis");
            entity.Property(e => e.HpDiabetes).HasColumnName("hp_Diabetes");
            entity.Property(e => e.HpDigestiveSystem).HasColumnName("hp_DigestiveSystem");
            entity.Property(e => e.HpEmbolism).HasColumnName("hp_Embolism");
            entity.Property(e => e.HpEmphysema).HasColumnName("hp_Emphysema");
            entity.Property(e => e.HpEndocrine).HasColumnName("hp_Endocrine");
            entity.Property(e => e.HpFibroid).HasColumnName("hp_Fibroid");
            entity.Property(e => e.HpGallBladder).HasColumnName("hp_GallBladder");
            entity.Property(e => e.HpGout).HasColumnName("hp_Gout");
            entity.Property(e => e.HpHernia).HasColumnName("hp_Hernia");
            entity.Property(e => e.HpHypertension).HasColumnName("hp_Hypertension");
            entity.Property(e => e.HpIntestinalFibrosis).HasColumnName("hp_IntestinalFibrosis");
            entity.Property(e => e.HpKidney).HasColumnName("hp_Kidney");
            entity.Property(e => e.HpLeukemia).HasColumnName("hp_Leukemia");
            entity.Property(e => e.HpLiver).HasColumnName("hp_Liver");
            entity.Property(e => e.HpLung).HasColumnName("hp_Lung");
            entity.Property(e => e.HpMoreInfo)
                .HasMaxLength(200)
                .IsUnicode(false)
                .HasColumnName("hp_MoreInfo");
            entity.Property(e => e.HpMusculoskeletal).HasColumnName("hp_Musculoskeletal");
            entity.Property(e => e.HpNephritis).HasColumnName("hp_Nephritis");
            entity.Property(e => e.HpOthers).HasColumnName("hp_Others");
            entity.Property(e => e.HpPregnant).HasColumnName("hp_Pregnant");
            entity.Property(e => e.Hphone)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.HronlineId)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("HROnline_ID");
            entity.Property(e => e.HronlinePrinId)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("HROnline_Prin_ID");
            entity.Property(e => e.HronlineUpload).HasColumnName("HROnline_Upload");
            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.IndvidualEx).HasColumnType("datetime");
            entity.Property(e => e.MainPlanName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.MaritalId).HasColumnName("MaritalID");
            entity.Property(e => e.MaritalStatus)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.MemberNo)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.MemberRegstDate).HasColumnType("datetime");
            entity.Property(e => e.MemberType)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.MemberTypeId).HasColumnName("MemberTypeID");
            entity.Property(e => e.MembershipNo)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.Mphone)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.MyHealthPrincipalId).HasColumnName("MyHealth_PrincipalID");
            entity.Property(e => e.MyHealthRegistId).HasColumnName("MyHealth_RegistID");
            entity.Property(e => e.NationalIdno)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("NationalIDNo");
            entity.Property(e => e.NewMember)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Nhisno)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("NHISNo");
            entity.Property(e => e.Occupation)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.OccupationId).HasColumnName("OccupationID");
            entity.Property(e => e.OtherName)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("otherName");
            entity.Property(e => e.OtherNames)
                .HasMaxLength(202)
                .IsUnicode(false);
            entity.Property(e => e.Picpath)
                .HasMaxLength(4000)
                .IsUnicode(false)
                .HasColumnName("picpath");
            entity.Property(e => e.PlanName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PlanShortName)
                .HasMaxLength(10)
                .IsUnicode(false);
            entity.Property(e => e.PrincipalId).HasColumnName("PrincipalID");
            entity.Property(e => e.PrincipalName)
                .HasMaxLength(304)
                .IsUnicode(false);
            entity.Property(e => e.PrincipalPhoneNo)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.RegistrationDate).HasColumnType("datetime");
            entity.Property(e => e.RelationId).HasColumnName("RelationID");
            entity.Property(e => e.Relationship)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.RxOnlineId).HasColumnName("RX_OnlineID");
            entity.Property(e => e.SentSms).HasColumnName("SentSMS");
            entity.Property(e => e.StartDate).HasColumnType("datetime");
            entity.Property(e => e.Status)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.StatusId).HasColumnName("StatusID");
            entity.Property(e => e.Surname)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Title)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.TitleId).HasColumnName("TitleID");
            entity.Property(e => e.UniqueId).HasColumnName("UniqueID");
            entity.Property(e => e.Updated).HasColumnName("UPDATED");
            entity.Property(e => e.UploadDateTime).HasColumnType("datetime");
        });

        modelBuilder.Entity<VwMemberPlanBenefitGroup>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwMemberPlan_BenefitGroups");

            entity.Property(e => e.BenefitGroup)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.Limit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ParentName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PlanName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PolicyCode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<VwMemberPlanBenefitLimit>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwMemberPlan_BenefitLimits");

            entity.Property(e => e.AdultCoverLimit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Benefit)
                .HasMaxLength(200)
                .IsUnicode(false);
            entity.Property(e => e.BenefitGroup)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.BenefitId).HasColumnName("BenefitID");
            entity.Property(e => e.ChildCoverLimit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.CostPerVisit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.CoverComment)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.CoverStatus)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.CustomType)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.FemaleCoverLimit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.MaleCoverLimit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.PlanId).HasColumnName("PlanID");
            entity.Property(e => e.PlanName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PolicyCode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.RowId).HasColumnName("RowID");
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<VwMemberPlanBenefitParent>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwMemberPlan_BenefitParent");

            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.Limit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ParentName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PlanName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PolicyCode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<VwMemberPolicy>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwMemberPolicy");

            entity.Property(e => e.CustomizedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CustomizedDate).HasColumnType("datetime");
            entity.Property(e => e.DateStamp).HasColumnType("datetime");
            entity.Property(e => e.EndDate).HasColumnType("datetime");
            entity.Property(e => e.PlanName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PolicyNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.StartDate).HasColumnType("datetime");
            entity.Property(e => e.Username)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<VwMemberStatusInfo>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwMemberStatusInfo");

            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.EffectiveDate).HasColumnType("datetime");
            entity.Property(e => e.MemberId).HasColumnName("MemberID");
            entity.Property(e => e.RowId).HasColumnName("RowID");
            entity.Property(e => e.Status)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.StatusId).HasColumnName("StatusID");
            entity.Property(e => e.UserId).HasColumnName("UserID");
            entity.Property(e => e.Username)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<VwOnlineUpload>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("Vw_Online_Uploads");

            entity.Property(e => e.ActualStatusId).HasColumnName("ActualStatusID");
            entity.Property(e => e.BalanceStartDate)
                .HasColumnType("datetime")
                .HasColumnName("balance_start_date");
            entity.Property(e => e.CardPin)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("cardPin");
            entity.Property(e => e.CompanyId).HasColumnName("CompanyID");
            entity.Property(e => e.DateOfBirth).HasColumnName("date_of_birth");
            entity.Property(e => e.Email)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Employer)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("employer");
            entity.Property(e => e.ExpiryDate)
                .HasColumnType("datetime")
                .HasColumnName("expiry_date");
            entity.Property(e => e.IndvidualEx).HasColumnType("datetime");
            entity.Property(e => e.InsertDeleteStatus)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("insert_delete_status");
            entity.Property(e => e.MemberId).HasColumnName("member_id");
            entity.Property(e => e.MemberNo)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("member_no");
            entity.Property(e => e.MemberPlan)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("member_plan");
            entity.Property(e => e.MemberType)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.NationalIdno)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("NationalIDNo");
            entity.Property(e => e.OldMemberNo)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("old_member_no");
            entity.Property(e => e.Othernames)
                .HasMaxLength(201)
                .IsUnicode(false)
                .HasColumnName("othernames");
            entity.Property(e => e.PlanId)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("PlanID");
            entity.Property(e => e.PrincipalId).HasColumnName("PrincipalID");
            entity.Property(e => e.Relationship)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.RxMemberId)
                .HasMaxLength(103)
                .IsUnicode(false)
                .HasColumnName("rx_member_id");
            entity.Property(e => e.Sex)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("sex");
            entity.Property(e => e.StartDate).HasColumnType("datetime");
            entity.Property(e => e.Status)
                .HasMaxLength(8)
                .IsUnicode(false);
            entity.Property(e => e.StatusId).HasColumnName("StatusID");
            entity.Property(e => e.Surname)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.TelephoneNo)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("telephone_no");
        });

        modelBuilder.Entity<VwOnlineUploadHr>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("Vw_Online_Upload_HR");

            entity.Property(e => e.CardPin)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("cardPin");
            entity.Property(e => e.Company)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.CompanyId).HasColumnName("CompanyID");
            entity.Property(e => e.ConfirmRecord).HasColumnName("Confirm_Record");
            entity.Property(e => e.Dob).HasColumnName("DOB");
            entity.Property(e => e.Dobday).HasColumnName("DOBDay");
            entity.Property(e => e.Dobmonth).HasColumnName("DOBMonth");
            entity.Property(e => e.Dobyear).HasColumnName("DOBYear");
            entity.Property(e => e.Email)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.FirstName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Gender)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.HronlineId).HasColumnName("HROnline_ID");
            entity.Property(e => e.IsEdit).HasColumnName("Is_edit");
            entity.Property(e => e.MemberId).HasColumnName("Member_ID");
            entity.Property(e => e.MemberNo)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.MemberPlan)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("member_plan");
            entity.Property(e => e.MemberType)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("Member_type");
            entity.Property(e => e.NationalIdno)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("NationalIDNo");
            entity.Property(e => e.Nhisno)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("NHISNo");
            entity.Property(e => e.OtherName)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("otherName");
            entity.Property(e => e.PhoneNo2)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.PlanId).HasColumnName("Plan_id");
            entity.Property(e => e.PrimaryPhoneNo1)
                .HasMaxLength(101)
                .IsUnicode(false);
            entity.Property(e => e.PrincipalId).HasColumnName("PrincipalID");
            entity.Property(e => e.PrincipalNames)
                .HasMaxLength(304)
                .IsUnicode(false);
            entity.Property(e => e.RelationshipType)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("Relationship_type");
            entity.Property(e => e.StaffId)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("Staff_ID");
            entity.Property(e => e.Surname)
                .HasMaxLength(100)
                .IsUnicode(false);
        });

        modelBuilder.Entity<VwPlan>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwPlans");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.IsFamily).HasColumnName("isFamily");
            entity.Property(e => e.MainPlanName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PlanName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Prefix)
                .HasMaxLength(10)
                .IsUnicode(false);
            entity.Property(e => e.Premium).HasColumnType("decimal(18, 2)");
        });

        modelBuilder.Entity<VwPlanBenefitGroup>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwPlan_BenefitGroups");

            entity.Property(e => e.BenefitGroup)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Limit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ParentName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PlanName)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<VwPlanBenefitLimit>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwPlan_BenefitLimits");

            entity.Property(e => e.Benefit)
                .HasMaxLength(200)
                .IsUnicode(false);
            entity.Property(e => e.BenefitGroup)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.BenefitId).HasColumnName("BenefitID");
            entity.Property(e => e.CoverComment)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.CoverLimit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.CoverStatus)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.PlanId).HasColumnName("PlanID");
            entity.Property(e => e.PlanName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.RowId).HasColumnName("RowID");
        });

        modelBuilder.Entity<VwPlanBenefitParent>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwPlan_BenefitParent");

            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.Limit).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ParentName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PlanName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<VwPrincipal>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwPrincipals");

            entity.Property(e => e.BenefitOptionId).HasColumnName("BenefitOptionID");
            entity.Property(e => e.CompanyId).HasColumnName("CompanyID");
            entity.Property(e => e.CompanyName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Email)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.EmpNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.FirstName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Gender)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.GenderId).HasColumnName("GenderID");
            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.MembershipNo)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.Mphone)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.PlanName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PrincipalName)
                .HasMaxLength(304)
                .IsUnicode(false);
            entity.Property(e => e.Status)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<VwProformaInvoice>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwProformaInvoice");

            entity.Property(e => e.AuthorizedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.BrokerContactNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.BrokerContactPerson)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.BrokerName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ContactNo)
                .HasMaxLength(10)
                .IsUnicode(false);
            entity.Property(e => e.CustomerAddress)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CustomerAttn)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.CustomerName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.CustomerPhone)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.CustomerState)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.DateCreated).HasColumnType("datetime");
            entity.Property(e => e.InvoiceAmount).HasColumnType("decimal(19, 2)");
            entity.Property(e => e.InvoiceDate).HasColumnType("datetime");
            entity.Property(e => e.InvoiceNo)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.MembershipFee).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.PremiumAmount).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.PreparedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.SourceOfBusiness)
                .HasMaxLength(10)
                .IsUnicode(false);
        });

        modelBuilder.Entity<VwProformaInvoiceSigned>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwProformaInvoiceSigned");

            entity.Property(e => e.AuthorizedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.BrokerContactNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.BrokerContactPerson)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.BrokerName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ContactNo)
                .HasMaxLength(10)
                .IsUnicode(false);
            entity.Property(e => e.CustomerAddress)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CustomerAttn)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.CustomerName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.CustomerPhone)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.CustomerState)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Description)
                .HasMaxLength(153)
                .IsUnicode(false);
            entity.Property(e => e.InvoiceDate).HasColumnType("datetime");
            entity.Property(e => e.InvoiceNo)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.PrepareSignPath)
                .HasMaxLength(200)
                .IsUnicode(false);
            entity.Property(e => e.PreparedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.SourceOfBusiness)
                .HasMaxLength(10)
                .IsUnicode(false);
        });

        modelBuilder.Entity<VwProformaProduct>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwProformaProducts");

            entity.Property(e => e.Description)
                .HasMaxLength(153)
                .IsUnicode(false);
            entity.Property(e => e.InvoiceNo)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.MemberType)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.OtherComment)
                .HasMaxLength(100)
                .IsUnicode(false);
        });

        modelBuilder.Entity<VwRefundsAdvice>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwRefunds_Advice");

            entity.Property(e => e.ApprovedAmount).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Claimed).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ClaimsDetailsId).HasColumnName("ClaimsDetailsID");
            entity.Property(e => e.ClaimsNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Item)
                .HasMaxLength(5000)
                .IsUnicode(false);
            entity.Property(e => e.TariffXRejectionComments).HasColumnName("Tariff_X_RejectionComments");
        });

        modelBuilder.Entity<VwRefundsPaymentAdvice>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("VwRefunds_PaymentAdvice");

            entity.Property(e => e.AmountClaimed).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ApprovedAmount).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Bank)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ChequeAmount).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ChequeNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Claimed).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ClaimsDetailsId).HasColumnName("ClaimsDetailsID");
            entity.Property(e => e.ClaimsNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Comment)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.CompanyName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ConfirmAward).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.DateOfClaim).HasColumnType("datetime");
            entity.Property(e => e.DateofAttendance).HasColumnType("datetime");
            entity.Property(e => e.Fullname)
                .HasMaxLength(304)
                .IsUnicode(false);
            entity.Property(e => e.Item)
                .HasMaxLength(5000)
                .IsUnicode(false);
            entity.Property(e => e.MembershipNo)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.PaymentMode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PrincipalName)
                .HasMaxLength(304)
                .IsUnicode(false);
            entity.Property(e => e.ServiceProviderId).HasColumnName("ServiceProviderID");
            entity.Property(e => e.TariffXRejectionComments).HasColumnName("Tariff_X_RejectionComments");
        });

        modelBuilder.Entity<VwRefundsPrescription>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwRefundsPrescriptions");

            entity.Property(e => e.ClaimsNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.FileDate).HasColumnType("datetime");
            entity.Property(e => e.FilePath)
                .HasMaxLength(200)
                .IsUnicode(false);
            entity.Property(e => e.ServiceProvider)
                .HasMaxLength(100)
                .IsUnicode(false);
        });

        modelBuilder.Entity<VwRefundsReceipt>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwRefundsReceipts");

            entity.Property(e => e.ClaimsNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Comment)
                .HasMaxLength(200)
                .IsUnicode(false);
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.FilePath)
                .HasMaxLength(200)
                .IsUnicode(false);
            entity.Property(e => e.InOutId).HasColumnName("InOutID");
            entity.Property(e => e.Inout)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Reason)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ReceiptAmount).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ReceiptDate).HasColumnType("datetime");
            entity.Property(e => e.ReceiptNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ServiceProvider)
                .HasMaxLength(100)
                .IsUnicode(false);
        });

        modelBuilder.Entity<VwRxClaimsDiagnosis>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("Vw_RX_Claims_Diagnosis");

            entity.Property(e => e.BuildStatus).HasColumnName("Build_status");
            entity.Property(e => e.DiseaseCode)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("disease_code");
            entity.Property(e => e.DiseaseId).HasColumnName("DiseaseID");
            entity.Property(e => e.ProcessClaimNo)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("process_claim_no");
            entity.Property(e => e.RowId).HasColumnName("RowID");
        });

        modelBuilder.Entity<VwServiceProvider>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwServiceProviders");

            entity.Property(e => e.AccountName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.AccountNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.AceeptTpa).HasColumnName("AceeptTPA");
            entity.Property(e => e.Bank)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.BankBranchName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.BankId).HasColumnName("BankID");
            entity.Property(e => e.BranchName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Ceoemail)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("CEOEmail");
            entity.Property(e => e.Ceoname)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("CEOName");
            entity.Property(e => e.Ceophone)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("CEOphone");
            entity.Property(e => e.ClaimsEmail)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ClaimsName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Community)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.CommunityId).HasColumnName("CommunityID");
            entity.Property(e => e.DigitalAddress)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.DocIdOnlineVetting).HasColumnName("DocID_OnlineVetting");
            entity.Property(e => e.Doctor).HasMaxLength(50);
            entity.Property(e => e.Email)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.FaxNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.FinEmail)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.GroupLocation).HasMaxLength(50);
            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.MobNum)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.OwnerTypeId).HasColumnName("OwnerTypeID");
            entity.Property(e => e.Ownership)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PaymentContactName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PaymentContactNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PostalAddress)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.PspMarkUp)
                .HasColumnType("decimal(18, 2)")
                .HasColumnName("PSP_MarkUp");
            entity.Property(e => e.Region)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.RegionId).HasColumnName("RegionID");
            entity.Property(e => e.RegistrationNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.RmEmail)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("RM_Email");
            entity.Property(e => e.RmMob)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("RM_Mob");
            entity.Property(e => e.RmName)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("RM_Name");
            entity.Property(e => e.RmOtherPhone)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("RM_OtherPhone");
            entity.Property(e => e.RxMasterProviderId).HasColumnName("RX_Master_ProviderID");
            entity.Property(e => e.Service)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ServiceProvider)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ServiceProviderStatus).HasMaxLength(50);
            entity.Property(e => e.ServiceType)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ServiceTypeId).HasColumnName("ServiceTypeID");
            entity.Property(e => e.StatusId).HasColumnName("StatusID");
            entity.Property(e => e.StreetLocation)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.TelNum)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<VwServiceProviderBenefitParent>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwServiceProvider_BenefitParent");

            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.EffectiveDate).HasColumnType("datetime");
            entity.Property(e => e.EndDate).HasColumnType("datetime");
            entity.Property(e => e.ParentBenefitId).HasColumnName("ParentBenefitID");
            entity.Property(e => e.ParentName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.RowId).HasColumnName("RowID");
            entity.Property(e => e.ServiceProviderId).HasColumnName("ServiceProviderID");
        });

        modelBuilder.Entity<VwServiceProviderXPlan>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwServiceProvider_X_Plans");

            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.EffectiveDate).HasColumnType("datetime");
            entity.Property(e => e.EndDate).HasColumnType("datetime");
            entity.Property(e => e.PlanId).HasColumnName("PlanID");
            entity.Property(e => e.PlanName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.RowId).HasColumnName("RowID");
            entity.Property(e => e.ServiceProvider)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ServiceProviderId).HasColumnName("ServiceProviderID");
        });

        modelBuilder.Entity<VwServiceProviderXService>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwServiceProvider_X_Services");

            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.EffectiveDate).HasColumnType("datetime");
            entity.Property(e => e.EndDate).HasColumnType("datetime");
            entity.Property(e => e.RowId).HasColumnName("RowID");
            entity.Property(e => e.ServiceClassRowId).HasColumnName("ServiceClass_RowID");
            entity.Property(e => e.ServiceId).HasColumnName("ServiceID");
            entity.Property(e => e.ServiceName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ServiceProvider)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ServiceProviderId).HasColumnName("ServiceProviderID");
        });

        modelBuilder.Entity<VwServiceProviderXTariffXPrice>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("Vw_ServiceProvider_X_Tariff_X_Prices");

            entity.Property(e => e.CreatedBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.EffectiveDate).HasColumnType("datetime");
            entity.Property(e => e.EndDate).HasColumnType("datetime");
            entity.Property(e => e.RowId).HasColumnName("RowID");
            entity.Property(e => e.ServiceProviderId).HasColumnName("ServiceProviderID");
            entity.Property(e => e.TariffId).HasColumnName("TariffID");
            entity.Property(e => e.TariffName)
                .HasMaxLength(5000)
                .IsUnicode(false);
            entity.Property(e => e.UnitCost).HasColumnType("decimal(18, 2)");
        });

        modelBuilder.Entity<VwServiceProvidersVettingDoctor>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwServiceProviders_VettingDoctors");

            entity.Property(e => e.DocIdOnlineVetting).HasColumnName("DocID_OnlineVetting");
            entity.Property(e => e.Doctor)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.ServiceProvider)
                .HasMaxLength(100)
                .IsUnicode(false);
        });

        modelBuilder.Entity<VwSettlementLetter>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwSettlementLetter");

            entity.Property(e => e.AmountClaimed).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Awarded).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Bank)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ChequeAmount).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ChequeNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ClaimsMonth).HasMaxLength(35);
            entity.Property(e => e.DateOfClaim).HasColumnType("datetime");
            entity.Property(e => e.Fullname)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.Service)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ServiceProvider)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.SignaturePath)
                .HasMaxLength(200)
                .IsUnicode(false);
            entity.Property(e => e.WithHoldingRate)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Withold).HasColumnType("decimal(18, 2)");
        });

        modelBuilder.Entity<VwTariff>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwTariff");

            entity.Property(e => e.Benefit)
                .HasMaxLength(200)
                .IsUnicode(false);
            entity.Property(e => e.DrugGenId).HasColumnName("DrugGenID");
            entity.Property(e => e.InOutPatient).HasColumnName("In_OutPatient");
            entity.Property(e => e.LabGroupId).HasColumnName("LabGroupID");
            entity.Property(e => e.MedClassId).HasColumnName("MedClassID");
            entity.Property(e => e.OpticalServicesTypeId).HasColumnName("OpticalServicesTypeID");
            entity.Property(e => e.ServiceId).HasColumnName("ServiceID");
            entity.Property(e => e.ServiceName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.TariffCode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.TariffId).HasColumnName("TariffID");
            entity.Property(e => e.TariffName)
                .HasMaxLength(5000)
                .IsUnicode(false);
        });

        modelBuilder.Entity<VwTariffDrugsGeneric>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwTariff_DrugsGeneric");

            entity.Property(e => e.DrugClassId).HasColumnName("DrugClassID");
            entity.Property(e => e.DrugGenId).HasColumnName("DrugGenID");
            entity.Property(e => e.InOutPatient).HasColumnName("In_OutPatient");
            entity.Property(e => e.ServiceId).HasColumnName("ServiceID");
            entity.Property(e => e.ServiceName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.TariffCode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.TariffName)
                .HasMaxLength(5000)
                .IsUnicode(false);
        });

        modelBuilder.Entity<VwTariffDrugsProprietary>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwTariff_DrugsProprietary");

            entity.Property(e => e.DrugGenId).HasColumnName("DrugGenID");
            entity.Property(e => e.GenericName)
                .HasMaxLength(5000)
                .IsUnicode(false);
            entity.Property(e => e.InOutPatient).HasColumnName("In_OutPatient");
            entity.Property(e => e.LabGroupId).HasColumnName("LabGroupID");
            entity.Property(e => e.MedClassId).HasColumnName("MedClassID");
            entity.Property(e => e.OpticalServicesTypeId).HasColumnName("OpticalServicesTypeID");
            entity.Property(e => e.ServiceId).HasColumnName("ServiceID");
            entity.Property(e => e.ServiceName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Status).HasColumnName("STATUS");
            entity.Property(e => e.TariffCode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.TariffId).HasColumnName("TariffID");
            entity.Property(e => e.TariffName)
                .HasMaxLength(5000)
                .IsUnicode(false);
        });

        modelBuilder.Entity<VwTariffXPricesDrugsMobimed>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("Vw_Tariff_X_Prices_Drugs_Mobimed");

            entity.Property(e => e.EffectiveDate).HasColumnType("datetime");
            entity.Property(e => e.EndDate).HasColumnType("datetime");
            entity.Property(e => e.TariffId).HasColumnName("TariffID");
        });

        modelBuilder.Entity<VwTariffXPricesDrugsNew>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("Vw_Tariff_X_Prices_Drugs_new");

            entity.Property(e => e.DrugId).HasColumnName("DrugID");
            entity.Property(e => e.EffectiveDate).HasColumnType("datetime");
            entity.Property(e => e.EndDate).HasColumnType("datetime");
            entity.Property(e => e.TariffBasePrice).HasColumnName("Tariff_Base_Price");
            entity.Property(e => e.TariffId).HasColumnName("TariffID");
        });

        modelBuilder.Entity<VwUtiliazationMyHealthDetail>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vwUtiliazation_MyHealth_Detail");

            entity.Property(e => e.InOutId).HasColumnName("InOutID");
            entity.Property(e => e.MyHealthPrincipalId).HasColumnName("MyHealth_PrincipalID");
            entity.Property(e => e.SysAmountClaimed).HasColumnType("decimal(38, 2)");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
