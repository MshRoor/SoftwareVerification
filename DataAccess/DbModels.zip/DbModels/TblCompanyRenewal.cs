﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblCompanyRenewal
{
    public int Id { get; set; }

    public int CompanyId { get; set; }

    public string PolicyCode { get; set; } = null!;

    public DateTime PolicyStartDate { get; set; }

    public DateTime PolicyEndDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? CreatedDate { get; set; }

    public bool? ActuarialApproved { get; set; }

    public string? ActuarialApprovedBy { get; set; }

    public DateTime? ActuarialApprovedDate { get; set; }

    public bool? Approved { get; set; }

    public string? ApprovedBy { get; set; }

    public DateTime? ApprovedDate { get; set; }

    public string? UpdatedBy { get; set; }

    public DateTime? UpdatedDate { get; set; }
}
