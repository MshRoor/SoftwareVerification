﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblTariffXRejectionCommentOnline
{
    public int TariffXRejectionCommentId { get; set; }

    public string TariffXRejectionComments { get; set; } = null!;
}
