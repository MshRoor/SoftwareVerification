﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class MedifemItem
{
    public string? InsItemCode { get; set; }

    public string? Item { get; set; }
}
