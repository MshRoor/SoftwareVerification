﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblCommunity
{
    public int Id { get; set; }

    public string? Community { get; set; }
}
