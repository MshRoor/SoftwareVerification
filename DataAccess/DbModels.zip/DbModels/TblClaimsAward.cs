﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblClaimsAward
{
    public int Id { get; set; }

    public int BatchNo { get; set; }

    public decimal? Claimed { get; set; }

    public decimal? SysAward { get; set; }

    public decimal? Awarded { get; set; }

    public decimal? Withold { get; set; }

    public decimal? Building { get; set; }

    public decimal? AmountDue { get; set; }

    public DateTime? AwardDate { get; set; }

    public string? Comment { get; set; }

    public string? AmountWord { get; set; }

    public int? Status { get; set; }

    public string? WithHoldingRate { get; set; }

    public virtual TblClaimsBatch BatchNoNavigation { get; set; } = null!;
}
