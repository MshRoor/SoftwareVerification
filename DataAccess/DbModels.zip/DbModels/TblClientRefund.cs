﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblClientRefund
{
    public int Id { get; set; }

    public int? CompanyId { get; set; }

    public string? MemberName { get; set; }

    public int? BatchNo { get; set; }

    public DateTime? SubmissionDate { get; set; }

    public double? AmountClaimed { get; set; }

    public string? PaymentMode { get; set; }

    public string? Status { get; set; }

    public string? Outcome { get; set; }

    public string? OutcomeReason { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }
}
