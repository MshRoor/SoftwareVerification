﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblCompanySalesComment
{
    public int Id { get; set; }

    public string Comment { get; set; } = null!;

    public int? DepartmentId { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? CreatedDate { get; set; }
}
