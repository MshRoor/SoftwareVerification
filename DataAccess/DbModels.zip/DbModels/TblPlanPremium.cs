﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblPlanPremium
{
    public int Id { get; set; }

    public int PlanId { get; set; }

    public decimal? Premium { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? CreatedDate { get; set; }
}
