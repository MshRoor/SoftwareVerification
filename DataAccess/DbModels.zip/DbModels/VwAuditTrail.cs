﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwAuditTrail
{
    public int Id { get; set; }

    public int ActionBy { get; set; }

    public string? Username { get; set; }

    public DateTime ActionDate { get; set; }

    public string ActionDescription { get; set; } = null!;

    public string? ActionId { get; set; }
}
