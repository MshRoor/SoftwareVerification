﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblBenefitCustomType
{
    public int Id { get; set; }

    public string CustomType { get; set; } = null!;
}
