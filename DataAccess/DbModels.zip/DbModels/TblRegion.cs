﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblRegion
{
    public int Id { get; set; }

    public string Region { get; set; } = null!;

    public string? RegionCode { get; set; }
}
