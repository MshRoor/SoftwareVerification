﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblServiceProvidersRefund
{
    public int Id { get; set; }

    public string? ServiceProvider { get; set; }

    public int? HspId { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? CreatedDate { get; set; }

    public virtual ICollection<TblRefundsPrescription> TblRefundsPrescriptions { get; set; } = new List<TblRefundsPrescription>();

    public virtual ICollection<TblRefundsReceipt> TblRefundsReceipts { get; set; } = new List<TblRefundsReceipt>();
}
