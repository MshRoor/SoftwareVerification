﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblBenefit
{
    public int Id { get; set; }

    public string Benefit { get; set; } = null!;

    public int BenefitGroupId { get; set; }

    public int? BenefitParentId { get; set; }

    public int? RxBenefitId { get; set; }

    public virtual TblBenefitGroup BenefitGroup { get; set; } = null!;

    public virtual TblBenefitParent? BenefitParent { get; set; }

    public virtual ICollection<TblBenefitXTariff> TblBenefitXTariffs { get; set; } = new List<TblBenefitXTariff>();

    public virtual ICollection<TblPlanBenefitLimit> TblPlanBenefitLimits { get; set; } = new List<TblPlanBenefitLimit>();
}
