﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwClaimsBatchRefund
{
    public int? ServiceProviderId { get; set; }

    public int BatchNo { get; set; }

    public DateTime? DateStamp { get; set; }

    public int? MemberId { get; set; }

    public int? NoOfClaims { get; set; }

    public decimal? AmountClaimed { get; set; }

    public decimal? AmountAwarded { get; set; }

    public DateTime? PeriodFrom { get; set; }

    public DateTime? PeriodTo { get; set; }

    public DateTime? StartEntryDate { get; set; }

    public DateTime? CompletedEntryDate { get; set; }

    public DateTime? DateOfClaim { get; set; }

    public int? BatchedBy { get; set; }

    public int? Sms { get; set; }

    public int? StatusId { get; set; }

    public string Status { get; set; } = null!;

    public decimal? SystemClaim { get; set; }

    public decimal? SystemAward { get; set; }

    public decimal? ProviderClaimed { get; set; }

    public decimal? ConfirmAward { get; set; }

    public int? TypeOfBatching { get; set; }

    public int? Tpa { get; set; }

    public int? NoOfFiles { get; set; }

    public string? SubmittedBy { get; set; }

    public string? ContactNo { get; set; }

    public int? PaymentModeId { get; set; }

    public string PaymentMode { get; set; } = null!;

    public string? MoMoNumber { get; set; }

    public string MembershipNo { get; set; } = null!;

    public string? FullName { get; set; }

    public int? CompanyId { get; set; }

    public string CompanyName { get; set; } = null!;

    public string? Username { get; set; }

    public string? Gender { get; set; }

    public string? Relationship { get; set; }

    public string? Mphone { get; set; }

    public string? ChequeNo { get; set; }

    public DateTime? ChequeDate { get; set; }

    public decimal? ChequeAmount { get; set; }

    public string? Bank { get; set; }

    public DateOnly? Dob { get; set; }

    public string PrinceMemberNo { get; set; } = null!;

    public string? PrincipalName { get; set; }

    public int? BankId { get; set; }

    public string? ModeOfSubmission { get; set; }

    public string PlanName { get; set; } = null!;

    public string? Email { get; set; }

    public string? FirstName { get; set; }

    public string? ContactPersonEmail { get; set; }

    public string? PrincipalEmail { get; set; }
}
