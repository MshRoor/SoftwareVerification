﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VspClaimsHeader
{
    public int Id { get; set; }

    public string ClaimsNo { get; set; } = null!;

    public DateTime DateofAttendance { get; set; }

    public int MemberId { get; set; }

    public string MembershipNo { get; set; } = null!;

    public string? FullName { get; set; }

    public DateOnly? Dob { get; set; }

    public string? Mphone { get; set; }

    public int? AttendMonth { get; set; }

    public int? AttendYear { get; set; }

    public string? Inout { get; set; }

    public string? TypeOfVisit { get; set; }

    public DateTime? StampDate { get; set; }

    public decimal? ProviderAmountClaimed { get; set; }

    public int? NmhProviderId { get; set; }

    public string ServiceProvider { get; set; } = null!;

    public int? BenefitOption { get; set; }

    public string? Diagnosis { get; set; }

    public int? CompanyId { get; set; }

    public int? InOutId { get; set; }

    public int? StatusId { get; set; }

    public string Status { get; set; } = null!;
}
