﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwPlan
{
    public int Id { get; set; }

    public string PlanName { get; set; } = null!;

    public string? Prefix { get; set; }

    public decimal? Premium { get; set; }

    public bool? Active { get; set; }

    public bool? IsFamily { get; set; }

    public int? MainPlanId { get; set; }

    public string? MainPlanName { get; set; }
}
