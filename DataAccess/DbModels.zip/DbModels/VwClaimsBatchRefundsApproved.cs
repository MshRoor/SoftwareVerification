﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwClaimsBatchRefundsApproved
{
    public int? ServiceProviderId { get; set; }

    public int Id { get; set; }

    public int ClaimsBatchNo { get; set; }

    public DateTime? DateStamp { get; set; }

    public int? MemberId { get; set; }

    public int? NoOfClaims { get; set; }

    public decimal? SysAmountClaimed { get; set; }

    public decimal? SysAmountAwarded { get; set; }

    public decimal? Rejection { get; set; }

    public DateTime? DateOfClaim { get; set; }

    public int? BatchedBy { get; set; }

    public int? StatusId { get; set; }

    public string PaymentMode { get; set; } = null!;

    public string? MoMoNumber { get; set; }

    public string MemberNo { get; set; } = null!;

    public string? FullName { get; set; }

    public int? CompanyId { get; set; }

    public string? PrincipalName { get; set; }

    public string PrinceMemberNo { get; set; } = null!;

    public int? PrincipalId { get; set; }

    public string? CompanyName { get; set; }
}
