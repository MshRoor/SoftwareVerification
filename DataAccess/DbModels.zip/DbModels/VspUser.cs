﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VspUser
{
    public int Id { get; set; }

    public string Username { get; set; } = null!;

    public string Fullname { get; set; } = null!;

    public string? ContactNo { get; set; }

    public string? Email { get; set; }

    public string? AccountType { get; set; }

    public string ProviderId { get; set; } = null!;

    public bool Active { get; set; }

    public int? BaseProviderId { get; set; }

    public byte[] UserPassword { get; set; } = null!;

    public string Userroles { get; set; } = null!;

    public string? Gender { get; set; }
}
