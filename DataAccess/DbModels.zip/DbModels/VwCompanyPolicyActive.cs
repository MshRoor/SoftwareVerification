﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwCompanyPolicyActive
{
    public int Id { get; set; }

    public string PolicyCode { get; set; } = null!;

    public int CompanyId { get; set; }

    public DateTime? PolicyStartDate { get; set; }

    public DateTime? PolicyEndDate { get; set; }

    public DateTime? TerminatedDate { get; set; }

    public bool? PolicyActive { get; set; }

    public string CompanyName { get; set; } = null!;

    public string ExpiryType { get; set; } = null!;

    public bool? IsGroupPolicy { get; set; }

    public bool? PolicyStarted { get; set; }

    public DateTime? StartedDate { get; set; }

    public string? StartedBy { get; set; }

    public bool? Customized { get; set; }

    public bool? UpdatedOnline { get; set; }
}
