﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblRefundsApprovedRejection
{
    public int AutoId { get; set; }

    public int Id { get; set; }

    public string ClaimsBatchNo { get; set; } = null!;

    public string? MemberNo { get; set; }

    public string? FullName { get; set; }

    public int? PrincipalId { get; set; }

    public string? PrinceMemberNo { get; set; }

    public string? PrincipalName { get; set; }

    public int? CompanyId { get; set; }

    public string? Company { get; set; }

    public DateTime? DateOfClaim { get; set; }

    public decimal? SysAmountClaimed { get; set; }

    public decimal? SysAmountAwarded { get; set; }

    public decimal? Rejection { get; set; }

    public string? PaymentMode { get; set; }

    public string? MoMoNumber { get; set; }

    public string? MoMoName { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public string? ReferenceClaimNo { get; set; }

    public bool? OnlinePush { get; set; }
}
