﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblClaimsBatch
{
    public int Id { get; set; }

    public DateTime? DateStamp { get; set; }

    public int? ServiceProviderId { get; set; }

    public int? MemberId { get; set; }

    public int? NoOfClaims { get; set; }

    public decimal? AmountClaimed { get; set; }

    public decimal? AmountAwarded { get; set; }

    public DateTime? PeriodFrom { get; set; }

    public DateTime? PeriodTo { get; set; }

    public DateTime? StartEntryDate { get; set; }

    public DateTime? CompletedEntryDate { get; set; }

    public DateTime? DateOfClaim { get; set; }

    public int? EntryUserId { get; set; }

    public int? BatchedBy { get; set; }

    public int? Sms { get; set; }

    public int? StatusId { get; set; }

    public decimal? SystemClaim { get; set; }

    public decimal? SystemAward { get; set; }

    public decimal? ProviderClaimed { get; set; }

    public int? CommentId { get; set; }

    public decimal? WithHolding { get; set; }

    public decimal? OtherDeduction { get; set; }

    public decimal? ConfirmAward { get; set; }

    public int? TypeOfBatching { get; set; }

    public int? Tpa { get; set; }

    public int? NoOfFiles { get; set; }

    public string? SubmittedBy { get; set; }

    public string? ContactNo { get; set; }

    public int? PaymentModeId { get; set; }

    public string? MoMoNumber { get; set; }

    public string? Comment { get; set; }

    public string? ModeOfSubmission { get; set; }

    public virtual ICollection<TblClaimsAward> TblClaimsAwards { get; set; } = new List<TblClaimsAward>();

    public virtual ICollection<TblClaimsBatchStatusInfo> TblClaimsBatchStatusInfos { get; set; } = new List<TblClaimsBatchStatusInfo>();

    public virtual ICollection<TblClaimsHeader> TblClaimsHeaders { get; set; } = new List<TblClaimsHeader>();

    public virtual ICollection<TblClaimsPayment> TblClaimsPayments { get; set; } = new List<TblClaimsPayment>();

    public virtual ICollection<TblRefundsReceipt> TblRefundsReceipts { get; set; } = new List<TblRefundsReceipt>();
}
