﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwCompaniesSummary
{
    public int? CompanyId { get; set; }

    public string? CompanyName { get; set; }

    public int? CoCare { get; set; }

    public int? ExecoCare { get; set; }

    public int? Standard { get; set; }

    public int? Essential { get; set; }

    public int? Executive { get; set; }

    public int? Premier { get; set; }

    public int? PremierLister { get; set; }

    public int? PremierPlus { get; set; }

    public int? Privilege { get; set; }

    public int? International { get; set; }

    public DateTime? BusinessDate { get; set; }

    public DateTime? PolicyStartDate { get; set; }

    public DateTime? PolicyEndDate { get; set; }

    public string? ContactPerson { get; set; }

    public string? Telephone1 { get; set; }

    public string? Email { get; set; }

    public string? PostalAddress { get; set; }

    public string? NatureOfBusiness { get; set; }
}
