﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblClaimsDetailsXTariffRejection
{
    public int RowId { get; set; }

    public string ClaimsNo { get; set; } = null!;

    public int TariffId { get; set; }

    public int TariffXRejectionCommentId { get; set; }

    public bool? RejectionAccepted { get; set; }

    public DateTime? StampDate { get; set; }

    public int? UserId { get; set; }

    public bool? Confirmed { get; set; }

    public decimal? RejectedAmount { get; set; }

    public int? ClaimsDetailsId { get; set; }

    public int? RxRowId { get; set; }

    public int? OnlineStatus { get; set; }

    public virtual TblClaimsDetail? ClaimsDetails { get; set; }
}
