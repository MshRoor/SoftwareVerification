﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwClaimsRecievedHsp
{
    public int BatchNo { get; set; }

    public int? ServiceProviderId { get; set; }

    public string ServiceProvider { get; set; } = null!;

    public int? NoOfClaims { get; set; }

    public decimal? AmountClaimed { get; set; }

    public DateTime? DateOfClaim { get; set; }

    public int? StatusId { get; set; }

    public string? CustomerId { get; set; }

    public int? Tpa { get; set; }

    public string BatchType { get; set; } = null!;

    public int? TypeOfBatching { get; set; }

    public string? MonthOfClaim { get; set; }
}
