﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwServiceProviderXService
{
    public int RowId { get; set; }

    public int? ServiceProviderId { get; set; }

    public string ServiceProvider { get; set; } = null!;

    public int? ServiceClassRowId { get; set; }

    public int? ServiceId { get; set; }

    public string? ServiceName { get; set; }

    public DateTime? EffectiveDate { get; set; }

    public DateTime EndDate { get; set; }

    public int? Status { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }
}
