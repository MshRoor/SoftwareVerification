﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwServiceProvidersVettingDoctor
{
    public int Id { get; set; }

    public string ServiceProvider { get; set; } = null!;

    public int DocIdOnlineVetting { get; set; }

    public string? Doctor { get; set; }
}
