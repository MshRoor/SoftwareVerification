﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblMonthlyUsageMobileApp
{
    public int Id { get; set; }

    public string? MobileApp { get; set; }

    public int? UsageMonth { get; set; }

    public int? UsageYear { get; set; }

    public string? UsagePeriod { get; set; }

    public int? Downloads { get; set; }

    public int? Usage { get; set; }

    public string? Traffic { get; set; }

    public string? Remarks { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }
}
