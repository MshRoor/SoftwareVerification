﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblClaimsAvailableDental
{
    public int Id { get; set; }

    public int? ClaimsBatchNo { get; set; }

    public string ClaimsNo { get; set; } = null!;

    public DateTime? DateofAttendance { get; set; }

    public int? NmhProviderId { get; set; }

    public string? ServiceProvider { get; set; }

    public int? ProviderId { get; set; }

    public string? FacilityName { get; set; }

    public string? Diagnosis { get; set; }

    public string? EyeOptical { get; set; }

    public string? Toothnos { get; set; }

    public string? TypeOfVisit { get; set; }

    public string? Item { get; set; }

    public string? MemberNo { get; set; }

    public string? FullName { get; set; }

    public string? Gender { get; set; }

    public string? BenefitOption { get; set; }

    public string? Company { get; set; }

    public string? MemberAge { get; set; }

    public int? ClaimDetailsId { get; set; }

    public int RowId { get; set; }

    public int? DocId { get; set; }

    public string? DocResponse { get; set; }

    public string? DocComment { get; set; }

    public bool? Vetted { get; set; }

    public bool? OnlinePush { get; set; }

    public bool? NmhPull { get; set; }

    public DateTime? DatePushed { get; set; }
}
