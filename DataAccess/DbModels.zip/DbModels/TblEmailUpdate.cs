﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblEmailUpdate
{
    public int RowId { get; set; }

    public int? RowIdOnline { get; set; }

    public int? MemberId { get; set; }

    public string? NewEmail { get; set; }

    public string? OtherEmail { get; set; }

    public int? IsUpdate { get; set; }

    public DateTime? DateStamp { get; set; }
}
