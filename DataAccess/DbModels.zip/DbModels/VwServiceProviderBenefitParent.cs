﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwServiceProviderBenefitParent
{
    public int RowId { get; set; }

    public int ServiceProviderId { get; set; }

    public int ParentBenefitId { get; set; }

    public string ParentName { get; set; } = null!;

    public DateTime EffectiveDate { get; set; }

    public DateTime? EndDate { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }
}
