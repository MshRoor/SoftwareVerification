﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblNatureOfBusiness
{
    public int Id { get; set; }

    public string NatureOfBusiness { get; set; } = null!;
}
