﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblPaymentMode
{
    public int PaymentModeId { get; set; }

    public string PaymentMode { get; set; } = null!;
}
