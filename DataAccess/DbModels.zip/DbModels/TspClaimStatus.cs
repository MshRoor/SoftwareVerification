﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TspClaimStatus
{
    public int Id { get; set; }

    public string Status { get; set; } = null!;

    public virtual ICollection<TspClaimStatusInfo> TspClaimStatusInfos { get; set; } = new List<TspClaimStatusInfo>();
}
