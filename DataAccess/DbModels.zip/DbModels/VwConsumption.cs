﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwConsumption
{
    public string? ServiceProvider { get; set; }

    public string? TypeName { get; set; }

    public decimal? Claimed { get; set; }

    public decimal? Awarded { get; set; }

    public string? Inout { get; set; }

    public string ClaimsNo { get; set; } = null!;

    public string? BenefitOption { get; set; }

    public string? MemberType { get; set; }

    public string? ServiceType { get; set; }

    public string? Service { get; set; }

    public DateTime DateofAttendance { get; set; }

    public string? Fullname { get; set; }

    public string? Gender { get; set; }

    public DateOnly? Dob { get; set; }

    public string? CompanyName { get; set; }

    public string? Relationship { get; set; }

    public int ClaimsDetailsId { get; set; }

    public int? CompanyId { get; set; }
}
