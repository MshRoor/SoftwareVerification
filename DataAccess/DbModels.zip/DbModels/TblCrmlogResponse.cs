﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblCrmlogResponse
{
    public int Id { get; set; }

    public int TicketId { get; set; }

    public string Comment { get; set; } = null!;

    public string? CreatedBy { get; set; }

    public DateTime? CreatedDate { get; set; }

    public bool? FollowUp { get; set; }
}
