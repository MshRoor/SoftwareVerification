﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwServiceProvider
{
    public int Id { get; set; }

    public string ServiceProvider { get; set; } = null!;

    public string? Doctor { get; set; }

    public string? PostalAddress { get; set; }

    public string? TelNum { get; set; }

    public string? GroupLocation { get; set; }

    public string? StreetLocation { get; set; }

    public int? RegionId { get; set; }

    public string? Region { get; set; }

    public int? Tax { get; set; }

    public string? Email { get; set; }

    public int? ServiceTypeId { get; set; }

    public string? ServiceType { get; set; }

    public string? MobNum { get; set; }

    public bool? BuildingFund { get; set; }

    public bool? WitholdingTax { get; set; }

    public string? RegistrationNo { get; set; }

    public int? CommunityId { get; set; }

    public string? Community { get; set; }

    public int? OwnerTypeId { get; set; }

    public string? Ownership { get; set; }

    public string? FaxNo { get; set; }

    public string? AccountName { get; set; }

    public int? BankId { get; set; }

    public string? Bank { get; set; }

    public int? BankBranchId { get; set; }

    public string? BankBranchName { get; set; }

    public string? BranchName { get; set; }

    public string? AccountNo { get; set; }

    public string? PaymentContactNo { get; set; }

    public string? PaymentContactName { get; set; }

    public int? RxMasterProviderId { get; set; }

    public string? RmName { get; set; }

    public string? RmEmail { get; set; }

    public string? RmMob { get; set; }

    public string? RmOtherPhone { get; set; }

    public int DocIdOnlineVetting { get; set; }

    public int? AceeptTpa { get; set; }

    public bool? StatusId { get; set; }

    public decimal? PspMarkUp { get; set; }

    public string? ClaimsName { get; set; }

    public string? ClaimsEmail { get; set; }

    public string? DigitalAddress { get; set; }

    public string? Ceoname { get; set; }

    public string? Ceoemail { get; set; }

    public string? Ceophone { get; set; }

    public string? FinEmail { get; set; }

    public string? Service { get; set; }

    public string? ServiceProviderStatus { get; set; }
}
