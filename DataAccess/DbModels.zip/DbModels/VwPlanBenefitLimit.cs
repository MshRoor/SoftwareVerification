﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwPlanBenefitLimit
{
    public int RowId { get; set; }

    public int PlanId { get; set; }

    public string PlanName { get; set; } = null!;

    public int BenefitId { get; set; }

    public string Benefit { get; set; } = null!;

    public int BenefitGroupId { get; set; }

    public string BenefitGroup { get; set; } = null!;

    public string? CoverStatus { get; set; }

    public decimal? CoverLimit { get; set; }

    public string? CoverComment { get; set; }
}
