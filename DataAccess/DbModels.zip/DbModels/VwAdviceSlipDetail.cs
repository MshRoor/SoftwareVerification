﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwAdviceSlipDetail
{
    public int RowId { get; set; }

    public string ClaimsNo { get; set; } = null!;

    public int TariffId { get; set; }

    public double? Qty { get; set; }

    public double? QtyPrescribed { get; set; }

    public decimal? Claimed { get; set; }

    public decimal? Awarded { get; set; }

    public decimal? ApprovedAmount { get; set; }

    public int? RxRowId { get; set; }

    public decimal? UnitPrice { get; set; }

    public string? TariffName { get; set; }

    public int TariffXRejectionCommentId { get; set; }

    public string? TariffXRejectionComments { get; set; }

    public bool? RejectionAccepted { get; set; }

    public DateTime? StampDate { get; set; }

    public int? UserId { get; set; }

    public bool? Confirmed { get; set; }

    public decimal? RejectedAmount { get; set; }

    public int? ClaimsDetailsId { get; set; }

    public int? OnlineStatus { get; set; }

    public int? CommentLocation { get; set; }

    public int? ClaimsBatchNo { get; set; }

    public int? NmhProviderId { get; set; }

    public int? AttendMonth { get; set; }

    public int? AttendYear { get; set; }

    public int? Tpa { get; set; }

    public int MemberId { get; set; }
}
