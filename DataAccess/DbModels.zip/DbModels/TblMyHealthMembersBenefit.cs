﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblMyHealthMembersBenefit
{
    public int RowId { get; set; }

    public int? MyHealthPrincipalId { get; set; }

    public decimal? OpdLimit { get; set; }

    public decimal? IpLimit { get; set; }

    public int? PushStatus { get; set; }

    public DateOnly? StartDate { get; set; }

    public DateOnly? ExpiryDate { get; set; }

    public DateOnly? DateStamp { get; set; }
}
