﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblClaimsHeader
{
    public int Id { get; set; }

    public DateTime DateofAttendance { get; set; }

    public string ClaimsNo { get; set; } = null!;

    public int MemberId { get; set; }

    public int? ClaimsBatchNo { get; set; }

    public DateTime? DateStamp { get; set; }

    public int? AttendDay { get; set; }

    public int? AttendMonth { get; set; }

    public int? AttendYear { get; set; }

    public DateTime? Attend { get; set; }

    public int? UserId { get; set; }

    public int? InOutId { get; set; }

    public DateTime? StampDate { get; set; }

    public int? BenefitOption { get; set; }

    public decimal? ProviderAmountClaimed { get; set; }

    public decimal? SysAmountClaimed { get; set; }

    public decimal? SysAmountAwarded { get; set; }

    public string? NotAMember { get; set; }

    public int? HeaderComemntId { get; set; }

    public DateOnly? AdminisionDate { get; set; }

    public DateOnly? DischargeDate { get; set; }

    public bool? Rejucted { get; set; }

    public int? ClaimsHeaderStatus { get; set; }

    public int? PolicyCodeId { get; set; }

    public string? Comments { get; set; }

    public int? Released { get; set; }

    public int? RxProviderId { get; set; }

    public int? RxMasterProviderId { get; set; }

    public string? RxProviderName { get; set; }

    public int? NmhProviderId { get; set; }

    public int? ClaimType { get; set; }

    public int? PrescriptionAvaliable { get; set; }

    public int? Tpa { get; set; }

    public string? ChequeNo { get; set; }

    public decimal? ChequeAmount { get; set; }

    public int? RefunPayStatus { get; set; }

    public decimal? ReviewAwarded { get; set; }

    public decimal? TotalAwarded { get; set; }

    public decimal? RejectedAmount { get; set; }

    public int? RefundBank { get; set; }

    public int? PaymentModeId { get; set; }

    public string? MoMoNumber { get; set; }

    public string? MoMoName { get; set; }

    public int? RefundSmsSent { get; set; }

    public bool? Vetted { get; set; }

    public int? VettedBy { get; set; }

    public DateTime? VettedDate { get; set; }

    public string? ProviderComment { get; set; }

    public virtual TblClaimsBatch? ClaimsBatchNoNavigation { get; set; }

    public virtual ICollection<TblClaimForm> TblClaimForms { get; set; } = new List<TblClaimForm>();

    public virtual ICollection<TblClaimsDetail> TblClaimsDetails { get; set; } = new List<TblClaimsDetail>();

    public virtual ICollection<TblClaimsDetailsReIssue> TblClaimsDetailsReIssues { get; set; } = new List<TblClaimsDetailsReIssue>();

    public virtual TblClaimsDiagnosisTem? TblClaimsDiagnosisTem { get; set; }

    public virtual ICollection<TblClaimsHeaderXDisease> TblClaimsHeaderXDiseases { get; set; } = new List<TblClaimsHeaderXDisease>();
}
