﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwDentalClaimsDetail
{
    public int? ClaimsBatchNo { get; set; }

    public string ClaimsNo { get; set; } = null!;

    public DateTime DateofAttendance { get; set; }

    public int? NmhProviderId { get; set; }

    public string ServiceProvider { get; set; } = null!;

    public int? ProviderId { get; set; }

    public string? Diagnosis { get; set; }

    public string? EyeOptical { get; set; }

    public string? Toothnos { get; set; }

    public string? TypeOfVisit { get; set; }

    public string? Item { get; set; }

    public string? MemberNo { get; set; }

    public string? FullName { get; set; }

    public string? Gender { get; set; }

    public string? PlanName { get; set; }

    public string? CompanyName { get; set; }

    public string? MemberAge { get; set; }

    public int RowId { get; set; }

    public int? ClaimDetailsId { get; set; }
}
