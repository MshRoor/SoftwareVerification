﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwProformaInvoiceSigned
{
    public string InvoiceNo { get; set; } = null!;

    public DateTime InvoiceDate { get; set; }

    public int CustomerId { get; set; }

    public string CustomerName { get; set; } = null!;

    public string? CustomerAddress { get; set; }

    public string? CustomerState { get; set; }

    public string? CustomerPhone { get; set; }

    public string? CustomerAttn { get; set; }

    public string? SourceOfBusiness { get; set; }

    public string BrokerName { get; set; } = null!;

    public string? ContactNo { get; set; }

    public int? CoverPeriod { get; set; }

    public string? PreparedBy { get; set; }

    public string? AuthorizedBy { get; set; }

    public int ProformaProductId { get; set; }

    public string Description { get; set; } = null!;

    public int? Quantity { get; set; }

    public double? UnitPrice { get; set; }

    public double? Amount { get; set; }

    public string? BrokerContactPerson { get; set; }

    public string? BrokerContactNo { get; set; }

    public string? PrepareSignPath { get; set; }
}
