﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblCallReason
{
    public int Id { get; set; }

    public string CallReason { get; set; } = null!;

    public int ServiceTypeId { get; set; }

    public string? Priority { get; set; }
}
