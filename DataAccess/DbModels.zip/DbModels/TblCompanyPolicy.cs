﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblCompanyPolicy
{
    public int Id { get; set; }

    public int CompanyId { get; set; }

    public string PolicyCode { get; set; } = null!;

    public DateTime? PolicyStartDate { get; set; }

    public DateTime? PolicyEndDate { get; set; }

    public bool? PolicyActive { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? UpdatedDate { get; set; }

    public string? UpdatedBy { get; set; }

    public bool? Terminated { get; set; }

    public DateTime? TerminatedDate { get; set; }

    public string? TerminatedBy { get; set; }

    public bool? PolicyStarted { get; set; }

    public DateTime? StartedDate { get; set; }

    public string? StartedBy { get; set; }

    public bool? Customized { get; set; }

    public bool? UpdatedOnline { get; set; }
}
