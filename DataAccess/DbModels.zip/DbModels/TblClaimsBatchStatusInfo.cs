﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblClaimsBatchStatusInfo
{
    public int Id { get; set; }

    public int BatchNo { get; set; }

    public int StatusId { get; set; }

    public int? UserId { get; set; }

    public DateTime? DateStamp { get; set; }

    public virtual TblClaimsBatch BatchNoNavigation { get; set; } = null!;

    public virtual TblClaimBatchStatus Status { get; set; } = null!;
}
