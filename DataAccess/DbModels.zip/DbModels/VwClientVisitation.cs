﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwClientVisitation
{
    public int Id { get; set; }

    public int? CompanyId { get; set; }

    public string Company { get; set; } = null!;

    public string? VisitType { get; set; }

    public DateTime? VisitDate { get; set; }

    public string? ClientRep { get; set; }

    public string? Nmirep { get; set; }

    public string? Issues { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }
}
