﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblDepartment
{
    public int Id { get; set; }

    public string Department { get; set; } = null!;

    public string? EmailAddress { get; set; }

    public bool? Active { get; set; }
}
