﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TspUserRole
{
    public int RoleId { get; set; }

    public string UserRole { get; set; } = null!;
}
