﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblBenefitGroup
{
    public int Id { get; set; }

    public string BenefitGroup { get; set; } = null!;

    public int? BenefitParentId { get; set; }

    public int? RxGroupId { get; set; }

    public virtual TblBenefitParent? BenefitParent { get; set; }

    public virtual ICollection<TblBenefit> TblBenefits { get; set; } = new List<TblBenefit>();

    public virtual ICollection<TblPlanBenefitGroup> TblPlanBenefitGroups { get; set; } = new List<TblPlanBenefitGroup>();
}
