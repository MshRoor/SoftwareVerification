﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblRefundsPayment
{
    public int Id { get; set; }

    public int? PrincipalId { get; set; }

    public string? ReferenceNo { get; set; }

    public DateTime? PayDate { get; set; }

    public string? PayMode { get; set; }

    public string? ChequeNo { get; set; }

    public decimal? Amount { get; set; }

    public string? Description { get; set; }

    public string? PostingAccount { get; set; }

    public string? AccountName { get; set; }

    public int? SystemBankId { get; set; }

    public string? CreatedBy { get; set; }

    public int? SystemUserId { get; set; }

    public int? Processed { get; set; }

    public DateTime? CreatedDate { get; set; }
}
