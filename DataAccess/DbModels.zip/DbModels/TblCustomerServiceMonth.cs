﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblCustomerServiceMonth
{
    public int Id { get; set; }

    public DateTime? EventDate { get; set; }

    public int? EventMonth { get; set; }

    public int? EventYear { get; set; }

    public string? Theme { get; set; }

    public string? Activities { get; set; }

    public string? Remarks { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }
}
