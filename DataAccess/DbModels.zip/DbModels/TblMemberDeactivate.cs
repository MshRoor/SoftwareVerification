﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblMemberDeactivate
{
    public int RowId { get; set; }

    public int? MemberId { get; set; }

    public string? MembershipNo { get; set; }

    public DateOnly? EffectiveDate { get; set; }

    public DateTime? DateTimeCreated { get; set; }

    public DateTime? DateStamp { get; set; }
}
