﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblClaimsDetail
{
    public int Id { get; set; }

    public string ClaimsNo { get; set; } = null!;

    public double? Product { get; set; }

    public int ProductId { get; set; }

    public string? BenefitOption { get; set; }

    public double? Qty { get; set; }

    public double? QtyPrescribed { get; set; }

    public decimal? Claimed { get; set; }

    public double? Computed { get; set; }

    public decimal? Awarded { get; set; }

    public string? Curr { get; set; }

    public string? PreVetComments { get; set; }

    public bool? Rejected { get; set; }

    public bool? Verify { get; set; }

    public int? VettingId { get; set; }

    public DateTime? StampDate { get; set; }

    public decimal? Diff { get; set; }

    public int? PassGender { get; set; }

    public int? PassAge { get; set; }

    public int? PassExclusion { get; set; }

    public int? PassInOut { get; set; }

    public int? PassService { get; set; }

    public int? PassAmount { get; set; }

    public int? PassDiaTariff { get; set; }

    public decimal? ApprovedAmount { get; set; }

    public int? PrescribeDrug { get; set; }

    public DateOnly? DatePrescribed { get; set; }

    public int? Released { get; set; }

    public int? SameFunctionDrug { get; set; }

    public int? RxRowId { get; set; }

    public decimal? UnitPrice { get; set; }

    public decimal? ReviewAwarded { get; set; }

    public int? ReviewStatus { get; set; }

    public string? RefundReceiptNo { get; set; }

    public virtual TblClaimsHeader ClaimsNoNavigation { get; set; } = null!;

    public virtual TblTariff ProductNavigation { get; set; } = null!;

    public virtual ICollection<TblClaimsDetailsXTariffRejection> TblClaimsDetailsXTariffRejections { get; set; } = new List<TblClaimsDetailsXTariffRejection>();
}
