﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwCompanyPlanBenefitGroupsSale
{
    public int Id { get; set; }

    public int PlanId { get; set; }

    public string PlanName { get; set; } = null!;

    public int BenefitGroupId { get; set; }

    public string BenefitGroup { get; set; } = null!;

    public int? BenefitParentId { get; set; }

    public string ParentName { get; set; } = null!;

    public decimal? Limit { get; set; }

    public int CompanyId { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? UpdatedBy { get; set; }

    public DateTime? UpdatedDate { get; set; }

    public bool? Updated { get; set; }
}
