﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwOnlineUpload
{
    public string MemberNo { get; set; } = null!;

    public string? MemberPlan { get; set; }

    public string? Surname { get; set; }

    public string? Othernames { get; set; }

    public string? Sex { get; set; }

    public DateOnly? DateOfBirth { get; set; }

    public string? TelephoneNo { get; set; }

    public string? Email { get; set; }

    public string? Employer { get; set; }

    public DateTime? ExpiryDate { get; set; }

    public string Status { get; set; } = null!;

    public int MemberId { get; set; }

    public string? RxMemberId { get; set; }

    public string? InsertDeleteStatus { get; set; }

    public int? InfoUploaded { get; set; }

    public int? Printed { get; set; }

    public int? StatusId { get; set; }

    public int? CompanyId { get; set; }

    public string? PlanId { get; set; }

    public string? CardPin { get; set; }

    public string? MemberType { get; set; }

    public string? Relationship { get; set; }

    public int? PrincipalId { get; set; }

    public int? ActualStatusId { get; set; }

    public DateTime? BalanceStartDate { get; set; }

    public DateTime? IndvidualEx { get; set; }

    public DateTime? StartDate { get; set; }

    public string? OldMemberNo { get; set; }

    public bool? ReplaceMemberNo { get; set; }

    public string? NationalIdno { get; set; }
}
