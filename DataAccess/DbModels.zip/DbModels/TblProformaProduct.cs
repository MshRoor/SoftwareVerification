﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblProformaProduct
{
    public int Id { get; set; }

    public string InvoiceNo { get; set; } = null!;

    public int ProductId { get; set; }

    public int? MemberTypeId { get; set; }

    public int? Quantity { get; set; }

    public double? UnitPrice { get; set; }

    public double? Amount { get; set; }

    public string? OtherComment { get; set; }

    public DateTime? DateCreated { get; set; }

    public int? CompanyPlanSalesId { get; set; }

    public virtual TblProforma InvoiceNoNavigation { get; set; } = null!;
}
