﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblPlanBenefitLimit
{
    public int RowId { get; set; }

    public int PlanId { get; set; }

    public int BenefitId { get; set; }

    public string? CoverStatus { get; set; }

    public decimal? CoverLimit { get; set; }

    public string? CoverComment { get; set; }

    public virtual TblBenefit Benefit { get; set; } = null!;

    public virtual TblPlan Plan { get; set; } = null!;
}
