﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class User
{
    public int Id { get; set; }

    public string? UserName { get; set; }

    public int? NmiUserId { get; set; }

    public int? AccountTypeId { get; set; }

    public string? UserRoles { get; set; }

    public string? Email { get; set; }

    public string? PhoneNumber { get; set; }

    public bool? Blocked { get; set; }

    public int? UserDepartment { get; set; }

    public string? Profile { get; set; }

    public string? Staffnumber { get; set; }
}
