﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblBillingCycle
{
    public int BillingCycleNo { get; set; }

    public string BillingCycleName { get; set; } = null!;
}
