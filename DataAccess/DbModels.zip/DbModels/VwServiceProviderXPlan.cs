﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwServiceProviderXPlan
{
    public int RowId { get; set; }

    public int ServiceProviderId { get; set; }

    public string ServiceProvider { get; set; } = null!;

    public int PlanId { get; set; }

    public string PlanName { get; set; } = null!;

    public DateTime EffectiveDate { get; set; }

    public DateTime EndDate { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }
}
