﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwUtiliazationMyHealthDetail
{
    public int? MyHealthPrincipalId { get; set; }

    public decimal? SysAmountClaimed { get; set; }

    public int? InOutId { get; set; }
}
