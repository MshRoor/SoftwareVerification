﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblBank
{
    public int Id { get; set; }

    public string Bank { get; set; } = null!;

    public string? Shortname { get; set; }

    public bool? Active { get; set; }

    public virtual ICollection<TblBankBranch> TblBankBranches { get; set; } = new List<TblBankBranch>();
}
