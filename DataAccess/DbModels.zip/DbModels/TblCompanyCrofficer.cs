﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblCompanyCrofficer
{
    public int Id { get; set; }

    public int? CompanyId { get; set; }

    public int? CrofficerId { get; set; }

    public DateTime? DateAssigned { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public bool? Active { get; set; }
}
