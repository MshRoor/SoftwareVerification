﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblCompaniesSale
{
    public int Id { get; set; }

    public string CompanyName { get; set; } = null!;

    public string? Tin { get; set; }

    public string? OfficeLocation { get; set; }

    public string? PostalAddress { get; set; }

    public string? Telephone1 { get; set; }

    public string? Telephone2 { get; set; }

    public string? Email { get; set; }

    public string? ContactPerson { get; set; }

    public string? ContactPersonPhone { get; set; }

    public string? ContactPersonPhone2 { get; set; }

    public string? ContactPersonEmail { get; set; }

    public int? NatureOfBusinessId { get; set; }

    public int? BillingCycleNo { get; set; }

    public DateTime? ProposedStartDate { get; set; }

    public int? PolicyDuration { get; set; }

    public string? SourceOfBusiness { get; set; }

    public int? RegionId { get; set; }

    public string? DigitalAddress { get; set; }

    public string? CompanyApprovalBy { get; set; }

    public string? CompanyApprovalPosition { get; set; }

    public DateTime? CompanyApprovalDate { get; set; }

    public int? BusinessBy { get; set; }

    public DateTime? BusinessDate { get; set; }

    public bool? ActuarialApproved { get; set; }

    public string? ActuarialApprovedBy { get; set; }

    public DateTime? ActuarialApprovedDate { get; set; }

    public string? BusinessApprovedBy { get; set; }

    public bool? BusinessApproved { get; set; }

    public DateTime? BusinessApprovalDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? UpdatedBy { get; set; }

    public DateTime? UpdatedDate { get; set; }

    public bool? IsGroupPolicy { get; set; }

    public string? CompanyCardName { get; set; }

    public int? AdditionBillingCycleNo { get; set; }

    public string? RegistrationNo { get; set; }

    public int? ProductLineId { get; set; }

    public virtual ICollection<TblCompanySalesResponse> TblCompanySalesResponses { get; set; } = new List<TblCompanySalesResponse>();
}
