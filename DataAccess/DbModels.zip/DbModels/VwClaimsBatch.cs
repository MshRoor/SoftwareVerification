﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwClaimsBatch
{
    public int? ServiceProviderId { get; set; }

    public int BatchNo { get; set; }

    public DateTime? DateStamp { get; set; }

    public int? MemberId { get; set; }

    public int? NoOfClaims { get; set; }

    public decimal? AmountClaimed { get; set; }

    public decimal? AmountAwarded { get; set; }

    public DateTime? PeriodFrom { get; set; }

    public DateTime? PeriodTo { get; set; }

    public DateTime? StartEntryDate { get; set; }

    public DateTime? CompletedEntryDate { get; set; }

    public DateTime? DateOfClaim { get; set; }

    public int? BatchedBy { get; set; }

    public int? Sms { get; set; }

    public int? StatusId { get; set; }

    public string Status { get; set; } = null!;

    public decimal? SystemClaim { get; set; }

    public decimal? SystemAward { get; set; }

    public decimal? ProviderClaimed { get; set; }

    public decimal? ConfirmAward { get; set; }

    public int? TypeOfBatching { get; set; }

    public int? Tpa { get; set; }

    public int? NoOfFiles { get; set; }

    public string? SubmittedBy { get; set; }

    public string? ContactNo { get; set; }

    public int? PaymentModeId { get; set; }

    public string? MoMoNumber { get; set; }

    public string? Username { get; set; }

    public string? ModeOfSubmission { get; set; }

    public string ServiceProvider { get; set; } = null!;

    public int? ServiceTypeId { get; set; }

    public string? ServiceType { get; set; }

    public string? ClaimsMonth { get; set; }

    public string TypeOfBatch { get; set; } = null!;

    public string TypeOfClaims { get; set; } = null!;

    public int? AttendMonth { get; set; }

    public int? AttendYear { get; set; }

    public bool? BuildingFund { get; set; }

    public bool? WitholdingTax { get; set; }

    public int? AceeptTpa { get; set; }

    public string? Service { get; set; }

    public string? RmName { get; set; }
}
