﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class VwSettlementLetter
{
    public int Id { get; set; }

    public string ServiceProvider { get; set; } = null!;

    public int BatchNo { get; set; }

    public string? Bank { get; set; }

    public string? ChequeNo { get; set; }

    public decimal? ChequeAmount { get; set; }

    public decimal? AmountClaimed { get; set; }

    public string? Service { get; set; }

    public string? ClaimsMonth { get; set; }

    public DateTime? DateOfClaim { get; set; }

    public string? Fullname { get; set; }

    public string? WithHoldingRate { get; set; }

    public decimal? Withold { get; set; }

    public decimal? Awarded { get; set; }

    public string? SignaturePath { get; set; }
}
