﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblDrugPriceList
{
    public int DrugId { get; set; }

    public string? DrugName { get; set; }

    public double? DrugPrice { get; set; }

    public bool Mapped { get; set; }

    public int? TariffId { get; set; }
}
