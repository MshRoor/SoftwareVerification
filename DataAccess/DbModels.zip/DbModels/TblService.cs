﻿using System;
using System.Collections.Generic;

namespace DataAccess.DbModels;

public partial class TblService
{
    public int ServiceId { get; set; }

    public string? ServiceName { get; set; }

    public string? ServiceCode { get; set; }

    public string? Description { get; set; }

    public int? ApprovalRequired { get; set; }

    public int? LimitRequired { get; set; }

    public int? EscapeDiag { get; set; }

    public DateTime? DateStamp { get; set; }
}
